package nl.weeaboo.android.gles;

import nl.weeaboo.gl.GLResCache;
import nl.weeaboo.gl.GLResId;
import nl.weeaboo.gl.PBO;

public class ES2ResCache extends GLResCache {

	@Override
	public int getBufferCount() {
		return ES2ResId.getBufferCount();
	}

	@Override
	public int getProgramCount() {
		return ES2ResId.getProgramCount();
	}

	@Override
	public int getTextureCount() {
		return ES2ResId.getTextureCount();
	}

	@Override
	public void registerId(GLResId id) {
		registerId(new ES2ResId.IdRef((ES2ResId)id, this));
	}

	@Override
	public PBO newPBO() {
		throw new RuntimeException("Not supported");		
	}

}

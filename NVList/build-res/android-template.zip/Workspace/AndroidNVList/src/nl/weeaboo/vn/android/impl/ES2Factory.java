package nl.weeaboo.vn.android.impl;

import nl.weeaboo.android.gles.ES2Draw;
import nl.weeaboo.android.gles.ES2Manager;
import nl.weeaboo.android.gles.ES2ResCache;
import nl.weeaboo.android.gles.ES2ShaderStore;
import nl.weeaboo.android.gles.ESManager;
import nl.weeaboo.android.gles.ESTextureStore;
import nl.weeaboo.android.vn.AndroidRenderEnv;
import nl.weeaboo.android.vn.GLFactory;
import nl.weeaboo.filesystem.FileSystemView;
import nl.weeaboo.filesystem.IFileSystem;
import nl.weeaboo.gl.GLResCache;
import nl.weeaboo.gl.shader.IShaderStore;
import nl.weeaboo.vn.INotifier;
import nl.weeaboo.vn.IShaderFactory;
import nl.weeaboo.vn.impl.base.BaseNotifier;
import nl.weeaboo.vn.impl.base.BaseShaderFactory;
import nl.weeaboo.vn.impl.lua.LuaTweenLib;

public class ES2Factory extends GLFactory {

	public ES2Factory() {
	}
	
	@Override
	public GLResCache newGLResCache() {
		return new ES2ResCache();
	}
	
	@Override
	public ESManager<?> newGLManager(GLResCache rc, IShaderStore shs) {
		return new ES2Manager(new ES2Draw(shs), rc);		
	}

	@Override
	public IShaderStore newShaderStore(IFileSystem fs) {
		return new ES2ShaderStore(new FileSystemView(fs, "shader-es2", true));
	}

	@Override
	public BaseShaderFactory newShaderFactory(IShaderStore shs, BaseNotifier ntf) {
		return new ES2ShaderFactory(ntf, shs);
	}

	@Override
	public LuaTweenLib newTweenLib(INotifier ntf, ImageFactory imgfac, IShaderFactory shfac) {
		return new ES2TweenLib(ntf, imgfac, (ES2ShaderFactory)shfac);
	}
	
	@Override
	public Renderer newRenderer(AndroidRenderEnv env, ESManager<?> glm, ImageFactory imgfac,
			IShaderFactory shfac, ESTextureStore ts)
	{
		return new ES2Renderer(env, (ES2Manager)glm, imgfac, (ES2ShaderFactory)shfac, ts);
	}

}

package nl.weeaboo.android.gles;

import static android.opengl.GLES20.GL_TEXTURE0;
import static android.opengl.GLES20.GL_TEXTURE_2D;

import java.io.Serializable;

import nl.weeaboo.gl.GLManager;
import nl.weeaboo.gl.shader.AbstractShader;
import nl.weeaboo.gl.shader.IShaderStore;
import android.opengl.GLES20;

public final class ES2Shader extends AbstractShader implements Serializable {

	private static final long serialVersionUID = 1L;
	
	public ES2Shader(IShaderStore store, String filename) {
		super(store, filename);
	}
	
	//Functions	
		
	//Getters
	@Override
	protected int glGetUniformLocation(GLManager glm, String name) {
		return GLES20.glGetUniformLocation(glId(), name);
	}
	
	@Override
	protected int glGetAttribLocation(GLManager glm, String name) {
		return GLES20.glGetAttribLocation(glId(), name);
	}
		
	//Setters
	@Override
	public void setTextureUniform(GLManager glm, String name, int texIndex, int texId) {
		if (!glIsLoaded()) return;
		
		GLES20.glActiveTexture(GL_TEXTURE0 + texIndex);
		GLES20.glBindTexture(GL_TEXTURE_2D, texId);
		GLES20.glUniform1i(getUniformLocation(glm, name), texIndex);
		GLES20.glActiveTexture(GL_TEXTURE0);
	}

	@Override
	public void setFloatUniform(GLManager glm, String name, float x) {
		if (!glIsLoaded()) return;
	
		GLES20.glUniform1f(getUniformLocation(glm, name), x);
	}

	@Override
	public void setVec2Uniform(GLManager glm, String name, float x, float y) {
		if (!glIsLoaded()) return;
		
		GLES20.glUniform2f(getUniformLocation(glm, name), x, y);
	}

	@Override
	public void setVec3Uniform(GLManager glm, String name, float x, float y, float z) {
		if (!glIsLoaded()) return;
		
		GLES20.glUniform3f(getUniformLocation(glm, name), x, y, z);
	}

	@Override
	public void setVec4Uniform(GLManager glm, String name, float x, float y, float z, float a) {
		if (!glIsLoaded()) return;
		
		GLES20.glUniform4f(getUniformLocation(glm, name), x, y, z, a);
	}

	@Override
	public void setMat4Uniform(GLManager glm, String name, float[] mat, int off) {
		if (!glIsLoaded()) return;
		
		GLES20.glUniformMatrix4fv(getUniformLocation(glm, name), 1, false, mat, off);
	}
		
}

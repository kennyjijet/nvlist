package nl.weeaboo.vn.android.impl;

import static android.opengl.GLES20.GL_BLEND;
import static android.opengl.GLES20.GL_FLOAT;
import static android.opengl.GLES20.GL_ONE;
import static android.opengl.GLES20.GL_ONE_MINUS_SRC_ALPHA;
import static android.opengl.GLES20.GL_RGB;
import static android.opengl.GLES20.GL_SCISSOR_TEST;
import static android.opengl.GLES20.GL_TEXTURE_2D;
import static android.opengl.GLES20.GL_TRIANGLE_STRIP;
import static android.opengl.GLES20.GL_UNSIGNED_BYTE;

import java.nio.ByteBuffer;
import java.nio.FloatBuffer;
import java.nio.IntBuffer;

import nl.weeaboo.android.gles.ES2Draw;
import nl.weeaboo.android.gles.ES2Manager;
import nl.weeaboo.android.gles.ESTextureStore;
import nl.weeaboo.android.vn.AndroidRenderEnv;
import nl.weeaboo.common.Area2D;
import nl.weeaboo.common.Rect;
import nl.weeaboo.common.Rect2D;
import nl.weeaboo.gl.GLUtil;
import nl.weeaboo.gl.shader.GLShader;
import nl.weeaboo.gl.tex.GLTexRect;
import nl.weeaboo.gl.tex.GLTexture;
import nl.weeaboo.gl.tex.GLWritableTexture;
import nl.weeaboo.vn.BlendMode;
import nl.weeaboo.vn.IDistortGrid;
import nl.weeaboo.vn.IPixelShader;
import nl.weeaboo.vn.IScreenshot;
import nl.weeaboo.vn.ITexture;
import nl.weeaboo.vn.RenderCommand;
import nl.weeaboo.vn.impl.base.TriangleGrid;
import nl.weeaboo.vn.math.Matrix;
import android.opengl.GLES20;

class ES2Renderer extends Renderer {

	private final ES2Manager glm;
	private final boolean enableCopyTexSubImage;
	
	protected final ES2FadeQuadRenderer fadeQuadRenderer;	
	protected final ES2BlendQuadRenderer blendQuadRenderer;	
	protected final ES2DistortQuadRenderer distortQuadRenderer;
	
	//--- Properties only valid between renderBegin() and renderEnd() beneath this line ---
	private ES2Draw glDraw;
	//private GLInfo glInfo;
	private float dx, dy;
	private volatile ByteBuffer triangleGridTemp;	
	//-------------------------------------------------------------------------------------

	protected ES2Renderer(AndroidRenderEnv env, ES2Manager glm, ImageFactory imgfac,
			ES2ShaderFactory shfac, ESTextureStore ts)
	{
		super(env, glm, imgfac, ts);
		
		this.glm = glm;
		this.glDraw = glm.getGLDraw();
		this.enableCopyTexSubImage = false;
		
		this.fadeQuadRenderer = new ES2FadeQuadRenderer(this);
		this.blendQuadRenderer = new ES2BlendQuadRenderer(this, shfac);
		this.distortQuadRenderer = new ES2DistortQuadRenderer(this);
	}
	
	//Functions
	@Override
	protected void renderBegin() {
		//rendering = true;
		
		glDraw = glm.getGLDraw();
		//glInfo = glm.getGLInfo();
		
		glDraw.glPushMatrix();
		
		//Translate and scale to virtual screen coords
		final float scale = (float)env.scale;
		dx = env.rx / scale;
		dy = env.ry / scale;
		glDraw.scale(scale, -scale);
		glDraw.translate(dx, dy-env.sh/scale);
		
		//Init GL state
		GLES20.glEnable(GL_SCISSOR_TEST);
		GLES20.glEnable(GL_BLEND);
		GLES20.glBlendFunc(GL_ONE, GL_ONE_MINUS_SRC_ALPHA);
		glDraw.setColor(0xFFFFFFFF);
		glDraw.setTexture(null, true);
	}
	
	@Override
	protected void renderEnd() {
		//Restore GL state
		glDraw.setTexture(null, true);
		glDraw.setColor(0xFFFFFFFF);
		GLES20.glEnable(GL_BLEND);
		GLES20.glBlendFunc(GL_ONE, GL_ONE_MINUS_SRC_ALPHA);
		GLES20.glDisable(GL_SCISSOR_TEST);
		
		glDraw.glPopMatrix();
		
		//rendering = false;
	}
		
	@Override
	protected void setClip(boolean c) {
		if (c) {
			GLES20.glEnable(GL_SCISSOR_TEST);
		} else {
			GLES20.glDisable(GL_SCISSOR_TEST);
		}
	}

	@Override
	protected void setColor(int argb) {
		glDraw.setColor(argb);
	}

	@Override
	protected void setBlendMode(BlendMode bm) {
		switch (bm) {
		case DEFAULT: GLES20.glEnable(GL_BLEND);  GLES20.glBlendFunc(GL_ONE, GL_ONE_MINUS_SRC_ALPHA); break;
		case ADD:     GLES20.glEnable(GL_BLEND);  GLES20.glBlendFunc(GL_ONE, GL_ONE); break;
		case OPAQUE:  GLES20.glDisable(GL_BLEND); break;
		}
	}
				
	@Override
	protected void setClipRect(Rect glRect) {
		GLES20.glScissor(glRect.x, glRect.y, glRect.w, glRect.h);
	}

	@Override
	protected void translate(double x, double y) {
		float tx = (float)x;
		float ty = (float)y;
		glDraw.translate(tx, ty);
		this.dx += tx;
		this.dy += ty;
	}
	
	@Override
	public void renderTriangleGrid(TriangleGrid grid) {		
		final int rows = grid.getRows();
		final int cols = grid.getCols();
		final int texCount = grid.getTextures();
		final int verticesPerRow = cols * 2;
		
		//Reuse a single buffer, garbage collecting them is very, very slow.
		int vertBytes = verticesPerRow * 2 * 4;
		int colorBytes = verticesPerRow * 4;
		int texcoordBytes = verticesPerRow * 2 * 4;
		int requiredBytes = vertBytes + colorBytes + texCount * texcoordBytes;
		if (triangleGridTemp == null || triangleGridTemp.limit() < requiredBytes) {
			triangleGridTemp = GLUtil.newDirectByteBuffer(requiredBytes);
		}
				
		//Make sure the buffers can't be garbage collected while OpenGL is using it.
		final ByteBuffer raw = triangleGridTemp;
		int off = 0;
		FloatBuffer posBuf = GLUtil.sliceBuffer(raw, off, vertBytes).asFloatBuffer();
		off += vertBytes;
		IntBuffer colorBuf = GLUtil.sliceBuffer(raw, off, colorBytes).asIntBuffer();
		off += colorBytes;
		FloatBuffer[] texCoordBuf = new FloatBuffer[texCount];
		for (int n = 0; n < texCoordBuf.length; n++) {
			texCoordBuf[n] = GLUtil.sliceBuffer(raw, off, texcoordBytes).asFloatBuffer();
			off += texcoordBytes;
		}
		
		GLShader sh = glDraw.getShader();
		
		int positionId = sh.getAttribLocation(glm, ES2Draw.ATTR_POSITION);
		GLES20.glEnableVertexAttribArray(positionId);
		
		int argb = glDraw.getColor();
		for (int n = 0; n < verticesPerRow; n++) {
			colorBuf.put(argb);
		}
		colorBuf.rewind();
		GLUtil.swapRedBlue(colorBuf, colorBuf);
		
		int colorId = sh.getAttribLocation(glm, ES2Draw.ATTR_COLOR);
		GLES20.glEnableVertexAttribArray(colorId);
		GLES20.glVertexAttribPointer(colorId, 4, GL_UNSIGNED_BYTE, true, 0, colorBuf);
		
		int[] texCoordIds = new int[texCount];
		for (int n = 0; n < texCount; n++) {
			texCoordIds[n] = sh.getAttribLocation(glm, ES2Draw.ATTR_TEX_COORD + n);
			GLES20.glEnableVertexAttribArray(texCoordIds[n]);
		}		
		for (int row = 0; row < rows; row++) {
			grid.getVertices(posBuf, row);
			posBuf.rewind();
			GLES20.glVertexAttribPointer(positionId, 2, GL_FLOAT, false, 0, posBuf);
			
			for (int t = 0; t < texCount; t++) {
				grid.getTexCoords(texCoordBuf[t], t, row);
				texCoordBuf[t].rewind();
				GLES20.glVertexAttribPointer(texCoordIds[t], 2, GL_FLOAT, false, 0, texCoordBuf[t]);
			}
			
		    GLES20.glDrawArrays(GL_TRIANGLE_STRIP, 0, verticesPerRow);
		}
		for (int n = texCount-1; n >= 0; n--) {
			GLES20.glDisableVertexAttribArray(texCoordIds[n]);
		}
	    GLES20.glDisableVertexAttribArray(colorId);
	    GLES20.glDisableVertexAttribArray(positionId);
	}
			
	@Override
	public void renderQuad(ITexture itex, Matrix t, Area2D bounds, Area2D uv, IPixelShader ps) {
		if (ps != null) ps.preDraw(this);
		
		GLTexture tex = null;
		double u = uv.x;
		double v = uv.y;
		double uw = uv.w;
		double vh = uv.h;
		if (itex instanceof TextureAdapter) {			
			TextureAdapter ta = (TextureAdapter)itex;
			ta.glTryLoad(glm);
			GLTexRect tr = ta.getTexRect();

			Area2D texUV = tr.getUV();
			u  = texUV.x + u * texUV.w;
			v  = texUV.y + v * texUV.h;
			uw = texUV.w * uw;
			vh = texUV.h * vh;

			tex = tr.getTexture();			
		}
		glDraw.setTexture(tex);
		
		//System.out.println((tex != null ? tex.glId() : 0) + " " + tex + " " + bounds);
		
		//System.out.printf("%d {%.0f,%.0f,%.0f,%.0f} {%.0f,%.0f,%.0f,%.0f}%n", texId, x, y, w, h, u, v, uw, vh);
		
		glDraw.glPushMatrix();
		glDraw.glMultMatrixf(t.toGLMatrix(), 0);
		glDraw.useDefaultShader();
		glDraw.fillRect(bounds.x, bounds.y, bounds.w, bounds.h, u, v, uw, vh);
		glDraw.glPopMatrix();			
		
		if (ps != null) ps.postDraw(this);				
	}

	@Override
	public void renderBlendQuad(ITexture tex0, double alignX0, double alignY0, ITexture tex1, double alignX1,
			double alignY1, double frac, Area2D uv, Matrix transform, IPixelShader ps)
	{
		blendQuadRenderer.renderBlendQuad(tex0, alignX0, alignY0, tex1, alignX1, alignY1, frac, uv, transform, ps);
	}

	@Override
	public void renderFadeQuad(ITexture tex, Matrix transform, int color0, int color1,
			Area2D bounds, Area2D uv, IPixelShader ps,
			int dir, boolean fadeIn, double span, double frac)
	{
		//System.out.println(x + " " + y + " " + w + " " + h);
		
		//renderQuad(tex, transform, x, y, w, h, ps, 0, 0, 1, 1);
		fadeQuadRenderer.renderFadeQuad(tex, transform, color0, color1, bounds, uv, ps, dir, fadeIn, span, frac);
	}

	@Override
	public void renderDistortQuad(ITexture tex, Matrix transform, int argb,
			Area2D bounds, Area2D uv, IPixelShader ps,
			IDistortGrid grid, Rect2D clampBounds)
	{
		distortQuadRenderer.renderDistortQuad(tex, transform, argb, bounds, uv, ps, grid, clampBounds);
	}

	@Override
	public void renderScreenshot(IScreenshot out, Rect glScreenRect) {
		Screenshot ss = (Screenshot)out;
		
		boolean done = false;
		if (enableCopyTexSubImage && ss.isVolatile()) {
			GLWritableTexture glTex = texStore.newWritableTexture(glScreenRect.w, glScreenRect.h);
			GLTexRect glTexRect = glTex.getSubRect(GLUtil.TEXRECT_FLIPPED);

			final int fmt = GL_RGB;
			final int type = GL_UNSIGNED_BYTE;
			
			GLES20.glBindTexture(GL_TEXTURE_2D, glTex.glId());
			GLES20.glTexImage2D(GL_TEXTURE_2D, 0, fmt, glTex.getTexWidth(), glTex.getTexHeight(), 0, fmt, type, null);
			GLES20.glCopyTexSubImage2D(GL_TEXTURE_2D, 0, 0, 0, glScreenRect.x, glScreenRect.y, glScreenRect.w, glScreenRect.h);
			int err = GLES20.glGetError();
			GLES20.glBindTexture(GL_TEXTURE_2D, 0);
			
			if (err == 0) {			
				ITexture tex = imgfac.createTexture(glTexRect, env.vw / (double)env.rw, env.vh / (double)env.rh);			
				ss.setVolatilePixels(tex, env.rw, env.rh);
				done = true;
			} else {
				glTex.glUnload();
			}
		}
		
		if (!done) { //Non-volatile or volatile copy failed.
			ss.setPixels(glm, glScreenRect, env.rw, env.rh);
			done = true;
		}
	}

	@Override
	protected boolean renderUnknownCommand(RenderCommand cmd) {
		return false;
	}
	
}

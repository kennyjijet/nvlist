package nl.weeaboo.android.gles;

import static android.opengl.GLES20.GL_BLUE_BITS;
import static android.opengl.GLES20.GL_CLAMP_TO_EDGE;
import static android.opengl.GLES20.GL_GREEN_BITS;
import static android.opengl.GLES20.GL_LINEAR;
import static android.opengl.GLES20.GL_RED_BITS;
import static android.opengl.GLES20.GL_TEXTURE_2D;
import static android.opengl.GLES20.GL_TEXTURE_MAG_FILTER;
import static android.opengl.GLES20.GL_TEXTURE_MIN_FILTER;
import static android.opengl.GLES20.GL_TEXTURE_WRAP_S;
import static android.opengl.GLES20.GL_TEXTURE_WRAP_T;
import static javax.microedition.khronos.opengles.GL10.GL_BLEND;
import static javax.microedition.khronos.opengles.GL10.GL_CCW;
import static javax.microedition.khronos.opengles.GL10.GL_COLOR_BUFFER_BIT;
import static javax.microedition.khronos.opengles.GL10.GL_CULL_FACE;
import static javax.microedition.khronos.opengles.GL10.GL_DEPTH_TEST;
import static javax.microedition.khronos.opengles.GL10.GL_DITHER;
import static javax.microedition.khronos.opengles.GL10.GL_ONE;
import static javax.microedition.khronos.opengles.GL10.GL_ONE_MINUS_SRC_ALPHA;
import static javax.microedition.khronos.opengles.GL10.GL_PACK_ALIGNMENT;
import static javax.microedition.khronos.opengles.GL10.GL_UNPACK_ALIGNMENT;

import java.nio.Buffer;

import nl.weeaboo.gl.GLDraw;
import nl.weeaboo.gl.GLManager;
import nl.weeaboo.gl.GLResCache;
import nl.weeaboo.gl.GLResId;
import nl.weeaboo.gl.GLInfo.CapsBuilder;
import nl.weeaboo.gl.tex.GLTexture;
import android.opengl.GLES20;

public class ES2Manager extends ESManager<Object> {

	public ES2Manager(ES2Draw draw, GLResCache resCache) {
		super(Object.class, draw, resCache);
	}
	
	//Functions
	@Override
	public void init(Object glRaw, boolean contextChanged) {				
		super.init(glRaw, contextChanged);				
		
		GLES20.glClearColor(0f, 0f, 0f, 1f);
		
		//Clearing the depth buffer can cause a segfault when rapidly changing orientation on real hardware		
		//gl.glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
		GLES20.glClear(GL_COLOR_BUFFER_BIT);
		
		GLES20.glDisable(GL_DITHER);
		GLES20.glEnable(GL_BLEND);
		GLES20.glDisable(GL_DEPTH_TEST);
		GLES20.glBlendFunc(GL_ONE, GL_ONE_MINUS_SRC_ALPHA);
		GLES20.glFrontFace(GL_CCW);
		GLES20.glDisable(GL_CULL_FACE);
		GLES20.glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
		GLES20.glPixelStorei(GL_PACK_ALIGNMENT, 1);
		
		GLDraw glDraw = getGLDraw();
		glDraw.setColor(0xFFFFFFFF);		
	}
	
	@Override
	protected void initGLCaps(Object gl, CapsBuilder b) {
		super.initGLCaps(gl, b);
		
		b.fboSupported = true;
		b.generateMipmapSupported = true;
		b.texNPOTSupported = true;
		
		b.glslVersion = glOptString(GLES20.GL_SHADING_LANGUAGE_VERSION, "0");		
	}
	
	@Override
	protected String glOptString(int glIdentifier, String defaultVal) {
		String s = GLES20.glGetString(glIdentifier);
		return (s != null ? s : defaultVal);
	}
	
	@Override
	protected int glGetInteger(int glIdentifier) {
		int temp[] = new int[1];
		GLES20.glGetIntegerv(glIdentifier, temp, 0);
		return temp[0];
	}	
	
	@Override
	protected void glTexParameterf(int target, int pname, float value) {
		GLES20.glTexParameterf(target, pname, value);
	}
	
	@Override
	public GLResId newTextureId(int minF, int magF, int wrapS, int wrapT) {
		GLDraw draw = getGLDraw();
		GLTexture oldtex = draw.getTexture();		

		if (minF == 0) minF = GL_LINEAR;
		if (magF == 0) magF = GL_LINEAR;
		if (wrapS == 0) wrapS = GL_CLAMP_TO_EDGE;
		if (wrapT == 0) wrapT = GL_CLAMP_TO_EDGE;
		
		GLResId texId = ES2ResId.newTextureInstance(getGLResCache());
		//System.out.println("CREATE: " + texId);
		
		GLES20.glBindTexture(GL_TEXTURE_2D, texId.getId());
		GLES20.glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, minF);
		GLES20.glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, magF);
		GLES20.glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, wrapS);
		GLES20.glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, wrapT);
		draw.setTexture(oldtex, true);
        
		return texId;
	}

	@Override
	public GLResId newBufferId() {		
		return ES2ResId.newBufferInstance(getGLResCache());
	}

	@Override
	public GLResId newProgramId() {
		return ES2ResId.newProgramInstance(getGLResCache());
	}
	
	//Getters
	@Override
	public ES2Draw getGLDraw() {
		return (ES2Draw)super.getGLDraw();
	}
	
	public static ES2Draw getGLDraw(GLManager glm) {
		return (ES2Draw)glm.getGLDraw();
	}

	@Override
	public int[] getRenderTargetBits() {
		int bits[] = new int[3];
		GLES20.glGetIntegerv(GL_RED_BITS, bits, 0);
		GLES20.glGetIntegerv(GL_GREEN_BITS, bits, 1);
		GLES20.glGetIntegerv(GL_BLUE_BITS, bits, 2);
		return bits;
	}
	
	@Override
	public void glReadPixels(int x, int y, int w, int h, int fmt, int type, Buffer buf) {
		GLES20.glReadPixels(x, y, w, h, fmt, type, buf);
	}
		
	//Setters
	@Override
	public void initProjection(int w, int h) {
		super.initProjection(w, h);
		
		GLES20.glViewport(0, 0, w, h);		
	}
	
}

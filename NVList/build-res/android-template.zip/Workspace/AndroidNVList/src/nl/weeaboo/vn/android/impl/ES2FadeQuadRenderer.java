package nl.weeaboo.vn.android.impl;

import static android.opengl.GLES20.GL_TRIANGLE_STRIP;

import java.nio.FloatBuffer;
import java.nio.IntBuffer;

import nl.weeaboo.android.gles.ES2Draw;
import nl.weeaboo.android.gles.ES2Manager;
import nl.weeaboo.gl.GLManager;
import nl.weeaboo.gl.shader.GLShader;
import nl.weeaboo.vn.IPixelShader;
import nl.weeaboo.vn.ITexture;
import nl.weeaboo.vn.impl.base.FadeQuadHelper;
import nl.weeaboo.vn.math.Matrix;
import android.opengl.GLES20;

class ES2FadeQuadRenderer extends FadeQuadHelper {

	private final Renderer renderer;
	
	public ES2FadeQuadRenderer(Renderer r) {
		super(r);
		
		renderer = r;
	}

	//Functions
	@Override
	protected void renderTriangleStrip(ITexture itex, Matrix transform, IPixelShader ps,
			FloatBuffer vertices, FloatBuffer texcoords, IntBuffer colors, int count)
	{
		GLManager glm = renderer.getGLManager();
		ES2Draw glDraw = ES2Manager.getGLDraw(glm);
		
		//Set texture
		if (itex instanceof TextureAdapter) {
			TextureAdapter ta = (TextureAdapter)itex;
			ta.glTryLoad(glm);
			glDraw.setTexture(ta.getTexture());
		}
		
		glDraw.pushMatrix();		
		glDraw.multMatrixf(transform.toGLMatrix(), 0);		
		
		glDraw.useDefaultShader();
		if (ps != null) {
        	ps.preDraw(renderer);
        }
		
        GLShader sh = glDraw.getShader();
		int positionId = sh.getAttribLocation(glm, ES2Draw.ATTR_POSITION);
		GLES20.glEnableVertexAttribArray(positionId);
		int texCoordId = sh.getAttribLocation(glm, ES2Draw.ATTR_TEX_COORD);
		GLES20.glEnableVertexAttribArray(texCoordId);
		int colorId = sh.getAttribLocation(glm, ES2Draw.ATTR_COLOR);
		GLES20.glEnableVertexAttribArray(colorId);
        
        GLES20.glDrawArrays(GL_TRIANGLE_STRIP, 0, count);

		GLES20.glDisableVertexAttribArray(positionId);
		GLES20.glDisableVertexAttribArray(texCoordId);
		GLES20.glDisableVertexAttribArray(colorId);
    	
        if (ps != null) {
        	ps.postDraw(renderer);
        }		
        glDraw.popMatrix();
	}
	
	//Getters
	
	//Setters
	
}

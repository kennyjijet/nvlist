package nl.weeaboo.android.gles;

import static android.opengl.GLES20.GL_BLEND;
import static android.opengl.GLES20.GL_FLOAT;
import static android.opengl.GLES20.GL_TEXTURE_2D;
import static android.opengl.GLES20.GL_TRIANGLES;
import static android.opengl.GLES20.GL_UNSIGNED_BYTE;

import java.nio.Buffer;
import java.util.Stack;

import nl.weeaboo.gl.AbstractGLDraw;
import nl.weeaboo.gl.GLBlendMode;
import nl.weeaboo.gl.GLManager;
import nl.weeaboo.gl.GLUtil;
import nl.weeaboo.gl.SpriteBatch;
import nl.weeaboo.gl.shader.GLShader;
import nl.weeaboo.gl.shader.IShaderStore;
import nl.weeaboo.gl.tex.GLTexture;
import android.opengl.GLES20;
import android.opengl.Matrix;

public class ES2Draw extends AbstractGLDraw {

	public static final String ATTR_POSITION = "attrPos";
	public static final String ATTR_TEX_COORD = "attrTexCoord";
	public static final String ATTR_COLOR = "attrColor";
	public static final String UNIFORM_TEXTURE = "tex";
	public static final String UNIFORM_MVP_MATRIX = "mvpMatrix";
	
	public static final String SHADER_DEFAULT = "builtin/default";
	public static final String SHADER_COLOR = "builtin/color";
	public static final String SHADER_BLEND = "builtin/blend";
	public static final String SHADER_BITMAP_TWEEN = "builtin/bitmap-tween";
	
	private final IShaderStore shStore;
	private final SpriteBatch spriteBatch;
	
	private Stack<float[]> matrixStack;
	private float[] matrix;
	private float[] tempMatrix;
	private float[] projectionMatrix;
	private float[] color;
	
	private ES2Manager glm;
	//private GLInfo glInfo;
		
	public ES2Draw(IShaderStore shs) {
		shStore = shs;		
		spriteBatch = new SpriteBatch(1);
		
		matrixStack = new Stack<float[]>();
		matrix = new float[16];
		tempMatrix = new float[16];
		color = new float[] {1f, 1f, 1f, 1f};
		//glInfo = new GLInfo();
	}
	
	@Override
	public void init(GLManager _glm, boolean contextChanged) {
		glm = (ES2Manager)_glm;
		//glInfo = glm.getGLInfo();

		matrixStack.clear();
		Matrix.setIdentityM(matrix, 0);
		color[0] = color[1] = color[2] = color[3] = 1f;
		projectionMatrix = glm.getProjectionMatrix();
		
		super.init(glm, contextChanged);		

		spriteBatch.clear();
		spriteBatch.init(glm);
	}
	
	@Override
	public void fillRect(float x, float y, float w, float h, float u, float v, float uw, float vh) {
		spriteBatch.setColor(getColor());
		spriteBatch.draw(x, y, w, h, u, v, uw, vh);
		spriteBatch.flush(glm);
	}

	@Override
	public void clearRect(float x, float y, float w, float h, float r, float g, float b) {
		useDefaultShader();

		spriteBatch.setColor(GLUtil.packARGB(r, g, b, 1f));
		spriteBatch.draw(x, y, w, h);
		spriteBatch.flush(glm);
		spriteBatch.setColor(getColor());
	}

	@Override
	public void drawRangeElements(Buffer vertexBuf, Buffer texcoordBuf, Buffer colorBuf, int mode,
			int start, int end, int count, int glIndexType, Buffer indexBuf)
	{
		GLShader sh = useShader(getShader());
		
		int positionId = -1, texCoordId = -1, colorId = -1;
		if (sh != null) {
			positionId = sh.getAttribLocation(glm, ATTR_POSITION);
			texCoordId = sh.getAttribLocation(glm, ATTR_TEX_COORD);
			colorId = sh.getAttribLocation(glm, ATTR_COLOR);
		}
		
		if (positionId >= 0) {
			GLES20.glEnableVertexAttribArray(positionId);
			GLES20.glVertexAttribPointer(positionId, 2, GL_FLOAT, false, 0, vertexBuf);
		}
		
		if (texCoordId >= 0) {
			GLES20.glEnableVertexAttribArray(texCoordId);
			GLES20.glVertexAttribPointer(texCoordId, 2, GL_FLOAT, false, 0, texcoordBuf);
		}
		
		if (colorId >= 0) {
			GLES20.glEnableVertexAttribArray(colorId);
			GLES20.glVertexAttribPointer(colorId, 4, GL_UNSIGNED_BYTE, true, 0, colorBuf);
		}
		
		GLES20.glDrawElements(GL_TRIANGLES, count, glIndexType, indexBuf);

		if (positionId >= 0) {
			GLES20.glDisableVertexAttribArray(positionId);
		}
		if (texCoordId >= 0) {
			GLES20.glDisableVertexAttribArray(texCoordId);
		}
		if (colorId >= 0) {
			GLES20.glDisableVertexAttribArray(colorId);
		}
	}
	
	public void glPushMatrix() {
		matrixStack.push(matrix.clone());
	}
	
	public void glPopMatrix() {
		matrix = matrixStack.pop();
	}
	
	public void glMultMatrixf(float[] m, int offset) {
		Matrix.multiplyMM(tempMatrix, 0, matrix, 0, m, offset);
		
		m = matrix;
		matrix = tempMatrix;
		tempMatrix = m;
	}
	
	@Override
	public void translate(float x, float y) {
		Matrix.translateM(matrix, 0, x, y, 0f);
	}

	@Override
	public void scale(float x, float y) {
		Matrix.scaleM(matrix, 0, x, y, 1f);
	}

	@Override
	protected void glSetColor(float r, float g, float b, float a) {
		color[0] = r;
		color[1] = g;
		color[2] = b;
		color[3] = a;
	}

	@Override
	protected void glSetBlendMode(GLBlendMode mode) {
		if (mode == null) {
			GLES20.glDisable(GL_BLEND);
		} else {
			GLES20.glEnable(GL_BLEND);
			GLES20.glBlendFunc(mode.sfactor, mode.dfactor);
		}
	}

	@Override
	protected void glSetShader(GLShader sh) {
		if (sh == null || sh.glId() == 0) {
			GLES20.glUseProgram(0);
		} else {
			GLES20.glUseProgram(sh.glId());
		}
	}

	@Override
	protected void glSetTexture(GLTexture tex) {
		if (tex == null || tex.glId() == 0) {
			GLES20.glBindTexture(GL_TEXTURE_2D, 0);
		} else {
			GLES20.glBindTexture(GL_TEXTURE_2D, tex.glId());
			tex.use();
		}
	}
	
	public GLShader useDefaultShader() {
		return useShader(null);
	}
	public GLShader useShader(GLShader sh) {
		GLTexture tex = getTexture();
		int texId = (tex != null ? tex.glId() : 0);
		
		if (sh == null) {
			sh = shStore.getShader(texId != 0 ? SHADER_DEFAULT : SHADER_COLOR);
			if (sh == null) {
				setShader(null);
				return null;
			}
		}		
		sh.glTryLoad(glm);
		setShader(sh);
		
		//Set MVP matrix
		Matrix.multiplyMM(tempMatrix, 0, projectionMatrix, 0, matrix, 0);
		sh.setMat4Uniform(glm, UNIFORM_MVP_MATRIX, tempMatrix, 0);
		
		//Set texture
		sh.setTextureUniform(glm, UNIFORM_TEXTURE, 0, texId);
				
		return sh;
	}

}

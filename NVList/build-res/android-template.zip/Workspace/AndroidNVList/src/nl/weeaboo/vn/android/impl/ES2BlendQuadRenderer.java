package nl.weeaboo.vn.android.impl;

import static android.opengl.GLES20.GL_TEXTURE0;
import static android.opengl.GLES20.GL_TEXTURE1;
import static android.opengl.GLES20.GL_TEXTURE_2D;
import nl.weeaboo.android.gles.ES2Draw;
import nl.weeaboo.android.gles.ES2Manager;
import nl.weeaboo.common.Area2D;
import nl.weeaboo.common.Rect2D;
import nl.weeaboo.gl.GLDraw;
import nl.weeaboo.gl.GLInfo;
import nl.weeaboo.gl.GLManager;
import nl.weeaboo.gl.shader.GLShader;
import nl.weeaboo.vn.IDrawBuffer;
import nl.weeaboo.vn.IPixelShader;
import nl.weeaboo.vn.ITexture;
import nl.weeaboo.vn.impl.base.BaseRenderer;
import nl.weeaboo.vn.impl.base.BlendQuadHelper;
import nl.weeaboo.vn.impl.base.TriangleGrid;
import nl.weeaboo.vn.impl.base.TriangleGrid.TextureWrap;
import nl.weeaboo.vn.math.Matrix;
import android.opengl.GLES20;

class ES2BlendQuadRenderer extends BlendQuadHelper {
	
	private final Renderer renderer;
	private final ES2ShaderFactory shfac;
	
	public ES2BlendQuadRenderer(Renderer r, ES2ShaderFactory shfac) {
		super(r);
		
		this.renderer = r;
		this.shfac = shfac;
	}

	//Functions
	@Override
	protected void renderQuad(ITexture tex, Area2D uv, Matrix transform, int mixColorARGB, Rect2D bounds,
			IPixelShader ps)
	{
		GLManager glm = renderer.getGLManager();
		GLDraw draw = glm.getGLDraw();
		draw.pushColor();
		draw.mixColor(mixColorARGB);
		renderer.renderQuad(tex, transform, bounds.toArea2D(), IDrawBuffer.DEFAULT_UV, ps);
		draw.popColor();	
	}

	@Override
	protected void renderMultitextured(ITexture tex0, Rect2D bounds0, ITexture tex1, Rect2D bounds1,
			Area2D uv, Matrix transform, IPixelShader ps, float tex0Factor)
	{
		GLManager glm = renderer.getGLManager();
		ES2Draw glDraw = ES2Manager.getGLDraw(glm);
		
		int texId0 = getTexId(tex0);
		int texId1 = getTexId(tex1);
		Area2D uv0 = BaseRenderer.combineUV(uv, tex0.getUV());
		Area2D uv1 = BaseRenderer.combineUV(uv, tex1.getUV());
		
		TriangleGrid grid = TriangleGrid.layout2(
				bounds0.toArea2D(), uv0, TextureWrap.CLAMP,
				bounds1.toArea2D(), uv1, TextureWrap.CLAMP);		
		
		//Set texture 0
		GLES20.glActiveTexture(GL_TEXTURE0);
		GLES20.glBindTexture(GL_TEXTURE_2D, texId0);
		
		// Set texture 1
		GLES20.glActiveTexture(GL_TEXTURE1);
		GLES20.glBindTexture(GL_TEXTURE_2D, texId1);
		
		//Render triangle grid		
		glDraw.pushMatrix();
		glDraw.multMatrixf(transform.toGLMatrix(), 0);		
		
		GLShader sh = glDraw.useShader(shfac.getGLShader(ES2Draw.SHADER_BLEND));
		sh.setTextureUniform(glm, "tex0", 0, texId0);
		sh.setTextureUniform(glm, "tex1", 1, texId1);
		sh.setFloatUniform(glm, "frac", tex0Factor);
		
		renderer.renderTriangleGrid(grid, ps);
		
		glDraw.popMatrix();
		
		//Reset texture
		GLES20.glActiveTexture(GL_TEXTURE1);
		GLES20.glActiveTexture(GL_TEXTURE0);
	}
	
	//Getters
	protected int getTexId(ITexture tex) {
		TextureAdapter ta = (TextureAdapter)tex;
		ta.glTryLoad(renderer.getGLManager());
		return ta.glId();
	}
	
	@Override
	protected boolean isFallbackRequired() {
		GLManager glm = renderer.getGLManager();
		return !isAvailable(glm.getGLInfo());
	}
	
	public static boolean isAvailable(GLInfo glInfo) {
		return glInfo.isGLSLAvailable();
	}
	
	//Setters
	
}

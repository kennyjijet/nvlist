package nl.weeaboo.android.nvlist;

import nl.weeaboo.android.XAPKFile;


final class ExpansionConstants {

	public static final String LVL_KEY_BASE64 = "DEADBEEFDEADBEEF";
	
	public static final byte[] SALT = new byte[] { -50, 46, 23, 35, -125, -53, 35, 105, 80, 34, -5, 16, 44, 60, -120, 53 };
	
	/**
	 * Hardcoded currently active expansion files (avoids having to connect to the internet).
	 * 
	 * Warning: Expansion files must be (obfuscated) .nvl files, non-obfuscated files won't work.
	 */
	public static final XAPKFile[] EXPANSION_FILES = {
		/*
		new XAPKFile(
			true,		// true signifies a main file
			3,			// the version of the APK that the file was uploaded against
			687801613L	// the length of the file in bytes
		),
		new XAPKFile(
			false,		// false signifies a patch file
			4,			// the version of the APK that the patch file was uploaded against
			512860L 	// the length of the patch file in bytes
		)
		*/
	};

	
	
	
	
	private ExpansionConstants() {		
	}
		
}

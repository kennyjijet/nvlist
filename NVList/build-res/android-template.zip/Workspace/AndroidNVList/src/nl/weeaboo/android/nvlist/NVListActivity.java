package nl.weeaboo.android.nvlist;

import java.util.Collection;

import nl.weeaboo.android.XAPKFile;
import nl.weeaboo.android.vn.AndroidVN;
import nl.weeaboo.android.vn.GLFactory;
import nl.weeaboo.android.vn.Game;
import nl.weeaboo.filesystem.IArchiveSource;
import nl.weeaboo.vn.android.impl.ES1Factory;
import nl.weeaboo.vn.android.impl.ES2Factory;
import android.os.Bundle;
import android.util.Log;

import com.google.android.vending.expansion.downloader.Helpers;

public class NVListActivity extends AndroidVN {

	//Functions
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
	}

	@Override
	protected void onGameCreated(Game game) {
		super.onGameCreated(game);
		
		//Novel novel = game.getNovel();
		//novel.addLuaInitializer(...);
	}
	
	@Override
	protected void initArchiveSources(Collection<IArchiveSource> out) {
		super.initArchiveSources(out);
		
		XAPKFile[] xfiles = ExpansionConstants.EXPANSION_FILES;
		String[] xnames = new String[xfiles.length];
		for (int n = 0; n < xfiles.length; n++) {
			XAPKFile xf = xfiles[n];
			
			String name = Helpers.getExpansionAPKFileName(this, xf.isMain, xf.fileVersion);
			xnames[n] = Helpers.generateSaveFileName(this, name);
		}
		out.add(new XAPKArchiveSource(xnames));
	}	
	
	@Override
	protected GLFactory newGLFactory(boolean isLowEnd) {		
		if (getPreferredGLESVersion() >= 2) {
			Log.i(TAG, "Choosing GLES 2.0+ renderer");
			return new ES2Factory();
		}
		
		Log.i(TAG, "Choosing GLES 1.x renderer");
		return new ES1Factory(isLowEnd);
	}
		
	//Getters
	
	//Setters
	
}

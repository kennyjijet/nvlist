package nl.weeaboo.android.nvlist;

import com.google.android.vending.expansion.downloader.Helpers;

import nl.weeaboo.android.ResourceManager;
import nl.weeaboo.android.XAPKFile;
import nl.weeaboo.android.vn.AndroidVN;
import nl.weeaboo.android.vn.Game;
import nl.weeaboo.filemanager.IArchiveOpenPlugin;
import android.os.Bundle;

public class NVListActivity extends AndroidVN {

	//Functions
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
	}

	@Override
	protected void onGameCreated(Game game) {
		super.onGameCreated(game);
		
		//Novel novel = game.getNovel();
		//novel.addLuaInitializer(...);
	}
	
	@Override
	protected IArchiveOpenPlugin newArchiveOpenPlugin(ResourceManager rm, int versionCode) {
		IArchiveOpenPlugin inner = super.newArchiveOpenPlugin(rm, versionCode);
		
		XAPKFile[] xfiles = ExpansionConstants.EXPANSION_FILES;
		String[] xnames = new String[xfiles.length];
		for (int n = 0; n < xfiles.length; n++) {
			XAPKFile xf = xfiles[n];
			
			String name = Helpers.getExpansionAPKFileName(this, xf.isMain, xf.fileVersion);
			xnames[n] = Helpers.generateSaveFileName(this, name);
		}
		return new XAPKArchiveOpenPlugin(inner, xnames);
	}	
	
	//Getters
	
	//Setters
	
}

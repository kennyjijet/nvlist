package nl.weeaboo.android.gles;

import java.util.concurrent.atomic.AtomicInteger;

import nl.weeaboo.gl.GLLog;
import nl.weeaboo.gl.GLManager;
import nl.weeaboo.gl.GLResCache;
import nl.weeaboo.gl.GLResId;
import android.opengl.GLES20;

public final class ES2ResId implements GLResId {

	private enum Type {
		TEXTURE, PROGRAM, BUFFER;
		
		final AtomicInteger alive = new AtomicInteger();
		
		private Type() {			
		}
	}
	
	private final Type type;
	private final int surfaceId;
	private int id;
	
	private ES2ResId(Type type, int id, int surfaceId) {
		this.type = type;
		this.id = id;
		this.surfaceId = surfaceId;
		
		type.alive.incrementAndGet();
	}
	
	//Functions		
	static ES2ResId newTextureInstance(GLResCache rc) {
		int[] ids = new int[1];
		GLES20.glGenTextures(1, ids, 0);		

		ES2ResId r = new ES2ResId(Type.TEXTURE, ids[0], rc.getSurfaceId());
		rc.registerId(r);
		return r;
	}
	
	static ES2ResId newProgramInstance(GLResCache rc) {
		int id = GLES20.glCreateProgram();
		
		ES2ResId r = new ES2ResId(Type.PROGRAM, id, rc.getSurfaceId());
		rc.registerId(r);
		return r;
	}
	
	static ES2ResId newBufferInstance(GLResCache rc) {
		int[] ids = new int[1];
		GLES20.glGenBuffers(1, ids, 0);
		
		ES2ResId r = new ES2ResId(Type.BUFFER, ids[0], rc.getSurfaceId());
		rc.registerId(r);
		return r;
	}
	
	@Override
	public void dispose() {
		id = 0;
	}
	
	@Override
	public String toString() {
		return "GLResId(" + type + ":" + id + ")";
	}
	
	//Getters
	@Override
	public int getId() {
		return id;
	}
	
	static int getTextureCount() {
		return Type.TEXTURE.alive.get();
	}
	static int getBufferCount() {
		return Type.BUFFER.alive.get();
	}
	static int getProgramCount() {
		return Type.PROGRAM.alive.get();
	}
	
	//Setters
	
	//Inner Classes
	static final class IdRef extends GLResCache.IdRef {
		
		private final Type type;
		private final int id;
		private final int surfaceId;
		
		private boolean disposed;
		
		public IdRef(ES2ResId r, GLResCache rc) {
			super(r, rc);
			
			this.type = r.type;
			this.id = r.id;
			this.surfaceId = r.surfaceId;
		}

		@Override
		public void dispose(GLManager glm, int currentSurfaceId) {
			if (disposed) {
				return;
			}
			disposed = true;
			
			type.alive.decrementAndGet();
			
			if (surfaceId == currentSurfaceId && id != 0) {
				switch (type) {
				case TEXTURE:
					GLES20.glDeleteTextures(1, new int[]{id}, 0);
					break;
				case PROGRAM:
					GLES20.glDeleteProgram(id);
					break;
				case BUFFER:
					GLES20.glDeleteBuffers(1, new int[]{id}, 0);
					break;
				default:
					GLLog.w("Undisposable GLResourceId type: " + type);
				}
			}		
		}
		
	}
	
}

package nl.weeaboo.android.nvlist;

import java.io.File;
import java.io.IOException;

import nl.weeaboo.filemanager.IArchiveOpenPlugin;
import nl.weeaboo.zip.IFileArchive;

public class XAPKArchiveOpenPlugin implements IArchiveOpenPlugin {

	private final IArchiveOpenPlugin inner;
	private final String[] xfiles;
	
	public XAPKArchiveOpenPlugin(IArchiveOpenPlugin inner, String[] xf) {
		this.inner = inner;
		this.xfiles = xf.clone();
	}

	//Functions
	@Override
	public IFileArchive newArchive(String filename) {
		return inner.newArchive(filename);
	}
	
	//Functions	
	@Override
	public void openArchive(IFileArchive zip, File[] readFolders, String filename) throws IOException {
		try {
			if (filename.equals("xapk1.obb") && xfiles.length >= 1) {
				zip.open(new File(xfiles[0]));
			} else if (filename.equals("xapk2.obb") && xfiles.length >= 2) {
				zip.open(new File(xfiles[1]));
			} else {		
				inner.openArchive(zip, readFolders, filename);
			}
		} catch (IOException ioe) {
			//Log.w(getClass().getSimpleName(), "ARC: " + filename + " :: " + ioe.toString());
			throw ioe;
		}
	}
	
	//Getters
	
	//Setters

}

package nl.weeaboo.android.nvlist;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;

import nl.weeaboo.filesystem.IArchiveSource;
import nl.weeaboo.zip.IFileArchive;
import nl.weeaboo.zip.ZipArchive;

public class XAPKArchiveSource implements IArchiveSource {

	private static final String XAPK1 = "xapk1.obb";
	private static final String XAPK2 = "xapk2.obb";
	
	private final String[] xfiles;
	
	public XAPKArchiveSource(String... xf) {
		this.xfiles = xf.clone();
	}

	@Override
	public IFileArchive newArchive(String filename) {
		return new ZipArchive();
	}
	
	@Override
	public void openArchive(IFileArchive arc, String filename) throws IOException {
		if (filename.equals(XAPK1) && xfiles.length >= 1) {
			arc.open(new File(xfiles[0]));
			return;
		} else if (filename.equals(XAPK2) && xfiles.length >= 2) {
			arc.open(new File(xfiles[1]));
			return;
		}
		throw new FileNotFoundException(filename);
	}

	@Override
	public boolean getArchiveExists(String filename) {
		return filename.equals(XAPK1) || filename.equals(XAPK2);
	}

}

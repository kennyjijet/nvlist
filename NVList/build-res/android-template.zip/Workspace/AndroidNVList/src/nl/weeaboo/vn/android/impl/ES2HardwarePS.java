package nl.weeaboo.vn.android.impl;

import static android.opengl.GLES20.GL_TEXTURE0;
import static android.opengl.GLES20.GL_TEXTURE_2D;

import java.io.Serializable;

import nl.weeaboo.android.gles.ES2Draw;
import nl.weeaboo.gl.GLDraw;
import nl.weeaboo.gl.GLManager;
import nl.weeaboo.gl.shader.GLShader;
import nl.weeaboo.gl.tex.GLTexture;
import nl.weeaboo.lua2.io.LuaSerializable;
import nl.weeaboo.vn.IRenderer;
import nl.weeaboo.vn.ITexture;
import nl.weeaboo.vn.impl.base.BaseHardwarePS;
import android.opengl.GLES20;

@LuaSerializable
public class ES2HardwarePS extends BaseHardwarePS implements Serializable {
		
	private static final long serialVersionUID = 1L;

	private final GLShader shader;
	
	public ES2HardwarePS(ES2ShaderFactory shfac, GLShader sh) {
		super(shfac);
		
		this.shader = sh;
	}

	//Functions 
	@Override
	protected boolean startShader(IRenderer r) {
		if (shader == null) {
			return false;
		}
		
		GLManager glm = getGLManager(r);
		ES2Draw glDraw = (ES2Draw)glm.getGLDraw();
		glDraw.useShader(shader);

		GLTexture tex = glDraw.getTexture();
		if (tex == null) {
			applyTextureParam(r, "tex", 0, 0);
			//applyShaderParam(r, "texSize", new float[2]);
		} else {
			applyTextureParam(r, "tex", 0, tex.glId());
			//applyShaderParam(r, "texSize", new float[] {tex.getCropWidth(), tex.getCropHeight()});
		}
		
		return true;
	}

	@Override
	protected void stopShader(IRenderer r) {
		GLManager glm = getGLManager(r);
		GLDraw glDraw = glm.getGLDraw();
		glDraw.setShader(null);
	}

	@Override
	protected void resetTextures(IRenderer r, int... texIndices) {
		for (int texIndex : texIndices) {
			GLES20.glActiveTexture(GL_TEXTURE0 + texIndex);
			GLES20.glBindTexture(GL_TEXTURE_2D, 0);
		}
		GLES20.glActiveTexture(GL_TEXTURE0);
	}
	
	@Override
	protected void applyTextureParam(IRenderer r, String name, int texIndex, ITexture tex) {
		int texId = 0;
		if (tex instanceof TextureAdapter) {
			TextureAdapter ta = (TextureAdapter)tex;
			ta.glTryLoad(getGLManager(r));
			texId = ta.glId();
		}
		applyTextureParam(r, name, texIndex, texId);
	}
	
	protected void applyTextureParam(IRenderer r, String name, int texIndex, int texId) {
		shader.setTextureUniform(getGLManager(r), name, texIndex, texId);
	}

	@Override
	protected void applyFloat1Param(IRenderer r, String name, float v1) {
		shader.setFloatUniform(getGLManager(r), name, v1);
	}

	@Override
	protected void applyFloat2Param(IRenderer r, String name, float v1, float v2) {
		shader.setVec2Uniform(getGLManager(r), name, v1, v2);
	}

	@Override
	protected void applyFloat3Param(IRenderer r, String name, float v1, float v2, float v3) {
		shader.setVec3Uniform(getGLManager(r), name, v1, v2, v3);
	}

	@Override
	protected void applyFloat4Param(IRenderer r, String name, float v1, float v2, float v3, float v4) {
		shader.setVec4Uniform(getGLManager(r), name, v1, v2, v3, v4);
	}

	//Getters
	protected GLManager getGLManager(IRenderer r) {
		return ((ES2Renderer)r).getGLManager();
	}
	
	//Setters
	
}

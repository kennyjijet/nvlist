package nl.weeaboo.android.gles;

import static android.opengl.GLES20.GL_COMPILE_STATUS;
import static android.opengl.GLES20.GL_FRAGMENT_SHADER;
import static android.opengl.GLES20.GL_VERTEX_SHADER;

import java.io.ByteArrayInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectStreamException;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import static nl.weeaboo.android.gles.ES2Draw.*;
import nl.weeaboo.common.StringUtil;
import nl.weeaboo.filesystem.FileSystemView;
import nl.weeaboo.gl.GLException;
import nl.weeaboo.gl.GLLog;
import nl.weeaboo.gl.GLManager;
import nl.weeaboo.gl.GLResId;
import nl.weeaboo.gl.shader.AbstractShaderStore;
import nl.weeaboo.gl.shader.GLShader;
import nl.weeaboo.io.EnvironmentSerializable;
import nl.weeaboo.io.StreamUtil;
import android.opengl.GLES20;
import android.util.Log;

public class ES2ShaderStore extends AbstractShaderStore implements Serializable {

	private static final long serialVersionUID = 1L;

	private static final String TAG = "ES2ShaderStore";
	private static final String SUFFIX_VERT = ".vert";
	private static final String SUFFIX_FRAG = ".frag";
	
	private final Map<String, String> builtin = new HashMap<String, String>();
	
	private final EnvironmentSerializable es;
	
	public ES2ShaderStore(FileSystemView fs) {
		super(fs);
		
		initBuiltin("shaderES2/");
		
		es = new EnvironmentSerializable(this);		
	}

	//Functions
	private Object writeReplace() throws ObjectStreamException {	
		return es.writeReplace();
	}

	protected final void initBuiltin(String prefix) {
		builtin.clear();
		
		initBuiltin(builtin, prefix, SHADER_DEFAULT + SUFFIX_VERT);
		initBuiltin(builtin, prefix, SHADER_DEFAULT + SUFFIX_FRAG);
		initBuiltin(builtin, prefix, SHADER_COLOR + SUFFIX_VERT);
		initBuiltin(builtin, prefix, SHADER_COLOR + SUFFIX_FRAG);
		initBuiltin(builtin, prefix, SHADER_BLEND + SUFFIX_VERT);
		initBuiltin(builtin, prefix, SHADER_BLEND + SUFFIX_FRAG);		
		initBuiltin(builtin, prefix, SHADER_BITMAP_TWEEN + SUFFIX_VERT);
		initBuiltin(builtin, prefix, SHADER_BITMAP_TWEEN + SUFFIX_FRAG);		
	}
	
	private void initBuiltin(Map<String, String> out, String prefix, String filename) {
		try {
			ClassLoader cl = ES2ShaderStore.class.getClassLoader();
			if (cl == null) {
				throw new IOException("Unable to retrieve class loader for builtin shaders.");
			}
			
			InputStream in = cl.getResourceAsStream(prefix + filename);
			if (in == null) {
				throw new FileNotFoundException();
			}
			byte[] bytes = StreamUtil.readFully(in);
			out.put(filename, StringUtil.fromUTF8(bytes, 0, bytes.length));
		} catch (IOException ioe) {
			Log.e(TAG, "Error reading built-in shader: " + filename, ioe);
		}
	}
	
	@Override
	protected GLShader newShader(String path) throws IOException {
		if (!getFileExists(path + SUFFIX_VERT) && !getFileExists(path + SUFFIX_FRAG)) {
			throw new FileNotFoundException(path);
		}
		ES2Shader sh = new ES2Shader(this, path);
		register(path, sh);
		return sh;
	}

	@Override
	public GLResId newProgramId(GLManager glm, String filename) throws IOException {
		if (isShaderMarkedInvalid(filename)) {
			return null;
		}
		
		int vprog, fprog;
		try {
			vprog = newShaderId(filename + SUFFIX_VERT, GL_VERTEX_SHADER);
			fprog = newShaderId(filename + SUFFIX_FRAG, GL_FRAGMENT_SHADER);
		} catch (IOException ioe) {
			markShaderInvalid(filename, ioe);
			throw new GLException("Error creating shader: " + filename, ioe);
		}
		
		if (vprog == 0 && fprog == 0) {
			markShaderInvalid(filename);
			throw new FileNotFoundException("No vertex or fragment shaders found for shader: " + filename);
		}
		
		GLResId id = glm.newProgramId();
		int programId = id.getId();		
		int glerr = GLES20.glGetError();
		if (programId == 0) {
			markShaderInvalid(filename);
			throw new GLException("Unknown error, glCreateProgram returned 0, glError=" + glerr);
		}
			
		if (vprog != 0) {
			GLES20.glAttachShader(programId, vprog);
			glerr = GLES20.glGetError();
			if (glerr != 0) GLLog.w("Error in glAttachShader: " + glerr);
		}
		if (fprog != 0) {
			GLES20.glAttachShader(programId, fprog);
			glerr = GLES20.glGetError();
			if (glerr != 0) GLLog.w("Error in glAttachShader: " + glerr);
		}
		GLES20.glLinkProgram(programId);
		//GLES20.glValidateProgram(programId); Shouldn't be necessary
		
		if (vprog != 0) GLES20.glDeleteShader(vprog);
		if (fprog != 0) GLES20.glDeleteShader(fprog);
		
		return id;
	}
	
	private int newShaderId(String path, int type) throws IOException {
		String code;
		try {
			InputStream in = newInputStream(path);
			try {
				byte[] bytes = StreamUtil.readFully(in);
				code = StringUtil.fromUTF8(bytes, 0, bytes.length);
			} finally {
				in.close();
			}
		} catch (FileNotFoundException fnfe) {
			return 0;
		}

		int prog = GLES20.glCreateShader(type);			
		GLES20.glShaderSource(prog, code);				
		GLES20.glCompileShader(prog);
		
		int success[] = new int[1];
		GLES20.glGetShaderiv(prog, GL_COMPILE_STATUS, success, 0);
		if (success[0] == 0) {
			throw new IOException("Compilation Error: " + GLES20.glGetShaderInfoLog(prog));
		}
		
		return prog;
	}
	
	@Override
	protected boolean getFileExists(String path) {
		return builtin.containsKey(path) || super.getFileExists(path);
	}
	
	protected InputStream newInputStream(String path) throws IOException {
		String str = builtin.get(path);
		if (str != null) {
			return new ByteArrayInputStream(StringUtil.toUTF8(str));
		}
		return super.newInputStream(path);
	}
	
}

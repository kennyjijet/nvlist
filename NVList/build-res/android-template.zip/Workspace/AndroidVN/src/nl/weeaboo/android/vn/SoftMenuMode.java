package nl.weeaboo.android.vn;

public enum SoftMenuMode {

	VISIBLE, TRANSLUCENT, DISABLED;
	
}

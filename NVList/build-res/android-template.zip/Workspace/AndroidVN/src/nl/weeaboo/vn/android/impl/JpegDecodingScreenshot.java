package nl.weeaboo.vn.android.impl;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.nio.ByteBuffer;

import nl.weeaboo.android.gl.Screenshot;
import nl.weeaboo.io.BufferUtil;
import nl.weeaboo.io.ByteBufferInputStream;
import nl.weeaboo.lua2.io.LuaSerializable;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

@LuaSerializable
public class JpegDecodingScreenshot extends Screenshot {
	
	private static final long serialVersionUID = AndroidImpl.serialVersionUID;
	
	private transient ByteBuffer data;
	private int sampleSize = 1;
	
	public JpegDecodingScreenshot(ByteBuffer b, int sampleSize) {
		super((short)0);
		
		this.data = b;
		this.sampleSize = sampleSize;
	}
	
	//Functions
	private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
		in.defaultReadObject();
	
		int len = in.readInt();
		if (len > 0) {
			byte[] arr = new byte[len];
			in.readFully(arr);
			data = ByteBuffer.wrap(arr);
		}
	}
	
	private void writeObject(ObjectOutputStream out) throws IOException {
		out.defaultWriteObject();

		if (!isTransient && data != null) {
			byte[] arr = BufferUtil.toArray(data);
			out.writeInt(arr.length);
			out.write(arr);
		} else {
			out.writeInt(0);
		}
	}
	
	protected void lazyLoad() {
		if (isCancelled() || !isAvailable()) {
			return;
		}
		
		Bitmap bm = null;
		
		if (data != null) {
			BitmapFactory.Options opts = new BitmapFactory.Options();
			opts.inSampleSize = sampleSize;			
			bm = BitmapFactory.decodeStream(new ByteBufferInputStream(data), null, opts);
		}
		
		if (bm == null) {
			cancel();
		}
		
		data = null;
		bitmap = bm;
	}
		
	@Override
	public void cancel() {
		data = null; 
		bitmap = null;
		
		super.cancel();
	}
	
	@Override
	public Bitmap toBitmap() {
		lazyLoad();
		
		return super.toBitmap();
	}
	
	//Getters
	@Override
	public boolean isAvailable() {
		return data != null || bitmap != null;
	}
	
	@Override
	public boolean isCancelled() {
		return super.isCancelled() || (data == null && bitmap == null);
	}
		
	@Override
	public int[] getARGB() {
		lazyLoad();
		
		return super.getARGB();
	}
	
	@Override
	public int getWidth() {
		lazyLoad();

		return super.getWidth();
	}
	
	@Override
	public int getHeight() {
		lazyLoad();

		return super.getHeight();
	}
	
	@Override
	public int getScreenWidth() {
		return getWidth();
	}
	
	@Override
	public int getScreenHeight() {
		return getHeight();
	}
	
}
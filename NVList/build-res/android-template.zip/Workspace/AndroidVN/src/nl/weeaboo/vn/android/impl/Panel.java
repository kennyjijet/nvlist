package nl.weeaboo.vn.android.impl;

import nl.weeaboo.lua2.io.LuaSerializable;
import nl.weeaboo.vn.impl.base.BasePanel;

@LuaSerializable
public class Panel extends BasePanel {

	private static final long serialVersionUID = AndroidImpl.serialVersionUID;

	//Functions
	
	//Getters
	
	//Setters
	
}

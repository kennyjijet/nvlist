package nl.weeaboo.vn.android.impl;

import nl.weeaboo.android.vn.AndroidRenderEnv;
import nl.weeaboo.vn.IDrawBuffer;
import nl.weeaboo.vn.impl.base.BaseDrawBuffer;

public class DrawBuffer extends BaseDrawBuffer {

	public DrawBuffer(AndroidRenderEnv env) {
		super(env);
	}
	
	//Functions
	public static DrawBuffer cast(IDrawBuffer buf) {
		if (buf == null) return null;
		if (buf instanceof DrawBuffer) return (DrawBuffer)buf;
		throw new ClassCastException("Supplied draw buffer is of an invalid class: " + buf.getClass() + ", expected: " + DrawBuffer.class);
	}
	
	//Getters
	
	//Setters
	
}

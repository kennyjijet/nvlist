package nl.weeaboo.android.gles;

import java.io.BufferedInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.concurrent.ExecutorService;

import nl.weeaboo.android.JNGReader;
import nl.weeaboo.common.Dim;
import nl.weeaboo.common.StringUtil;
import nl.weeaboo.filesystem.IFileSystem;
import nl.weeaboo.game.resmgr.DataLoadException;
import nl.weeaboo.gl.GLInfo;
import nl.weeaboo.gl.GLManager;
import nl.weeaboo.gl.tex.ITextureData;
import nl.weeaboo.gl.tex.loader.AbstractTextureFormatHandler;
import nl.weeaboo.gl.tex.loader.TextureDataLoader;
import nl.weeaboo.gl.tex.loader.TextureLoadEnv;
import nl.weeaboo.gl.tex.loader.TextureLoadParam;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

public class ESTextureDataLoader extends TextureDataLoader {

	private String assetPrefix;
	private boolean dither;
	
	public ESTextureDataLoader(ExecutorService es, IFileSystem fs) {
		super(es, fs);
		
		assetPrefix = "";
		dither = false;
		
		registerDefaultTextureFormatHandler(new DefaultTextureFormatHandler());		
	}

	//Functions
	@Override
	public void initGL(GLManager glm) {
		super.initGL(glm);
		
		int[] bits = ((ESManager<?>)glm).getRenderTargetBits();
		dither = (bits == null || bits[0] < 8 || bits[1] < 8 || bits[2] < 8);
	}
	
	@Override
	protected InputStream newInputStream(IFileSystem fs, String prefix, String filename) throws IOException {
		try {
			return fs.newInputStream(assetPrefix + filename);
		} catch (FileNotFoundException fnfe) {
			return fs.newInputStream(prefix + filename);
		}
	}
	
	//Getters
	
	//Setters
	public void setAssetPrefix(String prefix) {
		assetPrefix = prefix;
	}
	
	//Inner Classes
	private class DefaultTextureFormatHandler extends AbstractTextureFormatHandler {

		@Override
		public ITextureData readTextureData(TextureLoadEnv env, TextureLoadParam param) throws DataLoadException {
			BitmapFactory.Options opts = new BitmapFactory.Options();
			opts.inDither = dither;
			opts.inScaled = false;
			
			InputStream in = env.getInputStream();
			Bitmap bitmap;
			if (StringUtil.getExtension(param.getFilename()).equalsIgnoreCase("jng")) {
				JNGReader jngReader = new JNGReader();
				try {
					bitmap = jngReader.read(new BufferedInputStream(in), opts);
				} catch (IOException e) {
					throw new DataLoadException(param, "Unable to decode image", e);					
				}
			} else {
				bitmap = BitmapFactory.decodeStream(in, null, opts);
			}			
			if (bitmap == null) {
				throw new DataLoadException(param, "Unable to decode image");					
			}			
			
			GLInfo glInfo = env.getGLInfo();
			Dim texSize = param.getTexSize();
			return ESTextureData.fromBitmap(glInfo, texSize, bitmap, false);
		}
	}
	
}

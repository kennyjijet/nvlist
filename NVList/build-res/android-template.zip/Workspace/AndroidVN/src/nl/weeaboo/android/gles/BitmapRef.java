package nl.weeaboo.android.gles;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

import nl.weeaboo.lua2.io.LuaSerializable;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

@LuaSerializable
public final class BitmapRef implements Serializable {

	private static final long serialVersionUID = 1L;
	
	//Warning: Uses manual serialization
	private Bitmap bitmap;
	private boolean shared;
	//Warning: Uses manual serialization
	
	private BitmapRef(Bitmap bitmap, boolean shared) {
		this.bitmap = bitmap;
		this.shared = shared;
		
		if (bitmap == null) throw new NullPointerException();
	}
	
	public static BitmapRef fromBitmap(Bitmap bitmap, boolean shared) {
		if (bitmap == null || bitmap.isRecycled()) return null;
		return new BitmapRef(bitmap, shared);
	}
	
	public static Bitmap tryGetBitmap(BitmapRef ref) {
		if (ref != null) {
			Bitmap bitmap = ref.bitmap;
			if (bitmap != null && !bitmap.isRecycled()) {
				return bitmap;
			}
		}
		return null;
	}
	
	private void writeObject(ObjectOutputStream out) throws IOException {
		bitmap.compress(Bitmap.CompressFormat.PNG, 100, out);
	}

	private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
		bitmap = BitmapFactory.decodeStream(in);
		shared = false;
	}

	public void dispose() {
		if (bitmap != null && !shared) {
			bitmap.recycle();
		}
	}
	
}

package nl.weeaboo.android.vn;

import nl.weeaboo.android.gles.ESManager;
import nl.weeaboo.android.gles.ESTextureStore;
import nl.weeaboo.filesystem.IFileSystem;
import nl.weeaboo.gl.GLResCache;
import nl.weeaboo.gl.shader.IShaderStore;
import nl.weeaboo.vn.INotifier;
import nl.weeaboo.vn.IShaderFactory;
import nl.weeaboo.vn.android.impl.ImageFactory;
import nl.weeaboo.vn.android.impl.Renderer;
import nl.weeaboo.vn.impl.base.BaseNotifier;
import nl.weeaboo.vn.impl.base.BaseShaderFactory;
import nl.weeaboo.vn.impl.lua.LuaTweenLib;

public abstract class GLFactory {

	public abstract GLResCache newGLResCache();
	public abstract IShaderStore newShaderStore(IFileSystem fs);
	public abstract ESManager<?> newGLManager(GLResCache rc, IShaderStore shs);
	public abstract BaseShaderFactory newShaderFactory(IShaderStore shs, BaseNotifier ntf);
	public abstract LuaTweenLib newTweenLib(INotifier ntf, ImageFactory imgfac, IShaderFactory shfac);
	public abstract Renderer newRenderer(AndroidRenderEnv env, ESManager<?> glm,
			ImageFactory imgfac, IShaderFactory shfac, ESTextureStore ts);
	
}

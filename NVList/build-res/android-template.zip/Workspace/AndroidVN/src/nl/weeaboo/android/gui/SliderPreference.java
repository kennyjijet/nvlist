package nl.weeaboo.android.gui;

import android.app.AlertDialog.Builder;
import android.content.Context;
import android.preference.DialogPreference;
import android.util.AttributeSet;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.TextView;

public class SliderPreference extends DialogPreference implements OnSeekBarChangeListener {

	private static final String androidNS = "http://schemas.android.com/apk/res/android";
	
	private Context context;
	private SeekBar seekBar;
	private TextView label;
	private int defaultValue;
	private int min, max;

	public SliderPreference(Context context, AttributeSet attrs) {
		super(context, attrs);
				
		this.context = context;
		
		this.defaultValue = attrs.getAttributeIntValue(androidNS, "defaultValue", 50);
		this.min = attrs.getAttributeIntValue(null, "min", 0);
		this.max = attrs.getAttributeIntValue(null, "max", 100);
	}

	protected void onPrepareDialogBuilder(Builder builder) {
		LinearLayout layout = new LinearLayout(context);
		layout.setOrientation(LinearLayout.HORIZONTAL);
		layout.setMinimumWidth(400);
		layout.setPadding(20, 20, 20, 20);

		seekBar = new SeekBar(context);
		seekBar.setMax(max - min);
		seekBar.setLayoutParams(new LinearLayout.LayoutParams(
				LinearLayout.LayoutParams.FILL_PARENT,
				LinearLayout.LayoutParams.WRAP_CONTENT, 0.25f));
		seekBar.setProgress(getPersistedInt(defaultValue) - min);
		seekBar.setOnSeekBarChangeListener(this);
		
		label = new TextView(context);
		label.setGravity(Gravity.RIGHT);
		label.setTextSize(label.getTextSize() * 1.5f);
		label.setLayoutParams(new LinearLayout.LayoutParams(
				LinearLayout.LayoutParams.FILL_PARENT,
				LinearLayout.LayoutParams.WRAP_CONTENT, .75f));

		layout.addView(seekBar);
		layout.addView(label);
		builder.setView(layout);

		super.onPrepareDialogBuilder(builder);
		
		onProgressChanged(seekBar, seekBar.getProgress(), false);
	}

	@Override
	protected void onDialogClosed(boolean positiveResult) {
		if (positiveResult) {
			int val = min + seekBar.getProgress();
			val = Math.max(min, Math.min(max, val));
			persistInt(val);
		}
	}

	@Override
	protected void onSetInitialValue(boolean restore, Object defaultValue) {
		super.onSetInitialValue(restore, defaultValue);
		
		if (seekBar != null) {
			if (restore) {
				seekBar.setProgress(getPersistedInt(this.defaultValue) - min);
			} else {
				seekBar.setProgress((Integer)defaultValue - min);
			}
		}
	}

	@Override
	public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
        label.setText(String.valueOf(min + progress));
	}

	@Override
	public void onStartTrackingTouch(SeekBar seekBar) {
	}

	@Override
	public void onStopTrackingTouch(SeekBar seekBar) {
	}

}

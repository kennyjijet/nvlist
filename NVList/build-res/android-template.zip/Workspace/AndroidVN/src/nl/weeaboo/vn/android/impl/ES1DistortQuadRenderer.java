package nl.weeaboo.vn.android.impl;

import static javax.microedition.khronos.opengles.GL10.GL_COLOR_ARRAY;
import static javax.microedition.khronos.opengles.GL10.GL_FLOAT;
import static javax.microedition.khronos.opengles.GL10.GL_MODULATE;
import static javax.microedition.khronos.opengles.GL10.GL_TEXTURE_2D;
import static javax.microedition.khronos.opengles.GL10.GL_TEXTURE_COORD_ARRAY;
import static javax.microedition.khronos.opengles.GL10.GL_TEXTURE_ENV;
import static javax.microedition.khronos.opengles.GL10.GL_TEXTURE_ENV_MODE;
import static javax.microedition.khronos.opengles.GL10.GL_TRIANGLE_STRIP;
import static javax.microedition.khronos.opengles.GL10.GL_UNSIGNED_BYTE;
import static javax.microedition.khronos.opengles.GL10.GL_VERTEX_ARRAY;

import java.nio.FloatBuffer;
import java.nio.IntBuffer;

import javax.microedition.khronos.opengles.GL10;

import nl.weeaboo.android.gles.ES1Manager;
import nl.weeaboo.gl.GLManager;
import nl.weeaboo.vn.ITexture;
import nl.weeaboo.vn.impl.base.DistortQuadHelper;
import nl.weeaboo.vn.math.Matrix;

public class ES1DistortQuadRenderer extends DistortQuadHelper {

	private final Renderer renderer;
	
	public ES1DistortQuadRenderer(Renderer r) {
		super(r);
		
		renderer = r;
	}

	//Functions
	@Override
	protected void preRender(ITexture itex, Matrix transform) {
		GLManager glm = renderer.getGLManager();
		GL10 gl = ES1Manager.getGL(glm);
		
		//Set texture
		int texId = 0;
		if (itex instanceof TextureAdapter) {
			TextureAdapter ta = (TextureAdapter) itex;
			ta.glTryLoad(glm);
			texId = ta.glId();
		}
		
		if (texId != 0) {
			gl.glEnable(GL_TEXTURE_2D);
			gl.glBindTexture(GL_TEXTURE_2D, texId);
	        gl.glTexEnvx(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);	        	        
		} else {
			gl.glDisable(GL_TEXTURE_2D);
		}
		
		gl.glPushMatrix();		
		gl.glMultMatrixf(transform.toGLMatrix(), 0);		
		
        gl.glEnableClientState(GL_VERTEX_ARRAY);
		gl.glEnableClientState(GL_TEXTURE_COORD_ARRAY);		
        gl.glEnableClientState(GL_COLOR_ARRAY);
	}
	
	@Override
	protected void renderStrip(FloatBuffer vertices, FloatBuffer texcoords, IntBuffer colors, int count) {        
		GLManager glm = renderer.getGLManager();
		GL10 gl = ES1Manager.getGL(glm);

		gl.glVertexPointer(2, GL_FLOAT, 0, vertices);
        gl.glTexCoordPointer(2, GL_FLOAT, 0, texcoords);
        gl.glColorPointer(4, GL_UNSIGNED_BYTE, 0, colors);
        gl.glDrawArrays(GL_TRIANGLE_STRIP, 0, count);
	}
	
	@Override
	protected void postRender() {
		GLManager glm = renderer.getGLManager();
		GL10 gl = ES1Manager.getGL(glm);

		gl.glDisableClientState(GL_VERTEX_ARRAY);	        
        gl.glDisableClientState(GL_TEXTURE_COORD_ARRAY);	        
        gl.glDisableClientState(GL_COLOR_ARRAY);	        
    	
		gl.glPopMatrix();
	}
	
	//Getters
	
	//Setters
	
}

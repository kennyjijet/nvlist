package nl.weeaboo.vn.android.impl;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectStreamException;

import nl.weeaboo.filemanager.IFileManager;
import nl.weeaboo.io.EnvironmentSerializable;
import nl.weeaboo.lua2.io.LuaSerializable;
import nl.weeaboo.vn.INotifier;
import nl.weeaboo.vn.impl.lua.BaseScriptLib;
import nl.weeaboo.vn.impl.lua.LuaNovel;
import android.content.res.AssetManager;

@LuaSerializable
public class ScriptLib extends BaseScriptLib {

	private static final String prefix = "script/";
	
	private final IFileManager fm;
	private final AssetManager assetManager;
	private final EnvironmentSerializable es;
	
	public ScriptLib(IFileManager fm, AssetManager am, INotifier ntf) {
		this.fm = fm;
		this.assetManager = am;
		this.es = new EnvironmentSerializable(this);
	}
	
	//Functions
	private Object writeReplace() throws ObjectStreamException {	
		return es.writeReplace();
	}
	
	protected boolean getScriptExists(String normalizedFilename) {
		return LuaNovel.isBuiltInScript(normalizedFilename)
			|| fm.getFileExists(prefix + normalizedFilename);
	}
	
	@Override
	protected InputStream openExternalScriptFile(String filename) throws IOException {
		InputStream in;
		try {
			in = fm.getInputStream(prefix + filename);
		} catch (IOException e) {
			in = assetManager.open(prefix + filename);
		}
		
		if (in == null) {
			throw new FileNotFoundException(filename);
		}
		
		return in;
	}

	@Override
	protected long getExternalScriptModificationTime(String filename) throws IOException {
		return fm.getFileModifiedTime(prefix + filename);
	}
	
	//Getters
	
	//Setters
	
}

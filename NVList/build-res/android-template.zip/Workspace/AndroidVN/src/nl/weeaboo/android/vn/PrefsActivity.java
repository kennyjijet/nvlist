package nl.weeaboo.android.vn;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashSet;
import java.util.Set;

import nl.weeaboo.io.StreamUtil;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences.Editor;
import android.content.res.Resources;
import android.os.Bundle;
import android.preference.Preference;
import android.preference.Preference.OnPreferenceClickListener;
import android.preference.PreferenceActivity;
import android.preference.PreferenceGroup;
import android.preference.PreferenceScreen;

public abstract class PrefsActivity extends PreferenceActivity {

	private int[] removeIds;
	
	public PrefsActivity(int... remove) {
		removeIds = remove;
	}
	
	//Functions
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
	
		initPreferences();		
	}
	
	protected void initPreferences() {
		PreferenceScreen prefScreen = getPreferenceScreen();
		if (prefScreen != null) {
			prefScreen.removeAll();
		}
		
		addPreferencesFromResource(R.xml.prefs);
        prefScreen = getPreferenceScreen();
        
        Set<String> removeSet = new HashSet<String>();
        Intent intent = getIntent();
        Resources res = getResources();

        String prefInfoKey = res.getString(R.string.pref_info);
        Preference infoPref = prefScreen.findPreference(prefInfoKey);
        if (infoPref != null) {
        	String desc = intent.getStringExtra(prefInfoKey);
        	if (desc == null) {
        		removeSet.add(prefInfoKey);
        	} else {
        		infoPref.setSummary(desc);
        	}
        }
        
        Preference licensePref = prefScreen.findPreference(res.getString(R.string.pref_license));
        if (licensePref != null) {
        	licensePref.setOnPreferenceClickListener(new OnPreferenceClickListener() {
				public boolean onPreferenceClick(Preference preference) {
					Resources res = getResources();
					
					String licenseString;
					try {
						InputStream in = res.openRawResource(R.raw.license);
						try {
							licenseString = new String(StreamUtil.readFully(in), "UTF-8");
						} finally {
							in.close();
						}
					} catch (IOException e) {
						licenseString = getString(R.string.pref_license_dialog_error);
					}
					
					new AlertDialog.Builder(PrefsActivity.this)
						.setTitle(R.string.pref_license_dialog_title)
						.setMessage(licenseString)
						.setNegativeButton(R.string.pref_license_dialog_cancel, null)
						.show();				
					return true;
				}
        	});
        }
        
        Preference resetPref = prefScreen.findPreference(res.getString(R.string.pref_reset_all));
        if (resetPref != null) {
	        resetPref.setOnPreferenceClickListener(new OnPreferenceClickListener() {
				public boolean onPreferenceClick(Preference preference) {
					new AlertDialog.Builder(PrefsActivity.this)
						.setTitle(R.string.pref_reset_all_dialog_title)
						.setMessage(R.string.pref_reset_all_dialog_message)
						.setPositiveButton(R.string.pref_reset_all_dialog_ok, new Dialog.OnClickListener() {
							public void onClick(DialogInterface dialog, int which) {
								Editor editor = getPreferenceScreen().getEditor();
								editor.clear();
								editor.commit();
								
								initPreferences();
							}
						})
						.setNegativeButton(R.string.pref_reset_all_dialog_cancel, null)
						.show();				
					return true;
				}
	        });      
        }
        
        for (int id : removeIds) {
        	removeSet.add(res.getString(id));
        }        
        removePreferences(prefScreen, removeSet);        
	}
	
	protected void removePreferences(PreferenceGroup group, Set<String> removeSet) {
        for (int n = 0; n < group.getPreferenceCount(); n++) {
        	Preference pref = group.getPreference(n);
        	if (pref instanceof PreferenceGroup) {
        		removePreferences((PreferenceGroup)pref, removeSet);
        	} else if (removeSet.contains(pref.getKey())) {
	        	group.removePreference(pref);
	        	n--;
        	}
        }		
	}
	
	//Getters
	
	//Setters
	
}

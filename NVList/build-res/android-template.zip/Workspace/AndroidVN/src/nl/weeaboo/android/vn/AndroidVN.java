package nl.weeaboo.android.vn;

import static android.view.WindowManager.LayoutParams.FLAG_FULLSCREEN;
import static android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON;
import static nl.weeaboo.android.AndroidUtil.cancelTask;
import static nl.weeaboo.android.AndroidUtil.isTaskRunning;
import static nl.weeaboo.android.vn.AndroidConfig.ACTION_BAR_ALGORITHM;
import static nl.weeaboo.android.vn.AndroidConfig.PREFERRED_ORIENTATION;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import nl.weeaboo.android.AndroidUtil;
import nl.weeaboo.android.AssetArchiveOpenPlugin;
import nl.weeaboo.android.ProgressListener;
import nl.weeaboo.android.ResourceManager;
import nl.weeaboo.android.SubTaskProgressListener;
import nl.weeaboo.android.gl.Screenshot;
import nl.weeaboo.android.gui.GLActivity;
import nl.weeaboo.android.gui.GLSurfaceView;
import nl.weeaboo.android.gui.Painter;
import nl.weeaboo.filemanager.IArchiveOpenPlugin;
import nl.weeaboo.lua2.LuaException;
import nl.weeaboo.vn.IImageState;
import nl.weeaboo.vn.ITimer;
import nl.weeaboo.vn.android.impl.Novel;
import nl.weeaboo.vn.impl.base.Obfuscator;
import nl.weeaboo.vn.vnds.VNDSUtil;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager.NameNotFoundException;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.media.AudioManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.Window;
import android.widget.ProgressBar;
import android.widget.TextView;

public class AndroidVN extends GLActivity implements Painter {
	
	public static final String TAG = "AndroidVN";
	public static final String BUNDLE_ID_ROOT = "folder";
	
	public static boolean allowSaveLoad = true;
	public static boolean allowQuickRead = true;
	
	private Game game;
	private boolean allowSuperSkip;
	private Handler msgHandler;
	private AsyncTask<Void, Float, Game> initTask;
	private AsyncTask<?, ?, ?> task;
	private int preferredOrientation;
	private boolean delayedResume;
	private boolean supportsActionBar;
	private int actionBarAlgorithm;
	
	public AndroidVN() {
		super(new GameRenderer());
	}
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		//if ((getApplication().getApplicationInfo().flags & ApplicationInfo.FLAG_DEBUGGABLE) != 0) {
		//	AndroidUtil.initStrictMode();
		//}
				
		supportsActionBar = AndroidUtil.supportsActionBar(this);
		if (!supportsActionBar) {
			//Remove title bar if it's not also the action bar
			requestWindowFeature(Window.FEATURE_NO_TITLE);
		}
		setWindowFlags(getWindow());

		final Resources res = getResources();		
		final File root = getRootFolder(getIntent(), res);
		final boolean isVNDS = VNDSUtil.isVNDSGame(root);
		allowSuperSkip = isVNDS && AndroidVN.allowQuickRead;
		
		super.onCreate(savedInstanceState);
		
		setContentView(R.layout.init);
		
        PreferenceManager.setDefaultValues(this, R.xml.prefs, false);
		preferredOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED;
		actionBarAlgorithm = -1;
		msgHandler = new Handler();		
				
		Display display = getWindowManager().getDefaultDisplay();
		DisplayMetrics metrics = new DisplayMetrics();
		display.getMetrics(metrics);					
		setVolumeControlStream(AudioManager.STREAM_MUSIC);
		
		final String gameId = getGameId(root);
		final boolean debugSigned = AndroidUtil.isDebugSigned(this, AndroidVN.class);
		final float density = metrics.density;
		
		PackageInfo pinfo = null;
		try {
			pinfo = getPackageManager().getPackageInfo(getPackageName(), 0);
		} catch (NameNotFoundException e) {
			//Ignore
		}
		final int versionCode = (pinfo != null && !debugSigned ? pinfo.versionCode : 0);
		
		final ResourceManager rm = newFileManager(gameId, root, isVNDS);
		final IArchiveOpenPlugin aop = newArchiveOpenPlugin(rm, versionCode);
		final ProgressBar splashProgress = (ProgressBar)findViewById(R.id.splashProgress);
		final TextView splashMessage = (TextView)findViewById(R.id.splashMessage);
		
		initTask = new AsyncTask<Void, Float, Game>() {
			
			private volatile Game game;
			private volatile String error;

			@Override
			protected void onPreExecute() {
				super.onPreExecute();

				splashMessage.setText(R.string.dialog_init_message);

				game = new Game(AndroidVN.this, msgHandler, gameId,
						density, debugSigned, inputAccum, AndroidVN.this);
			}
			
			@Override
			protected Game doInBackground(Void... params) {
				try {
					publishProgress(.0f);
					ProgressListener pl = new SubTaskProgressListener(0.0f, 1.0f) {
						@Override
						protected void onMainProgress(float val) {
							publishProgress(val);
						}
					};
					game.init(root, isVNDS, rm, aop, pl);
					publishProgress(1f);
				} catch (GameNotFoundException gnfe) {
					String err = "Error during initialization";
					Log.e(TAG + ".InitTask", err, gnfe);
					error = err + ": " + gnfe.getMessage();
					game = null;
				} catch (Exception e) {
					String err = "Error initializing game";
					Log.e(TAG + ".InitTask", err, e);
					error = err + ": " + e;
					game = null;
				}
				
				//game.checkSaveability();
				
				return game;
			}
			
			protected void onProgressUpdate(Float... values) {
				super.onProgressUpdate(values);
				
				if (values != null && values.length >= 1 && values[0] != null) {
					int max = splashProgress.getMax();
					int progress = Math.max(0, Math.min(max, Math.round(values[0] * max)));
					splashProgress.setProgress(progress);
				}
			}
			
			@Override
			protected void onPostExecute(final Game game) {
				super.onPostExecute(game);
								
				if (game != null && error == null) {
					AndroidVN.this.game = game;
					
					setContentView(getGLView());

					((GameRenderer)renderer).setGame(game);
					onPrefsChanged();
					
					if (isVNDS) {
						game.restart("vnds.main");
					} else {
						game.restart("main");
					}
										
					game.start();
				} else {
					AlertDialog.Builder builder = new AlertDialog.Builder(AndroidVN.this);
					builder.setCancelable(false);
					builder.setTitle(R.string.dialog_fatal_error_title);
					builder.setMessage(error);
					builder.setPositiveButton(R.string.dialog_fatal_error_ok,
						new OnClickListener() {
							public void onClick(DialogInterface dialog, int which) {
								AndroidVN.this.finish();
							}
					});
					builder.show();					
				}
				
				initTask = null;
			}
		};
		initTask.execute();
	}
	
	protected ResourceManager newFileManager(String gameId, File root, boolean isVNDS) {
		List<String> zipFiles = new ArrayList<String>();
		if (isVNDS) {
			zipFiles.addAll(Arrays.asList(VNDSUtil.getZipFilenames()));
		}
		zipFiles.addAll(Arrays.asList("assets", "xapk1.obb", "xapk2.obb", "res.zip", gameId+".nvl"));		
		
		ResourceManager rm = new ResourceManager(this, root.toURI(), zipFiles.toArray(new String[0]));			
		if (isVNDS) {
			rm.setImageFolder("");
			rm.setSoundFolder("");
			rm.setVideoFolder("");
		}		
		return rm;
	}
	
	protected IArchiveOpenPlugin newArchiveOpenPlugin(ResourceManager rm, int versionCode) {
		return new AssetArchiveOpenPlugin(rm, getAssets(), versionCode, Obfuscator.getInstance());		
	}
	
	@Override
	public void onDestroy() {
		cancelTask(initTask);
		initTask = null;
		cancelTask(task);
		task = null;
				
		if (game != null) {
			synchronized (game) {
				game.stop();
				game.dispose();
			}
			if (SaveLoadActivity.game == game) {
				SaveLoadActivity.game = null;
			}
		}		

		super.onDestroy();
	}
	
	@Override
	public void onConfigurationChanged(Configuration newConfig) {
	    super.onConfigurationChanged(newConfig);
	
		updateActionBarVisibility();
	}
	
	@Override
	protected void onPause() {
		super.onPause();
		
		cancelTask(task);
		task = null;
		
		if (game != null) {
			game.onPause();
		}
		
		delayedResume = false;
		
		if (glView != null) {
			glView.onPause();
		}
	}

	@Override
	protected void onResume() {
		super.onResume();
		
		SaveLoadActivity.game = game;
		
		onPrefsChanged();
		
		if (hasWindowFocus()) {
			delayedResume = false;			
			resumeGame();
		} else {
			delayedResume = true;			
		}
		
		if (glView != null) {
			glView.onResume();
		}
	}
	
	private void resumeGame() {
		if (game != null) {
			game.onResume();
		}		
	}
	
	protected void onPrefsChanged() {
		if (game == null) return;
		
		synchronized (game) {
			AndroidConfig config = game.getConfig();
			config.loadAndroid(this);
			
			game.onPrefsChanged();
			
			preferredOrientation = config.get(PREFERRED_ORIENTATION);
			actionBarAlgorithm = config.get(ACTION_BAR_ALGORITHM);
			setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
			updateActionBarVisibility();
		}		
	}
	
	private void updateActionBarVisibility() {
		boolean showActionBar = (actionBarAlgorithm == 1 ? false : true);
		boolean hasMenuKey = AndroidUtil.hasMenuKey(this);
		
		if (game != null) {
			Display display = getWindowManager().getDefaultDisplay();
			DisplayMetrics metrics = new DisplayMetrics();
			display.getMetrics(metrics);
			boolean landscape = (metrics.widthPixels > metrics.heightPixels);
			
			synchronized (game) {
				if (actionBarAlgorithm < 0) {
					if (supportsActionBar) {
						if (landscape) {
							showActionBar = false;
						}
						
						IImageState imageState = game.getNovel().getImageState();
						float verticalInches = metrics.heightPixels / metrics.ydpi;
						if (verticalInches >= 5f && metrics.heightPixels > 1.25f*imageState.getHeight()) {
							//Tablet-sized screen with pixels to spare for the action bar
							showActionBar = true;
						}
					} else {
						showActionBar = true;
					}
					game.setSoftMenuRequired(!showActionBar && !hasMenuKey && !landscape);
				} else {
					game.setSoftMenuRequired(!showActionBar && !hasMenuKey);
				}
			}
		}

		if (supportsActionBar) {
			AndroidUtil.setActionBarVisible(this, showActionBar);
		}
	}
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
	    MenuInflater inflater = getMenuInflater();
	    inflater.inflate(R.menu.options, menu);	    
	    if (!AndroidVN.allowSaveLoad) {
		    menu.removeItem(R.id.loadItem);
		    menu.removeItem(R.id.saveItem);
	    }
	    if (!allowSuperSkip) {
	    	menu.removeItem(R.id.superSkipItem);
	    }
	    return true;
	}
	
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
    	if (game == null || isTaskRunning(initTask) || isTaskRunning(task)) {
    		return true;
    	}
    	    	
		final int id = item.getItemId();
	    if (id == R.id.loadItem) {
			openLoadScreen();
			return true;
		} else if (id == R.id.saveItem) {
			openSaveScreen();
			return true;
		} else if (id == R.id.superSkipItem) {
			synchronized (game) {
				Novel novel = game.getNovel();
				novel.superSkip();
			}
			return true;
		} else if (id == R.id.textLogItem) {
			openTextLog();
			return true;
		} else if (id == R.id.autoReadItem) {
			synchronized (game) {
				game.toggleAutoRead();				
			}
			return true;
		} else if (id == R.id.prefsItem) {
			openPreferencesScreen();
			return true;
		} else if (id == R.id.restartItem) {
			askRestart();
			return true;
		} else if (id == R.id.quitItem) {
			askQuit();
			return true;
		} else {
			return super.onOptionsItemSelected(item);
		}
	}
	
	public void openTextLog() {
		synchronized (game) {
	    	try {
				game.getNovel().openTextLog();
			} catch (LuaException e) {
				Log.w("OpenTextLog", "Error calling textLog() function", e);
			}
		}
	}
	
	public void openPreferencesScreen() {
		if (game == null || isTaskRunning(initTask) || isTaskRunning(task)) return;
		
		String desc;
		synchronized (game) {
			Novel novel = game.getNovel();
			ITimer timer = novel.getTimer();
			desc = getString(R.string.pref_info_desc, timer.formatTime(timer.getTotalTime()));
		}
		
    	Intent intent = new Intent(this, getPrefsActivityClass(getResources()));
    	intent.putExtra(getString(R.string.pref_info), desc);
        startActivity(intent);
	}
	
	public void openLoadScreen() {
		if (game == null || isTaskRunning(initTask) || isTaskRunning(task)) return;

		SaveLoadActivity.game = game;

		Intent intent = new Intent(AndroidVN.this, SaveLoadActivity.class);
		intent.putExtra("save", false);
		startActivity(intent);
	}
	
	public void openSaveScreen() {
		if (game == null || isTaskRunning(initTask) || isTaskRunning(task)) return;
		
    	Resources res = getResources();    	
    	ScreenshotTask sst = new ScreenshotTask(this, msgHandler, res.getString(R.string.dialog_screenshot_message)) {
    		protected void onPostExecute(Screenshot ss) {
    			super.onPostExecute(ss);

    			if (task == this) {
    				task = null;
    			}
    			
    			SaveLoadActivity.game = game;
    			Intent intent = new Intent(AndroidVN.this, SaveLoadActivity.class);
    			intent.putExtra("save", true);

    			if (ss != null && ss.isAvailable()) {
    				int scale = 2;    				
    				
	    			File imgFile = new File(getFilesDir(), "~ss.jpg");
    				try {
    					ss.save(imgFile, scale);
    					intent.putExtra("screenshot", imgFile.getAbsolutePath());
    				} catch (FileNotFoundException fnfe) {
    					Log.w("Save", "Error saving screenshot to file", fnfe);
    				} catch (IOException ioe) {
    					//Ignore
    				}
    			}
    			    			
    			startActivity(intent);
    		}
    	};
    	task = sst.execute(game);
	}
	
	@Override
	public boolean onKeyUp(int keyCode, KeyEvent event) {
		if (game != null) {
			if (keyCode == KeyEvent.KEYCODE_BACK) {
				openTextLog();
				return true;
			} else if (game.isDebugSigned && !game.isVNDS && keyCode == KeyEvent.KEYCODE_SEARCH) {
				synchronized (game) {
					game.openScriptDebugJump();
				}
				return true;
			}
		}
		return super.onKeyUp(keyCode, event);
	}
	
	@Override
	public boolean onKeyLongPress(int keyCode, KeyEvent event) {
		if (game != null && keyCode == KeyEvent.KEYCODE_BACK) {
			askRestart();
			return true;
		}
		return super.onKeyLongPress(keyCode, event);
	}
		
	protected void askRestart() {
		new AlertDialog.Builder(this)
			.setTitle(R.string.dialog_restart_title)
			.setMessage(R.string.dialog_restart_message)
			.setPositiveButton(R.string.dialog_restart_ok, new Dialog.OnClickListener() {
				public void onClick(DialogInterface dialog, int which) {
					synchronized (game) {
						game.restart();			
					}
				}
			})
			.setNegativeButton(R.string.dialog_restart_cancel, null)
			.show();		
	}

	
	public void askQuit() {
		new AlertDialog.Builder(this)
			.setTitle(R.string.dialog_quit_title)
			.setMessage(R.string.dialog_quit_message)
			.setPositiveButton(R.string.dialog_quit_ok, new Dialog.OnClickListener() {
				public void onClick(DialogInterface dialog, int which) {
					finish();
				}
			})
			.setNegativeButton(R.string.dialog_quit_cancel, null)
			.show();		
	}
	
	@Override
	public void onWindowFocusChanged(boolean hasFocus) {
		super.onWindowFocusChanged(hasFocus);
		
		if (game != null) {
			synchronized (game) {
				if (delayedResume) {
					delayedResume = false;
					resumeGame();					
				}
				game.onFocusChanged(hasFocus);
			}
		}
	}
	
	@Override
	protected void onPrepareDialog(int id, Dialog dialog) {
		super.onPrepareDialog(id, dialog);
		
		setWindowFlags(dialog.getWindow());
	}
	
	@Override
	public void repaint() {
		final GLSurfaceView view = glView;
		if (view != null && renderer != null) {
			view.requestRender();
		}
	}
	
	public Handler getHandler() {
		return msgHandler;
	}
		
	@Override
	public void setRequestedOrientation(int orientation) {
		if (orientation == ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
			|| orientation == ActivityInfo.SCREEN_ORIENTATION_USER)
		{
			//Override user preference & undefined behaviors to use my preference
			orientation = preferredOrientation;
		}
		
		super.setRequestedOrientation(orientation);
	}
	
	private static void setWindowFlags(Window window) {
		window.addFlags(FLAG_FULLSCREEN|FLAG_KEEP_SCREEN_ON);
	}
	
	public static File getRootFolder(Intent intent, Resources res) {
		String rootFolder = intent.getStringExtra(BUNDLE_ID_ROOT);
		if (rootFolder == null) {
			rootFolder = new File(Environment.getExternalStorageDirectory(),
					res.getString(R.string.folder)).getAbsolutePath();
		}
		return new File(rootFolder);		
	}
	
	public static String getGameId(File root) {
		String gameId = root.getName();				
		return gameId.substring(gameId.lastIndexOf('.')+1);		
	}
	
	public static Class<?> getPrefsActivityClass(Resources res) {
		try {
			String s = res.getString(R.string.prefs_class);
			return Class.forName(s);
		} catch (ClassNotFoundException cnfe) {
			return PrefsActivity.class;
		}		
	}
	
}

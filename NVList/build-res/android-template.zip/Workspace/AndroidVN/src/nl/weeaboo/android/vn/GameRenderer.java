package nl.weeaboo.android.vn;

import static nl.weeaboo.android.gles.ESUtil.round;

import java.util.ArrayList;
import java.util.List;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

import nl.weeaboo.android.gles.ESManager;
import nl.weeaboo.android.gui.TextLayoutUtil;
import nl.weeaboo.styledtext.MutableTextStyle;
import nl.weeaboo.styledtext.TextStyle;
import nl.weeaboo.vn.BlendMode;
import nl.weeaboo.vn.IDrawBuffer;
import nl.weeaboo.vn.IDrawable;
import nl.weeaboo.vn.IImageDrawable;
import nl.weeaboo.vn.IImageState;
import nl.weeaboo.vn.ILayer;
import nl.weeaboo.vn.ITextDrawable;
import nl.weeaboo.vn.android.impl.DrawBuffer;
import nl.weeaboo.vn.android.impl.Novel;
import nl.weeaboo.vn.android.impl.Renderer;
import nl.weeaboo.vn.android.impl.TextDrawable;
import android.opengl.GLSurfaceView;
import android.util.FloatMath;

public class GameRenderer implements GLSurfaceView.Renderer {

	private final TextStyle vndsTextBoxStyle;
	private final TextStyle vndsNoEmbeddedTextBoxStyle;
	
	private Game game;
	private ESManager<?> glm;
	private EGLConfig config;
	private boolean initPending;
	private int rwidth, rheight;
	private boolean screenBoundsDirty;
	
	private final List<IDrawable> TEMP = new ArrayList<IDrawable>();
	
	public GameRenderer() {
		vndsNoEmbeddedTextBoxStyle = TextLayoutUtil.getDefaultStyle();

		MutableTextStyle mts = vndsNoEmbeddedTextBoxStyle.mutableCopy();
		mts.setFontName("vnds");
		vndsTextBoxStyle = mts.immutableCopy();
	}
	
	@Override
	public void onSurfaceCreated(GL10 gl, EGLConfig cfg) {
		config = cfg;
		screenBoundsDirty = true;				
		initPending = true;
	}

	@Override
	public void onSurfaceChanged(GL10 gl, int w, int h) {
		screenBoundsDirty = true;

		rwidth = w;
		rheight = h;
	}

	@Override
	public void onDrawFrame(GL10 gl) {		
		if (game == null) {
			return;
		}
		
        synchronized (game) {
			Novel novel = game.getNovel();
			if (novel == null) {
				return; //Game is disposed or not initialized
			}

			if (glm == null) {
				glm = game.getGLFactory().newGLManager(game.getGLResCache(), game.getShaderStore());				
			}
			glm.init(gl, initPending);
	        glm.initProjection(rwidth, rheight);			
	        if (initPending) {
	        	if (config == null) {
	        		return; //Can't init yet
	        	}
        		initPending = false;
        		game.initGL(glm, config, rwidth, rheight);        		
        	}
			game.updateGL(glm);			
	        
			int renderAnchor = game.getRenderAnchor();
			int halign = ((renderAnchor-1)%3)-1;
			int valign = ((9-renderAnchor)/3)-1;
			float vwidth = game.getWidth();
			float vheight = game.getHeight();
			
	        IImageState is = novel.getImageState();
			
			float scale = Math.min(rwidth/vwidth, rheight/vheight);
			float invScale = 1f / scale;
	        
	        //Be very careful that (isx,isy,isw,ish) falls entirely within the OpenGL window	        
	        int isw = Math.max(0, Math.min(rwidth, round(vwidth * scale)));
	        int ish = Math.max(0, Math.min(rheight, round(vheight * scale)));			
	        int isx = (halign < 0 ? 0 : (halign > 0 ? rwidth-isw : (rwidth-isw)/2));
	        int isy = (valign < 0 ? 0 : (valign > 0 ? rheight-ish : (rheight-ish)/2));
	        if (valign == 0) {
	        	//Must not allow script override here to avoid relayout of the render area
	        	int anchor = game.getTextBoxAnchor(false);
	        	/*if (anchor == -2) {
	        		isy = Math.min(rheight-ish, rheight/2);
	        	} else*/ if (anchor == 2) {
	        		isy = Math.max(0, rheight/2 - ish);
	        	}
	        }
	        
	        game.setScreenBounds(isx, isy, isw, ish, rwidth, rheight);
	        
	        //System.out.println(isx + " " + isy + " " + isw + " " + ish);
	        
	        TextDrawable textBox = (TextDrawable)novel.getTextState().getTextDrawable();
	        int textboxAnchor = 2;
	        if (textBox != null) {
	        	if (game.isVNDS) {
	        		if (game.useEmbeddedFonts) {
	        			textBox.setDefaultStyle(vndsTextBoxStyle);
	        		} else if (textBox.getDefaultStyle() == vndsTextBoxStyle) {
	        			textBox.setDefaultStyle(vndsNoEmbeddedTextBoxStyle);
	        		}
	        	}
				//textBox.setTextSpeed(999999);
				textBox.setClipEnabled(false);
				//textBox.setZ((short)-1000);
				
				//Calculate textbox dimensions in screen coords
		        int tbpad = round(.02f * ish * game.getDisplayDensity() * game.getTextScale());
		        int sl = textBox.getStartLine();
		        int tbTwoLineHeight = round(scale * textBox.getTextHeight(sl, sl+game.minVisibleLines));
		        int tbminh = tbTwoLineHeight + tbpad * 2;
		        
		        //Set size to minimum and grow to fill any available space
		        int tbh = tbminh;
				textboxAnchor = game.getTextBoxAnchor(true);
		        if (textboxAnchor == 0) {
		        	tbh = Math.max(tbh, ish);
		        } else if (textboxAnchor == 2) {
		        	tbh = Math.max(tbh, rheight-(isy+ish));
		        }
		        
		        //Sets the textbox position in screen coords
		        int tby = 0;
		        switch (textboxAnchor) {
		        case -2: tby = isy - tbh; break;
		        case -1: tby = isy; break;
		        case  0: tby = isy; break;
		        case  1: tby = isy + ish - tbh; break;
		        case  2: tby = isy + ish; break;
		        }
		        tby = Math.max(0, Math.min(rheight-tbh, tby));
		        
		        //Apply changed textbox properties
		        textBox.setPadding(tbpad * invScale);
		        textBox.setSize(is.getWidth(), FloatMath.ceil(tbh * invScale));
				textBox.setPos(0, (tby-isy) * invScale);
		        
		        if (textBox.getY() >= is.getHeight()) {
		        	textBox.setBlendMode(BlendMode.OPAQUE);
		        	if (textBox.getBackgroundColorRGB() == 0) {
		        		textBox.setBackgroundAlpha(0.0);
		        	} else {
		        		textBox.setBackgroundAlpha(1.0);
		        	}
		        } else {
			        int textBoxAlpha = game.getTextBoxAlpha();
			        textBox.setBlendMode(BlendMode.DEFAULT);
		        	textBox.setBackgroundAlpha(textBoxAlpha/255f);
		        }
	        }
	        	        
			Renderer r = game.getRenderer(glm);
			DrawBuffer buffer = r.getDrawBuffer();
			buffer.reset();
			ILayer root = is.getRootLayer();
	        if (!screenBoundsDirty) {
	        	if (game.privacyMode) {
	        		drawPrivacyMode(root, textBox, buffer);
	        	} else {
					root.draw(buffer);				
	        	}

		        int dw = 99 * (int)vwidth / 100;
		        int dh = (int)vheight;

		        int dir;
		        float y;
		        if (textboxAnchor <= 0) {
		        	dir = -1;
		        	y = (rheight-isy) * invScale;
		        } else {
		        	dir = 1;
		        	y = -isy * invScale;
		        }
		        
		        TEMP.add(game.getClockDrawable());
		        TEMP.add(game.getSuperSkipDrawable());
		        TEMP.add(game.getAutoReadDrawable());
	        	TEMP.add(game.getSoftMenuDrawable());
	        	drawVertical(buffer, dir, y, dw, dh, TEMP);
	        	TEMP.clear();
	        }
			r.render(root, buffer);
	        buffer.reset();
		}
        
        if (screenBoundsDirty) {
        	game.repaint();
        }        
        screenBoundsDirty = false;
	}
	
	private static void drawPrivacyMode(ILayer layer, ITextDrawable textBox, DrawBuffer buffer) {
		IDrawable[] drawables = layer.getContentsRecursive();
		boolean[] oldVisible = new boolean[drawables.length];
		for (int n = 0; n < drawables.length; n++) {
			IDrawable d = drawables[n];
			oldVisible[n] = d.isVisible();
			boolean isImage = (d instanceof IImageDrawable);
			d.setVisible(!isImage || d == textBox.getCursor());
		}
		
		layer.draw(buffer);
		
		for (int n = 0; n < drawables.length; n++) {
			drawables[n].setVisible(oldVisible[n]);
		}
	}
	
	private void drawVertical(IDrawBuffer buf, int dir, double y, int w, int h, Iterable<IDrawable> ds) {
		if (dir == 0) {
			throw new IllegalArgumentException("dir must be nonzero");
		}
		
		final IDrawable softMenu = game.getSoftMenuDrawable();		
		int pad = dir * (Math.min(w, h) >> 6);
		y += pad;
		for (IDrawable d : ds) {
			if (d == null) continue;

        	d.setRenderEnv(buf.getEnv());

			double dy;
			if (d instanceof ITextDrawable) {
				ITextDrawable td = (ITextDrawable)d;
				td.setSize(w, h);
				dy = td.getTextHeight();
				//td.setSize(td.getTextWidth(), td.getTextHeight());
			} else {
				dy = d.getHeight();
			}
			double newY = y + dir * dy;

			d.setPos(w - d.getWidth(), dir > 0 ? y : newY);
			//System.err.println(d.getX()+","+d.getY()+","+d.getWidth()+","+d.getHeight());
			
	        if (d != softMenu || game.getSoftMenuMode() != SoftMenuMode.DISABLED) {
	        	d.draw(buf);
	        }
			y = newY + pad;
		}
	}
			
	public Game getGame() {
		return game;
	}
	
	public void setGame(Game g) {
		if (game != g) {
			initPending = true;
			game = g;
			
			if (game != null) {
				game.repaint();
			}
		}
	}
	
}

package nl.weeaboo.android.gui;

import nl.weeaboo.styledtext.StyledText;
import nl.weeaboo.styledtext.TextAttribute;
import nl.weeaboo.styledtext.TextStyle;
import android.graphics.Typeface;
import android.text.Layout;
import android.text.SpannableString;
import android.text.TextPaint;
import android.text.style.AlignmentSpan;
import android.text.style.ForegroundColorSpan;
import android.text.style.MetricAffectingSpan;
import android.text.style.RelativeSizeSpan;
import android.text.style.StyleSpan;
import android.text.style.UnderlineSpan;

public class TextStyleParser {

	private static final float SIZE_SCALE = 1f / 30f;
	
	//Functions	
	public static SpannableString toSpannableString(FontManager fm, StyledText stext) {
		String text = stext.toString();
		SpannableString ss = new SpannableString(text);
		
		//Set default font span
		ss.setSpan(new FontManagerCharacterStyle(fm, null), 0, ss.length(), 0);
		
		TextStyle oldStyle = null;
		int written = 0;
		for (int n = 0; n < stext.length(); n++) {
			TextStyle curStyle = stext.getStyle(n);
			if (curStyle != oldStyle) {
				if (oldStyle != null) {
					setStyle(fm, ss, oldStyle, written, n);
				}
				written = n;
				oldStyle = curStyle;
			}			
		}
		if (stext.length() > written && oldStyle != null) {
			setStyle(fm, ss, oldStyle, written, stext.length());			
		}
		return ss;
	}
	
	protected static void setStyle(FontManager fm, SpannableString ss,
			TextStyle style, int start, int end)
	{
		if (style.hasProperty(TextAttribute.fontName)) {
			//ss.setSpan(new TypefaceSpan(style.getFontName()), start, end, 0);
			
			//System.out.println("Font: " + start + "->" + end + ": " + style.getFontName() + " = " + fm.getFont(style.getFontName()));			
			ss.setSpan(new FontManagerCharacterStyle(fm, style.getFontName()), start, end, 0);
		}
		if (style.hasProperty(TextAttribute.fontStyle)) {
			int s = Typeface.NORMAL;
			
			switch (style.getFontStyle()) {
			case PLAIN: s = Typeface.NORMAL; break;
			case BOLD: s = Typeface.BOLD; break;
			case ITALIC: s = Typeface.ITALIC; break;
			case BOLDITALIC: s = Typeface.BOLD_ITALIC; break;
			}
			
			ss.setSpan(new StyleSpan(s), start, end, 0);
		}
		if (style.hasProperty(TextAttribute.fontSize)) {
			float fs = (float)style.getFontSize();
			ss.setSpan(new RelativeSizeSpan(SIZE_SCALE * fs), start, end, 0);
		}
		if (style.hasProperty(TextAttribute.anchor)) {
			int anchor = style.getAnchor();
			if (anchor == 1 || anchor == 4 || anchor == 7) {
				ss.setSpan(new AlignmentSpan.Standard(Layout.Alignment.ALIGN_NORMAL), start, end, 0);
			} else if (anchor == 2 || anchor == 5 || anchor == 8) {
				ss.setSpan(new AlignmentSpan.Standard(Layout.Alignment.ALIGN_CENTER), start, end, 0);
			} else if (anchor == 3 || anchor == 6 || anchor == 9) {
				ss.setSpan(new AlignmentSpan.Standard(Layout.Alignment.ALIGN_OPPOSITE), start, end, 0);
			}
		}
		if (style.hasProperty(TextAttribute.color)) {
			ss.setSpan(new ForegroundColorSpan(style.getColor()), start, end, 0);
		}
		if (style.hasProperty(TextAttribute.underline)) {
			if (style.isUnderlined()) {
				ss.setSpan(new UnderlineSpan(), start, end, 0);
			}
		}
		if (style.hasOutline()) {
			//float size = SIZE_SCALE * style.getOutlineSize();
			//int color = style.getOutlineColor();
			//TODO: Implement 
		}
		if (style.hasShadow()) {
			final int color = style.getShadowColor();
			
			float dx = SIZE_SCALE * (float)style.getShadowDx();
			if (dx > .001f) dx = Math.max(1f, dx);
			else if (dx < -.001f) dx = Math.min(-1f, dx);
				
			float dy = SIZE_SCALE * (float)style.getShadowDy();
			if (dy > .001f) dy = Math.max(1f, dy);
			else if (dy < -.001f) dy = Math.min(-1f, dy);
			
			ss.setSpan(new ShadowSpan(dx, dy, color), start, end, 0);
		}		
	}
	
	//Inner Classes
	private static class FontManagerCharacterStyle extends MetricAffectingSpan {

		private final FontManager fm;
		private final String fontName;
		
		public FontManagerCharacterStyle(FontManager fm, String fontName) {
			this.fm = fm;
			this.fontName = fontName;
		}
		
		protected void updateState(TextPaint paint) {
			int oldStyle = 0;
	        Typeface oldTypeface = paint.getTypeface();
	        if (oldTypeface != null) oldStyle = oldTypeface.getStyle();

	        Typeface tf = fm.getFont(fontName, oldStyle);
	        
	        //Our requested font may not have the requested style. Fake if needed.
	        int fake = oldStyle & ~tf.getStyle();
	        if ((fake & Typeface.BOLD) != 0) {
	            paint.setFakeBoldText(true);
	        }
	        if ((fake & Typeface.ITALIC) != 0) {
	            paint.setTextSkewX(-0.25f);
	        }
	        paint.setTypeface(tf);			
		}
		
		@Override
		public void updateMeasureState(TextPaint paint) {
			updateState(paint);
		}
		
		@Override
		public void updateDrawState(TextPaint paint) {
			updateState(paint);
		}
		
	}
	
}

package nl.weeaboo.android.nvlist;

import java.util.ArrayList;
import java.util.List;

import nl.weeaboo.android.vn.PrefsActivity;
import nl.weeaboo.android.vn.R;

public class NVListPrefsActivity extends PrefsActivity {

	public NVListPrefsActivity() {
		super(removeList());
	}
	
	//Functions
	private static int[] removeList() {
		List<Integer> list = new ArrayList<Integer>();
		list.add(R.string.pref_embedded_fonts); //NVList always uses embedded fonts?
		list.add(R.string.pref_savemode);       //VNDS-specific quicksave mode
		list.add(R.string.pref_text_stream);    //VNDS-specific text stream preference
		
		int[] result = new int[list.size()];
		for (int n = 0; n < result.length; n++) {
			result[n] = list.get(n);
		}
		return result;
	}
	
	//Getters
	
	//Setters
	
}

package nl.weeaboo.android.vn;

public class GameNotFoundException extends Exception {

	private static final long serialVersionUID = 1L;

	public GameNotFoundException() {
	}

	public GameNotFoundException(String detailMessage) {
		super(detailMessage);
	}

	public GameNotFoundException(Throwable throwable) {
		super(throwable);
	}

	public GameNotFoundException(String detailMessage, Throwable throwable) {
		super(detailMessage, throwable);
	}

}

package nl.weeaboo.android;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;

import nl.weeaboo.common.Dim;
import nl.weeaboo.filesystem.IFileSystem;
import nl.weeaboo.image.FileResolutionOption;
import nl.weeaboo.image.FileResolutionPicker;
import nl.weeaboo.obfuscator.IObfuscator;
import nl.weeaboo.zip.FileRecord;
import nl.weeaboo.zip.ZipArchive;
import android.content.res.AssetFileDescriptor;
import android.content.res.AssetManager;
import android.util.Log;

public class AssetZipArchive extends ZipArchive {

	private static final String TAG = "AssetZipArchive";

	private final File cacheFolder;
	private final int versionCode;
	private final IObfuscator obfuscator;

	private AssetManager assets;
		
	public AssetZipArchive(File cacheFolder, final int versionCode, IObfuscator obfuscator) {
		this.cacheFolder = cacheFolder;
		this.versionCode = versionCode;
		this.obfuscator = obfuscator;		
	}

	//Functions
	private boolean tryReadCache(File file) {
		InputStream in = null;
		try {
			in = new BufferedInputStream(new FileInputStream(file), 8<<10);;
			return tryReadCache(in);
		} catch (FileNotFoundException e) {
			return false;
		} catch (IOException e) {
			Log.w(TAG, "Error reading assets cache", e);
			return false;
		} catch (ClassNotFoundException e) {
			Log.w(TAG, "Error reading assets cache", e);
			return false;
		} finally {
			try {
				if (in != null) in.close();
			} catch (IOException e) {
				//Ignore
			}
		}
	}
	private boolean tryReadCache(InputStream raw) throws IOException, ClassNotFoundException {
		ObjectInputStream in = new ObjectInputStream(raw);
		int storedVersion = in.readInt();
		if (storedVersion != versionCode || versionCode == 0) {
			return false;
		}
		records = (FileRecord[])in.readObject();
		return records != null;
	}
	
	private void writeCache(File file) throws IOException {
		OutputStream out = new BufferedOutputStream(new FileOutputStream(file), 8<<10);
		try {
			writeCache(out);
		} finally {
			out.close();
		}
	}
	private void writeCache(OutputStream raw) throws IOException {
		ObjectOutputStream out = new ObjectOutputStream(raw);
		out.writeInt(versionCode);
		out.writeObject(records);
		out.flush();
	}
	
	public void open(AssetManager assets) throws IOException {
		this.assets = assets;
		
		final File cacheF = new File(cacheFolder, "assets.list");		
		if (!tryReadCache(cacheF)) {
			Collection<FileRecord> rs = new ArrayList<FileRecord>(); 
			gatherRecords(rs, assets, "", 256, 8);
			records = rs.toArray(new FileRecord[rs.size()]);
			Arrays.sort(records);
			
			//System.out.println(Arrays.toString(records));
			
			try {
				writeCache(cacheF);
			} catch (IOException ioe) {
				Log.w(TAG, "Error writing assets cache", ioe);
			}
		}
	}
	
	/**
	 * The <code>subfolderLimit</code> limits the search depth to a maximum
	 * number of subfolders. The <code>fileLimit</code> is not a hard limit for
	 * the total number of files that may be gathered. It's a hard limit on the
	 * number of files that may be gathered from a single folder however. At
	 * each recursive call, the fileLimit is decreased by an undefined amount.
	 */
	private static int gatherRecords(Collection<FileRecord> out, AssetManager assets,
			String folder, int fileLimit, int subfolderLimit) throws IOException
	{
		String prefix = folder;
		if (prefix.length() > 0) prefix += "/";
		
		int filesAdded = 0;
		String[] files = assets.list(folder);
		for (String file : files) {
			if (filesAdded >= fileLimit) {
				break;
			}
			
			String path = prefix + file;			
			//System.out.println(path);			
			if (file.contains(".")) {
				long offset = 0, length = 0;
				
				try {
					AssetFileDescriptor afd = assets.openFd(path);
					try {
						offset = afd.getStartOffset();
						length = afd.getLength();
					} finally {
						afd.close();
					}
				} catch (IOException ioe) {
					InputStream in = assets.open(path);
					try {
						//Read entire file to get the uncompressed length (sigh)
						long s;
						while ((s = in.skip(2048)) > 0) {
							length += s;
						}
						while (in.read() >= 0) {
							length++;
						}
					} finally {
						in.close();
					}
				}

				byte[] bytes = path.getBytes("UTF-8");
				out.add(new FileRecord(bytes, 0, bytes.length, offset, length, length, (byte)0, 0));
				filesAdded++;
			} else {
				byte[] bytes = (path + "/").getBytes("UTF-8");
				out.add(new FileRecord(bytes, 0, bytes.length, 0, 0, 0, (byte)0, 0));
				filesAdded++;
				
				if (subfolderLimit > 0) {
					try {
						//Recurse
						int lim = Math.max(fileLimit / 2, fileLimit - files.length);
						gatherRecords(out, assets, path, lim, subfolderLimit-1);
					} catch (IOException ioe) {
						Log.w(TAG, "Error accessing assets", ioe);
					}
				}
			}
		}
		
		return filesAdded;
	}
	
	public static FileResolutionPicker createAssetFolderPicker(IFileSystem fs, AssetManager assets,
			String base, Dim baseSize) throws IOException
	{
		List<FileResolutionOption> options = new ArrayList<FileResolutionOption>();
		if (base.endsWith("/")) base = base.substring(0, base.length()-1);
		String assetBaseFolder = (base.indexOf('/') > 0 ? base.substring(0, base.lastIndexOf('/')) : "");
		for (String folder : assets.list(assetBaseFolder)) {
			if (!folder.startsWith(base)) {
				continue;
			}
			
			FileResolutionOption option = FileResolutionPicker.optionFromFolder(fs, folder, base, baseSize);
			if (option != null) {
				options.add(option);
			}
		}
		
		FileResolutionPicker resolutionPicker = new FileResolutionPicker();
		resolutionPicker.addOptions(options);
		return resolutionPicker;		
	}
	
	//Getters
	public AssetManager getAssets() {
		return assets;
	}
	
	@Override
	public InputStream getInputStream(String filename) throws IOException {
		if (assets != null) {
			return assets.open(filename);
		} else {
			InputStream in = super.getInputStream(filename);
			if (in != null && obfuscator != null && obfuscator.allowEncrypt(filename)) {
				in = obfuscator.decryptStream(in);
			}
			return in;
		}
	}
	
	//Setters
	
}

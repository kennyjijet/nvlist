package nl.weeaboo.vn.android.impl;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import nl.weeaboo.filesystem.IFileSystem;
import nl.weeaboo.settings.INIFile;
import nl.weeaboo.vn.impl.base.BaseNovelConfig;
import nl.weeaboo.vn.vnds.VNDSUtil;
import android.content.res.AssetManager;

public class NovelConfig extends BaseNovelConfig {

	private NovelConfig(INIFile file) {
		super(file);
	}
	
	//Functions
	public static NovelConfig fromFolder(File folder) throws IOException {		
		boolean isVNDS = VNDSUtil.isVNDSGame(folder);
		
		INIFile iniFile = new INIFile();
		if (isVNDS) {
			iniFile.read(new File(folder, "info.txt"));
			if (iniFile.get("id") == null) iniFile.put("id", folder.getName());
			if (iniFile.get("title") == null) iniFile.put("title", folder.getName());
		} else {
			iniFile.read(new File(folder, "game.ini"));			
		}
		return fromIniFile(iniFile, isVNDS);
	}
	
	public static NovelConfig fromAsset(AssetManager assets, boolean isVNDS) throws IOException {
		InputStream in = assets.open("game.ini");
		try {
	    	BufferedReader bin = new BufferedReader(new InputStreamReader(in, "UTF-8"));
	    	INIFile iniFile = new INIFile();
	    	iniFile.read(bin);        	
			return fromIniFile(iniFile, isVNDS);
		} finally {
			in.close();
		}
	}
	public static NovelConfig fromFileSystem(IFileSystem fs, boolean isVNDS) throws IOException {
    	InputStream in = fs.newInputStream("game.ini");
		try {
	    	BufferedReader bin = new BufferedReader(new InputStreamReader(in, "UTF-8"));
	    	INIFile iniFile = new INIFile();
	    	iniFile.read(bin);        	
			return fromIniFile(iniFile, isVNDS);
		} finally {
			in.close();
		}
	}
	
	public static NovelConfig fromIniFile(INIFile iniFile, boolean isVNDS) {
		if (isVNDS) {
			iniFile.putInt("width", 256);
			iniFile.putInt("height", 192);
		}
		
		return new NovelConfig(iniFile);
	}
	
	//Getters
	
	//Setters
	
}

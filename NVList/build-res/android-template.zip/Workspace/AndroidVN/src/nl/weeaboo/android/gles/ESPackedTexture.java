package nl.weeaboo.android.gles;

import java.nio.IntBuffer;

import nl.weeaboo.common.Dim;
import nl.weeaboo.common.Rect;
import nl.weeaboo.gl.GLLog;
import nl.weeaboo.gl.tex.ITextureData;
import nl.weeaboo.gl.tex.PackedTexture;
import nl.weeaboo.gl.tex.TextureId;
import android.graphics.Bitmap;

public class ESPackedTexture extends PackedTexture {

	private static final long serialVersionUID = 1L;
	
	private final ESTextureStore store;
	private ESTextureData data;
	
	public ESPackedTexture(TextureId id, ESTextureStore s, Dim texSize) {
		super(id, s, texSize);
		
		this.store = s;
	}

	@Override
	public ITextureData getPixels() {
		int tw = getTexWidth();
		int th = getTexHeight();
		if (data == null) {
			IntBuffer buf = store.newIntBuffer(tw * th);
			data = store.newARGB8TextureData(buf, false, tw, th);
		}
		return data;
	}

	@Override
	protected int[] getPixelsARGB(int x, int y, int w, int h) {
		ITextureData data = getPixels();
		int[] result = new int[w * h];
		data.getPixelsARGB8(IntBuffer.wrap(result), x, y, w, h);
		return result;
	}
	
	@Override
	public ITextureData peekPixels() {
		return data;
	}

	@Override
	protected void setPixelsARGB(Rect r, int[] argb) {
		getPixels(); //Force init of data
		
		Bitmap bitmap = data.getBitmap();
		if (bitmap == null) {
			GLLog.w("Error in ESPackedTexture.setPixelsARGB(), underlying texture data returned a null Bitmap");
			return;
		}
		
		int sscan = r.w;
		if (argb == null) {
			argb = new int[r.w];			
			sscan = 0; //Allows us to fill r.w*r.h with our buffer of length r.w
		}
		bitmap.setPixels(argb, 0, sscan, r.x, r.y, r.w, r.h);
		
		onPixelsChanged(r);		
	}

}

package nl.weeaboo.android.gles;

import static javax.microedition.khronos.opengles.GL10.GL_BLEND;
import static javax.microedition.khronos.opengles.GL10.GL_COLOR_ARRAY;
import static javax.microedition.khronos.opengles.GL10.GL_FLOAT;
import static javax.microedition.khronos.opengles.GL10.GL_MODULATE;
import static javax.microedition.khronos.opengles.GL10.GL_TEXTURE_2D;
import static javax.microedition.khronos.opengles.GL10.GL_TEXTURE_COORD_ARRAY;
import static javax.microedition.khronos.opengles.GL10.GL_TEXTURE_ENV;
import static javax.microedition.khronos.opengles.GL10.GL_TEXTURE_ENV_MODE;
import static javax.microedition.khronos.opengles.GL10.GL_TRIANGLES;
import static javax.microedition.khronos.opengles.GL10.GL_TRIANGLE_STRIP;
import static javax.microedition.khronos.opengles.GL10.GL_UNSIGNED_BYTE;
import static javax.microedition.khronos.opengles.GL10.GL_VERTEX_ARRAY;
import static nl.weeaboo.android.gles.ESUtil.round;

import java.nio.Buffer;
import java.nio.FloatBuffer;

import javax.microedition.khronos.opengles.GL10;
import javax.microedition.khronos.opengles.GL11;
import javax.microedition.khronos.opengles.GL11Ext;

import nl.weeaboo.gl.AbstractGLDraw;
import nl.weeaboo.gl.DefaultGLBufferAllocator;
import nl.weeaboo.gl.GLBlendMode;
import nl.weeaboo.gl.GLBufferAllocator;
import nl.weeaboo.gl.GLInfo;
import nl.weeaboo.gl.GLManager;
import nl.weeaboo.gl.shader.GLShader;
import nl.weeaboo.gl.tex.GLTexture;

public class ES1Draw extends AbstractGLDraw {

	private final FloatBuffer texcoordBuf;
	private final FloatBuffer colorBuf;
	private final FloatBuffer vertexBuf;
	private final int[] crop;
	
	private GL10 gl;
	private GLInfo glInfo;
	
	public ES1Draw() {
		GLBufferAllocator alloc = new DefaultGLBufferAllocator();
		texcoordBuf = alloc.newFloatBuffer(8);
		colorBuf    = alloc.newFloatBuffer(12);
		vertexBuf   = alloc.newFloatBuffer(8);
		crop = new int[4];
		
		glInfo = new GLInfo();
	}
	
	@Override
	public void init(GLManager glm, boolean contextChanged) {
		gl = ES1Manager.getGL(glm);
		glInfo = glm.getGLInfo();

		super.init(glm, contextChanged);		
	}
	
	@Override
	public void fillRect(float x, float y, float w, float h, float u, float v, float uw, float vh) {
		texcoordBuf.put(u   ); texcoordBuf.put(v   );
		texcoordBuf.put(u+uw); texcoordBuf.put(v   );
		texcoordBuf.put(u   ); texcoordBuf.put(v+vh);
		texcoordBuf.put(u+uw); texcoordBuf.put(v+vh);
		texcoordBuf.rewind();
		
		vertexBuf.put(x  ); vertexBuf.put(y  );
		vertexBuf.put(x+w); vertexBuf.put(y  );
		vertexBuf.put(x  ); vertexBuf.put(y+h);
		vertexBuf.put(x+w); vertexBuf.put(y+h);
		vertexBuf.rewind();
		
		gl.glEnableClientState(GL_VERTEX_ARRAY);
	    gl.glEnableClientState(GL_TEXTURE_COORD_ARRAY);
	    gl.glVertexPointer(2, GL_FLOAT, 0, vertexBuf);
	    gl.glTexCoordPointer(2, GL_FLOAT, 0, texcoordBuf);
	    gl.glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);
	    gl.glDisableClientState(GL_VERTEX_ARRAY);
	    gl.glDisableClientState(GL_TEXTURE_COORD_ARRAY);
	}

	@Override
	public void clearRect(float x, float y, float w, float h, float r, float g, float b) {
		for (int n = 0; n < 4; n++) {
			colorBuf.put(r);
			colorBuf.put(g);
			colorBuf.put(b);
		}
		colorBuf.rewind();
		
		vertexBuf.put(x);     vertexBuf.put(y);
		vertexBuf.put(x + w); vertexBuf.put(y);
		vertexBuf.put(x);     vertexBuf.put(y + h);
		vertexBuf.put(x + w); vertexBuf.put(y + h);
		vertexBuf.rewind();
		
		gl.glEnableClientState(GL_VERTEX_ARRAY);
	    gl.glEnableClientState(GL_COLOR_ARRAY);
	    gl.glColorPointer(3, GL_FLOAT, 0, colorBuf);
	    gl.glVertexPointer(2, GL_FLOAT, 0, vertexBuf);
	    gl.glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);
	    gl.glDisableClientState(GL_VERTEX_ARRAY);
	    gl.glDisableClientState(GL_COLOR_ARRAY);
	}

	@Override
	public void drawRangeElements(Buffer vertexBuf, Buffer texcoordBuf, Buffer colorBuf, int mode,
			int start, int end, int count, int glIndexType, Buffer indexBuf)
	{
		gl.glEnableClientState(GL_VERTEX_ARRAY);
		gl.glEnableClientState(GL_TEXTURE_COORD_ARRAY);
		gl.glEnableClientState(GL_COLOR_ARRAY);

		gl.glVertexPointer(2, GL_FLOAT, 0, vertexBuf);
		gl.glTexCoordPointer(2, GL_FLOAT, 0, texcoordBuf);
		gl.glColorPointer(4, GL_UNSIGNED_BYTE, 0, colorBuf);
				
		gl.glDrawElements(GL_TRIANGLES, count, glIndexType, indexBuf);
		
		gl.glDisableClientState(GL_VERTEX_ARRAY);
		gl.glDisableClientState(GL_TEXTURE_COORD_ARRAY);
		gl.glDisableClientState(GL_COLOR_ARRAY);
	}

	public void drawTexRecti(int texId, int texW, int texH,
			int ix, int iy, int iw, int ih, double u, double v, double uw, double vh)
	{
		if (!glInfo.isDrawTexSupported() || !(gl instanceof GL11Ext)) {
			throw new RuntimeException("drawTexRect is not supported on this hardware");
		}
		if (iw == 0 || ih == 0) {
			return; 
		}
		
		GL11 gl11 = (GL11)gl;
		GL11Ext gl11Ext = (GL11Ext)gl;
		
		if (iw < 0) {
			ix += iw;  iw = -iw; u += uw; uw = -uw;
		}		
		if (ih < 0) {
			iy += ih;  ih = -ih; v += vh; vh = -vh;
		}
		
		if (texId != 0) {
			gl.glEnable(GL_TEXTURE_2D);
			gl.glBindTexture(GL_TEXTURE_2D, texId);
			gl.glTexEnvx(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);	        	        
			
			crop[0] = round(u); crop[1] = round(v); crop[2] = round(uw); crop[3] = round(vh);
			gl11.glTexParameteriv(GL_TEXTURE_2D, GL11Ext.GL_TEXTURE_CROP_RECT_OES, crop, 0);
		} else {
			gl.glDisable(GL_TEXTURE_2D);			
		}		
		gl11Ext.glDrawTexiOES(ix, iy, 0, iw, ih);
	}	
	
	public void drawTexRectf(int texId, int texW, int texH,
			double x, double y, double w, double h, double u, double v, double uw, double vh)
	{
		if (!glInfo.isDrawTexSupported() || !(gl instanceof GL11Ext)) {
			throw new RuntimeException("drawTexRect is not supported on this hardware");
		}
		if (w == 0 || h == 0) {
			return; 
		}
		
		GL11 gl11 = (GL11)gl;
		GL11Ext gl11Ext = (GL11Ext)gl11;
		
		if (w < 0) {
			x += w;  w = -w; u += uw; uw = -uw;
		}		
		if (h < 0) {
			y += h;  h = -h; v += vh; vh = -vh;
		}
		
		if (texId != 0) {
			gl11.glEnable(GL_TEXTURE_2D);
			gl11.glBindTexture(GL_TEXTURE_2D, texId);
			gl11.glTexEnvx(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);	        	        
			
			crop[0] = round(u); crop[1] = round(v); crop[2] = round(uw); crop[3] = round(vh);	
			gl11.glTexParameteriv(GL_TEXTURE_2D, GL11Ext.GL_TEXTURE_CROP_RECT_OES, crop, 0);
		} else {
			gl11.glDisable(GL_TEXTURE_2D);
		}
		gl11Ext.glDrawTexfOES((float)x, (float)y, 0, (float)w, (float)h);
	}
	
	@Override
	public void pushMatrix() {
		gl.glPushMatrix();
	}

	@Override
	public void popMatrix() {
		gl.glPopMatrix();
	}

	@Override
	public void multMatrixf(float[] m, int offset) {
		gl.glMultMatrixf(m, offset);
	}
	
	@Override
	public void translate(float x, float y) {
		gl.glTranslatef(x, y, 0f);
	}

	@Override
	public void scale(float x, float y) {
		gl.glScalef(x, y, 1f);
	}

	@Override
	protected void onColorChanged(float[] colorStack, int off) {
		float r = colorStack[off  ];
		float g = colorStack[off+1];
		float b = colorStack[off+2];
		float a = colorStack[off+3];
		gl.glColor4f(a * r, a * g, a * b, a);
	}

	@Override
	protected void glSetBlendMode(GLBlendMode mode) {
		if (mode == null) {
			gl.glDisable(GL_BLEND);
		} else {
			gl.glEnable(GL_BLEND);
			gl.glBlendFunc(mode.sfactor, mode.dfactor);
		}
	}

	@Override
	protected void glSetShader(GLShader sh) {
		if (sh != null) {
			throw new RuntimeException("Not implemented");
		}
	}

	@Override
	protected void glSetTexture(GLTexture tex) {
		if (tex == null || tex.glId() == 0) {
			gl.glDisable(GL_TEXTURE_2D);
		} else {
			gl.glEnable(GL_TEXTURE_2D);
			gl.glBindTexture(GL_TEXTURE_2D, tex.glId());
			tex.use();
		}
	}

}

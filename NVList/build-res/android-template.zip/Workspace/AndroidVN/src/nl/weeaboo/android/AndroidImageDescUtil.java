package nl.weeaboo.android;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Map;

import javax.xml.parsers.ParserConfigurationException;

import nl.weeaboo.media.image.ImageDesc;
import nl.weeaboo.media.image.ImageDescUtil;

import org.xml.sax.SAXException;

import android.content.res.AssetManager;
import android.util.Log;

public final class AndroidImageDescUtil {

	/*
	public static void fromResourceManager(Map<String, ImageDesc> out,
			ResourceManager rm, String baseFolder)
		throws IOException, ParserConfigurationException, SAXException
	{
		List<String> folders = new ArrayList<String>();
		folders.add(baseFolder);
		folders.addAll(rm.getSubFolders(baseFolder, true));
		
		for (String folder : folders) {
			String path = folder + "img.xml";			
			if (rm.getFileExists(path)) {
				String prefix = folder;
				if (prefix.length() > baseFolder.length()+1) {
					prefix = prefix.substring(baseFolder.length());
					if (prefix.startsWith("/")) {
						prefix = prefix.substring(1);
					}
				} else {
					prefix = "";
				}
				
				InputStream in = null;
				try {
					in = new BufferedInputStream(rm.getInputStream(path), 4<<10);
					out.putAll(ImageDesc.fromXML(prefix, in));
				} catch (SAXException saxe) {
					Log.w("AndroidVN", "Parse error in " + path, saxe);
					throw saxe;
				} finally {
					try {
						if (in != null) in.close();
					} catch (IOException e) {
						//Ignore
					}					
				}
			}
		}
	}
	*/
	
	public static void fromAssets(Map<String, ImageDesc> out,
			AssetManager assets, String folder)
		throws IOException, ParserConfigurationException, SAXException
	{
		fromAssets(out, assets, folder, folder);
	}
	private static void fromAssets(Map<String, ImageDesc> out,
			AssetManager assets, String baseFolder, String folder)
		throws IOException, ParserConfigurationException, SAXException
	{	
		if (baseFolder.endsWith("/")) {
			baseFolder = baseFolder.substring(0, baseFolder.length()-1);
		}
		if (folder.endsWith("/")) {
			folder = folder.substring(0, folder.length()-1);
		}
		
		String prefix = folder;
		if (prefix.length() > baseFolder.length()+1) {
			prefix = prefix.substring(baseFolder.length()) + "/";
			if (prefix.startsWith("/")) {
				prefix = prefix.substring(1);
			}
		} else {
			prefix = "";
		}
		
		//System.err.println(folder);
		for (String file : assets.list(folder)) {
			String path = folder + "/" + file;
			//System.out.println(folder + " " + file + " " + baseFolder + " " + prefix);
			
			if (!file.contains(".")) {
				fromAssets(out, assets, baseFolder, path);
				continue;
			} else if (!file.equals("img.xml")) {
				continue;
			}
				
			InputStream in = null;
			try {
				in = new BufferedInputStream(assets.open(path), 4<<10);
				ImageDescUtil.fromXML(out, prefix, in);
			} catch (SAXException saxe) {
				Log.w("AndroidVN", "Parse error in " + path, saxe);
				throw saxe;
			} finally {
				try {
					if (in != null) in.close();
				} catch (IOException e) {
					//Ignore
				}					
			}
		}
	}
	
}

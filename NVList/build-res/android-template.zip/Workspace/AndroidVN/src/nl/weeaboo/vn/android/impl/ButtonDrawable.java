package nl.weeaboo.vn.android.impl;

import nl.weeaboo.lua2.io.LuaSerializable;
import nl.weeaboo.vn.impl.base.BaseButtonDrawable;

@LuaSerializable
public class ButtonDrawable extends BaseButtonDrawable {

	private static final long serialVersionUID = AndroidImpl.serialVersionUID;

	public ButtonDrawable(boolean isTouchScreen) {
		super(isTouchScreen);
	}
	
	//Functions

	//Getters
	
	//Setters
	
}

package nl.weeaboo.android.gles;

import java.io.IOException;
import java.io.ObjectStreamException;
import java.io.Serializable;

import nl.weeaboo.filesystem.FileSystemView;
import nl.weeaboo.gl.GLManager;
import nl.weeaboo.gl.GLResId;
import nl.weeaboo.gl.shader.AbstractShaderStore;
import nl.weeaboo.gl.shader.GLShader;
import nl.weeaboo.io.EnvironmentSerializable;

public class ES1ShaderStore extends AbstractShaderStore implements Serializable {

	private static final long serialVersionUID = 1L;

	private final EnvironmentSerializable es;
	
	public ES1ShaderStore(FileSystemView fs) {
		super(fs);
		
		es = new EnvironmentSerializable(this);		
	}

	//Functions
	private Object writeReplace() throws ObjectStreamException {	
		return es.writeReplace();
	}

	@Override
	protected GLShader newShader(String path) throws IOException {
		return null;
	}

	@Override
	public GLResId newProgramId(GLManager glm, String filename) throws IOException {
		return null;
	}
	
}

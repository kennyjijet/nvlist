package nl.weeaboo.android.gui;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import nl.weeaboo.android.ResourceManager;
import nl.weeaboo.common.StringUtil;
import nl.weeaboo.io.StreamUtil;
import android.content.res.AssetManager;
import android.graphics.Typeface;
import android.util.Log;

public class FontManager {

	private static final String TAG = "FontManager";
	
	private Map<String, Typeface> fonts;
	private File cacheF;
	private Set<File> tempFiles;
	
	public FontManager() {
		fonts = new HashMap<String, Typeface>();
		tempFiles = new HashSet<File>();
	}
	
	//Functions
	public void init(ResourceManager rm, AssetManager assets) throws IOException {
		final String folder = "font";
		
		cacheF = new File(rm.getCacheFolder(), folder);
		if (!cacheF.exists() && !cacheF.mkdirs()) {
			Log.w(TAG, "Unable to create font cache folder: " + cacheF);
		}
		
		//Clear cached files
		File[] cacheChildren = cacheF.listFiles();
		if (cacheChildren != null) {
			for (File cached : cacheChildren) {
				if (cached.exists() && !cached.delete()) {
					Log.w(TAG, "Unable to delete temp file: " + cached);
				}
			}
		}
		
		/*
		String filenames[] = assets.list(folder);
		for (String filename : filenames) {
			if (filename.endsWith(".ttf") || filename.endsWith(".ttc")) {
				try {
					Typeface typeface = Typeface.createFromAsset(assets, folder+"/"+filename);
					//typeface = Typeface.create("monospace", 0);
					add(filename, typeface);
				} catch (RuntimeException re) {
					//Might throw RuntimeException: native typeface cannot be made
					Log.w(TAG, "Unable to create font: " + filename, re);
				}
			}
		}
		*/
		
		for (String path : rm.getFolderContents(folder, true)) {
			String fext = StringUtil.getExtension(path).toLowerCase();
			if (fext.equals("ttf") || fext.equals("ttc")) {
				String name = path.substring(folder.length()+1);
				if (!hasFont(name)) {					
					add(rm, path, name);
				}
			}
		}		
	}
	
	public boolean add(ResourceManager rm, String path, String name) {
		File file = null;
		
		//If the font is in a regular file, use that...
		for (File folder : rm.getReadFolders()) {
			File f = new File(folder, path);
			if (f.exists()) {
				file = f;
				break;
			}
		}
		
		//Fallback case, extract the font to a temp file...
		if (file == null) {
			try {
				file = extractFromResourceManager(rm, path, cacheF);
			} catch (IOException ioe) {
				Log.w(TAG, "Unable to create font: " + path, ioe);
			}
		}
		
		if (file == null) {
			Log.w(TAG, "Unable to read font file: " + path);
			return false;
		}
		
		boolean ok = false;
		try {
			Typeface typeface = Typeface.createFromFile(file);
			add(name, typeface);
			ok = true;
		} catch (RuntimeException re) {
			//Might throw RuntimeException: native typeface cannot be made
			Log.w(TAG, "Unable to create font: " + path, re);
		} finally {
			if (!ok) {
				if (file.exists() && !file.delete()) {
					Log.w(TAG, "Unable to delete temp file: " + file);					
				}
			}
		}

		tempFiles.add(file);
		return true;
	}
	
	public static File extractFromResourceManager(ResourceManager rm, String filename,
			File cacheF) throws IOException
	{
		String fext = StringUtil.getExtension(filename);
		File file = File.createTempFile("temp", "." + fext, cacheF);
		//file.deleteOnExit(); //Doesn't do anything on Android

		boolean ok = false;
		InputStream in = null;
		try {
			in = rm.getInputStream(filename);			
			FileOutputStream fout = new FileOutputStream(file);
			try {
				StreamUtil.writeFully(fout, in);
			} finally {
				fout.close();
			}
						
			ok = true;
			return file;
		} finally {
			try {
				if (in != null) in.close();
			} catch (IOException ioe) {
				//Ignore
			}

			if (!ok) {
				if (file.exists() && !file.delete()) {
					Log.w(TAG, "Unable to delete temp file: " + file);					
				}
			}
		}
	}
	
	public void dispose() {
		dispose0();
	}
	
	private final void dispose0() {
		for (File file : tempFiles) {
			if (file.exists() && !file.delete()) {
				Log.w(TAG, "Unable to delete temp file: " + file);
			}
		}
		tempFiles.clear();		
	}
	
	@Override
	protected void finalize() throws Throwable {
		try {
			dispose0();
		} finally {
			super.finalize();
		}
	}
	
	public void add(String name, Typeface font) {
		name = (name != null ? name.toLowerCase() : null);
		fonts.put(name, font);
		//Log.v(TAG, "FontManager.add() :: " + name);
		
		if (name != null && name.indexOf('.') >= 0) {
			fonts.put(StringUtil.stripExtension(name), font);
			//Log.v(TAG, "FontManager.add() :: " + StringUtil.stripExtension(name));
		}
	}
	
	//Getters
	public Typeface getDefaultFont() {
		return getFont(null);
	}
	public Typeface getFont(String name) {
		return getFont(name, Typeface.NORMAL);
	}	
	public Typeface getFont(String name, int style) {
		name = (name != null ? name.toLowerCase() : null);
		Typeface cached = fonts.get(name);
		if (cached == null) {
			cached = Typeface.create(name, style);
			fonts.put(name, cached);
			Log.v(TAG, "Unknown font: " + name);
		}		
		return cached;
	}
	
	public boolean hasFont(String name) {
		return fonts.get(name != null ? name.toLowerCase() : null) != null;
	}
	
	public void clear() {
		fonts.clear();
	}
	
	//Setters
	public void setDefaultFont(Typeface typeface) {
		fonts.put(null, typeface);
	}
	
}

package nl.weeaboo.vn.android.impl;

import nl.weeaboo.lua2.io.LuaSerializable;
import nl.weeaboo.vn.impl.base.BaseVideoState;

@LuaSerializable
public class VideoState extends BaseVideoState {

	private static final long serialVersionUID = AndroidImpl.serialVersionUID;

	public VideoState() {		
	}
	
	//Functions
	
	//Getters
	
	//Setters
	
}

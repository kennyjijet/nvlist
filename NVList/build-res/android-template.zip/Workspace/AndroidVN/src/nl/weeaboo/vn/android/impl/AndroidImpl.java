package nl.weeaboo.vn.android.impl;

final class AndroidImpl {

	private AndroidImpl() {		
	}

	static final long serialVersionUID = 1L;
	
}

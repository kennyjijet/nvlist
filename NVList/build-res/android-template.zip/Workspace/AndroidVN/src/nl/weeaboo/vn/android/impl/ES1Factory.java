package nl.weeaboo.vn.android.impl;

import nl.weeaboo.android.gles.ES1Draw;
import nl.weeaboo.android.gles.ES1Manager;
import nl.weeaboo.android.gles.ES1ResCache;
import nl.weeaboo.android.gles.ES1ShaderStore;
import nl.weeaboo.android.gles.ESManager;
import nl.weeaboo.android.gles.ESTextureStore;
import nl.weeaboo.android.vn.AndroidRenderEnv;
import nl.weeaboo.android.vn.GLFactory;
import nl.weeaboo.filesystem.FileSystemView;
import nl.weeaboo.filesystem.IFileSystem;
import nl.weeaboo.gl.GLResCache;
import nl.weeaboo.gl.shader.IShaderStore;
import nl.weeaboo.vn.INotifier;
import nl.weeaboo.vn.IShaderFactory;
import nl.weeaboo.vn.impl.base.BaseNotifier;
import nl.weeaboo.vn.impl.base.BaseShaderFactory;
import nl.weeaboo.vn.impl.lua.LuaTweenLib;

public class ES1Factory extends GLFactory {

	private final boolean isLowEnd;
	
	public ES1Factory(boolean lowEnd) {
		isLowEnd = lowEnd;
	}
	
	@Override
	public GLResCache newGLResCache() {
		return new ES1ResCache();
	}
	
	@Override
	public ESManager<?> newGLManager(GLResCache rc, IShaderStore shs) {
		return new ES1Manager(new ES1Draw(), rc, isLowEnd);		
	}

	@Override
	public IShaderStore newShaderStore(IFileSystem fs) {
		return new ES1ShaderStore(new FileSystemView(fs, "shader-es1", true));
	}

	@Override
	public BaseShaderFactory newShaderFactory(IShaderStore shs, BaseNotifier ntf) {
		return new ES1ShaderFactory(ntf);
	}

	@Override
	public LuaTweenLib newTweenLib(INotifier ntf, ImageFactory imgfac, IShaderFactory shfac) {
		return new ES1TweenLib(ntf, imgfac, shfac);
	}
	
	@Override
	public Renderer newRenderer(AndroidRenderEnv env, ESManager<?> glm, ImageFactory imgfac,
			IShaderFactory shfac, ESTextureStore ts)
	{
		return new ES1Renderer(env, (ES1Manager)glm, imgfac, shfac, ts);
	}

}

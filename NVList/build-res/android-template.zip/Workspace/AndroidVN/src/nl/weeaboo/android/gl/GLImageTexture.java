package nl.weeaboo.android.gl;

import java.io.Serializable;

import javax.microedition.khronos.opengles.GL;

import nl.weeaboo.image.ImageDesc;
import nl.weeaboo.image.MultiImageDesc;
import nl.weeaboo.image.MultiImageDesc.CropRect;
import nl.weeaboo.lua2.io.LuaSerializable;
import android.graphics.Bitmap;

@LuaSerializable
public class GLImageTexture extends GLTexture implements Serializable {

	private static final long serialVersionUID = 1400123072449647063L;
	
	private String filename;
	
	public GLImageTexture(ImageDesc desc, int texId) {
		this(desc, texId, 0, 0, desc.getWidth(), desc.getHeight());
	}
	public GLImageTexture(ImageDesc desc, int texId, int cx, int cy, int cw, int ch) {
		super(texId, desc.getWidth(), desc.getHeight(), cx, cy, cw, ch);
		
		filename = desc.getFilename();
		
		if (desc instanceof MultiImageDesc) {
			MultiImageDesc mid = (MultiImageDesc)desc;
			for (CropRect cr : mid.getCropRects()) {
				texRects.add(new GLTexRect(cr.getId(), this, cr.getX(), cr.getY(), cr.getWidth(), cr.getHeight()));
			}
		}
		
		serializeBitmap = false;
	}

	//Functions
	@Override
	public String toString() {
		return String.format("GLImageTexture(id=%d, filename=%s)", getTexId(), filename);
	}
	
	@Override
	public void setPixels(GL gl, Bitmap bitmap) {
		throw new IllegalStateException("Can't set pixels for a GLImageTexture");
	}
	void initialSetPixels(GL gl, Bitmap bitmap, boolean mipmap) {
		super.setPixels(gl, bitmap, mipmap);
	}
	
	//Getters
	public String getFilename() {
		return filename;
	}
	
	public Bitmap getBitmap() {
		return bitmap;
	}
	
	//Setters
	
}

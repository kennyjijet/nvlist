package nl.weeaboo.vn.android.impl;

import nl.weeaboo.lua2.io.LuaSerializable;
import nl.weeaboo.vn.impl.base.BaseImageState;

@LuaSerializable
public class ImageState extends BaseImageState {

	private static final long serialVersionUID = AndroidImpl.serialVersionUID;

	public ImageState(ImageFactory imgfac, int w, int h) {
		super(imgfac, w, h);
	}
	
	//Functions
	
	//Getters
	
	//Setters
	
}

package nl.weeaboo.vn.android.impl;

import static javax.microedition.khronos.opengles.GL10.GL_BLEND;
import static javax.microedition.khronos.opengles.GL10.GL_FLOAT;
import static javax.microedition.khronos.opengles.GL10.GL_ONE;
import static javax.microedition.khronos.opengles.GL10.GL_ONE_MINUS_SRC_ALPHA;
import static javax.microedition.khronos.opengles.GL10.GL_SCISSOR_TEST;
import static javax.microedition.khronos.opengles.GL10.GL_TEXTURE0;
import static javax.microedition.khronos.opengles.GL10.GL_TEXTURE_2D;
import static javax.microedition.khronos.opengles.GL10.GL_TEXTURE_COORD_ARRAY;
import static javax.microedition.khronos.opengles.GL10.GL_TRIANGLE_STRIP;
import static javax.microedition.khronos.opengles.GL10.GL_VERTEX_ARRAY;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;

import javax.microedition.khronos.opengles.GL10;
import javax.microedition.khronos.opengles.GL11;

import nl.weeaboo.android.gl.GLDraw;
import nl.weeaboo.android.gl.GLTexRect;
import nl.weeaboo.android.gl.GLTexture;
import nl.weeaboo.android.gl.Screenshot;
import nl.weeaboo.android.gl.TextureCache;
import nl.weeaboo.common.Rect;
import nl.weeaboo.common.Rect2D;
import nl.weeaboo.vn.BlendMode;
import nl.weeaboo.vn.IPixelShader;
import nl.weeaboo.vn.IScreenshot;
import nl.weeaboo.vn.ITexture;
import nl.weeaboo.vn.RenderCommand;
import nl.weeaboo.vn.impl.base.DistortGrid;
import nl.weeaboo.vn.impl.base.TriangleGrid;
import nl.weeaboo.vn.math.Matrix;

class RendererGL10 extends Renderer {

	private final GL10 gl;
	protected final FadeQuadRendererGL10 fadeQuadRenderer;	
	protected final BlendQuadRendererGL10 blendQuadRenderer;	
	protected final DistortQuadRendererGL10 distortQuadRenderer;
	
	//--- Properties only valid between renderBegin() and renderEnd() beneath this line ---
	private float dx, dy;
	//-------------------------------------------------------------------------------------

	public RendererGL10(GL10 gl, TextureCache tc, int w, int h, int rx, int ry, int rw, int rh,
			int sw, int sh, double displayDensity, double textScale)
	{
		super(tc, w, h, rx, ry, rw, rh, sw, sh, displayDensity, textScale);
		
		this.gl = gl;
		this.fadeQuadRenderer = new FadeQuadRendererGL10(this);
		this.blendQuadRenderer = new BlendQuadRendererGL10(this);
		this.distortQuadRenderer = new DistortQuadRendererGL10(this);
	}
	
	//Functions
	@Override
	protected void renderBegin(Rect2D bounds, Rect screenClip, Rect layerClip) {
		//rendering = true;
		
		gl.glPushMatrix();
		final float scale = (float)getScale();
		final int rx = getRealX();
		final int ry = getRealY();
		final int sh = getScreenHeight();
		dx = rx / scale + (bounds != null ? (float)bounds.x : 0);
		dy = ry / scale + (bounds != null ? (float)bounds.y : 0);
		gl.glScalef(scale, -scale, 1);
		gl.glTranslatef(dx, dy-sh/scale, 0);
		
		gl.glEnable(GL_SCISSOR_TEST);
		gl.glScissor(layerClip.x, layerClip.y, layerClip.w, layerClip.h);
		
		gl.glEnable(GL_BLEND);
		gl.glBlendFunc(GL_ONE, GL_ONE_MINUS_SRC_ALPHA);
		
		int foreground = 0xFFFFFFFF;
		GLDraw.setColorPre(gl, foreground);
	}
	
	@Override
	protected void renderEnd() {
		gl.glBindTexture(GL_TEXTURE_2D, 0);
		GLDraw.setColorPre(gl, 0xFFFFFFFF);
		gl.glEnable(GL_BLEND);
		gl.glBlendFunc(GL_ONE, GL_ONE_MINUS_SRC_ALPHA);
		gl.glDisable(GL_SCISSOR_TEST);
		gl.glPopMatrix();
		
		//rendering = false;
	}
		
	@Override
	protected void renderSetClip(boolean c) {
		if (c) {
			gl.glEnable(GL_SCISSOR_TEST);
		} else {
			gl.glDisable(GL_SCISSOR_TEST);
		}
	}

	@Override
	protected void renderSetColor(int argb) {
		GLDraw.setColorPre(gl, GLDraw.premultiplyAlpha(argb));
	}

	@Override
	protected void renderSetBlendMode(BlendMode bm) {
		switch (bm) {
		case DEFAULT: gl.glEnable(GL_BLEND);  gl.glBlendFunc(GL_ONE, GL_ONE_MINUS_SRC_ALPHA); break;
		case ADD:     gl.glEnable(GL_BLEND);  gl.glBlendFunc(GL_ONE, GL_ONE); break;
		case OPAQUE:  gl.glDisable(GL_BLEND); break;
		}
	}
				
	private static FloatBuffer toGLFloatBuffer(FloatBuffer buf) {
		ByteBuffer resultB = ByteBuffer.allocateDirect(buf.limit() * 4);
		resultB.order(ByteOrder.nativeOrder());
		FloatBuffer result = resultB.asFloatBuffer();
		result.put(buf);
		result.rewind();
		return result;
	}
	
	@Override
	public void renderTriangleGrid(TriangleGrid grid) {
		gl.glEnableClientState(GL_VERTEX_ARRAY);
		for (int n = 0; n < grid.getTextures(); n++) {
			gl.glClientActiveTexture(GL_TEXTURE0 + n);
			gl.glEnableClientState(GL_TEXTURE_COORD_ARRAY);
		}
		for (int row = 0; row < grid.getRows(); row++) {
			gl.glVertexPointer(2, GL_FLOAT, 0, toGLFloatBuffer(grid.getPos(row)));
			for (int n = 0; n < grid.getTextures(); n++) {
				gl.glClientActiveTexture(GL_TEXTURE0 + n);
			    gl.glTexCoordPointer(2, GL_FLOAT, 0, toGLFloatBuffer(grid.getTex(n, row)));
			}
		    gl.glDrawArrays(GL_TRIANGLE_STRIP, 0, grid.getVertexCount(row));
		}
		for (int n = grid.getTextures()-1; n >= 0; n--) {
			gl.glClientActiveTexture(GL_TEXTURE0 + n);
			gl.glEnableClientState(GL_TEXTURE_COORD_ARRAY);
		}
	    gl.glDisableClientState(GL_VERTEX_ARRAY);		
	}
			
	@Override
	public void renderQuad(ITexture itex, Matrix transform, double x, double y, double w, double h,
			IPixelShader ps, double u, double v, double uw, double vh)
	{
		if (ps != null) ps.preDraw(this);
		
		int texId = 0;
		int tw = 0, th = 0;
		boolean mipmap = false;
		if (itex != null) {
			forceLoad(gl, itex);
			GLTexRect tr = ((TextureAdapter)itex).getTexRect();

			Rect2D uv = tr.getUV();
			u  = uv.x + u * uv.w;
			v  = uv.y + v * uv.h;
			uw = uv.w * uw;
			vh = uv.h * vh;

			GLTexture tex = tr.getTexture();			
			texId = tex.getTexId();
			tw = tex.getTexWidth();
			th = tex.getTexHeight();
			mipmap = tex.isMipmapped();
		}
					
		if (texId != 0 && GLDraw.supportsDrawTex(gl) && !transform.hasShear() && !mipmap) {
			double sx = transform.getScaleX();
			double sy = transform.getScaleY();

			v += vh;
			vh = -vh;
			
			double scale = getScale();
			w = scale * (sx * w);
			h = scale * (sy * h);
			x = scale * (dx + sx * x + transform.getTranslationX());
			y = getScreenHeight() - scale * (dy + sy * y + transform.getTranslationY()) - h;
			
			GLDraw.drawTexRect((GL11)gl, texId, tw, th, x, y, w, h, u, v, uw, vh);
		} else {
			gl.glPushMatrix();
			gl.glMultMatrixf(transform.toGLMatrix(), 0);
			GLDraw.drawQuad(gl, texId, tw, th, x, y, w, h, u, v, uw, vh);
			gl.glPopMatrix();
		}		
		
		if (ps != null) ps.postDraw(this);				
	}

	@Override
	public void renderBlendQuad(ITexture tex0, double alignX0, double alignY0, ITexture tex1, double alignX1,
			double alignY1, double frac, Matrix transform, IPixelShader ps)
	{
		blendQuadRenderer.renderBlendQuad(tex0, alignX0, alignY0, tex1, alignX1, alignY1, frac, transform, ps);
	}

	@Override
	public void renderFadeQuad(ITexture tex, Matrix transform, int color0, int color1, double x, double y,
			double w, double h, IPixelShader ps, int dir, boolean fadeIn, double span, double frac)
	{
		//System.out.println(x + " " + y + " " + w + " " + h);
		
		//renderQuad(tex, transform, x, y, w, h, ps, 0, 0, 1, 1);
		fadeQuadRenderer.renderFadeQuad(tex, transform, color0, color1, x, y, w, h, ps, dir, fadeIn, span, frac);
	}

	@Override
	public void renderDistortQuad(ITexture tex, Matrix transform, int argb,
			double x, double y, double w, double h, IPixelShader ps,
			DistortGrid grid, Rect2D clampBounds)
	{
		distortQuadRenderer.renderDistortQuad(tex, transform, argb, x, y, w, h, ps, grid, clampBounds);
	}

	@Override
	public void renderScreenshot(IScreenshot out, Rect glScreenRect) {
		Screenshot ss = (Screenshot)out;		
		ss.set(gl, glScreenRect, getRealWidth(), getRealHeight());
	}

	@Override
	protected boolean renderUnknownCommand(RenderCommand cmd) {
		return false;
	}

	@Override
	public GL10 getGL() {
		return gl;
	}
	
}

package nl.weeaboo.android.gui;

import android.text.TextPaint;
import android.text.style.CharacterStyle;

public class ShadowSpan extends CharacterStyle {

	private final float dx, dy;
	private final int color;
	
	public ShadowSpan(float dx, float dy, int color) {
		this.dx = dx;
		this.dy = dy;
		this.color = color;
	}
	
	//Functions
	@Override
	public void updateDrawState(TextPaint tp) {
		tp.setShadowLayer(.001f, dx, dy, color);
	}
	
	//Getters
	
	//Setters
	
}

package nl.weeaboo.android.vn;

import nl.weeaboo.android.gl.Screenshot;
import nl.weeaboo.android.gui.ProgressAsyncTask;
import nl.weeaboo.vn.IImageState;
import nl.weeaboo.vn.IScreenshotBuffer;
import android.content.Context;
import android.os.Handler;

public class ScreenshotTask extends ProgressAsyncTask<Game, Screenshot> {

	protected ScreenshotTask(Context c, Handler h, String msg) {
		super(c, h, msg);
	}

	//Functions
	@Override
	protected Screenshot doInBackground(Game... params) {
		Game game = params[0];
		
		Screenshot ss;		
		synchronized (game) {
			IImageState is = game.getNovel().getImageState();
			IScreenshotBuffer ssb = is.getDefaultLayer().getScreenshotBuffer();
			ss = new Screenshot(Short.MIN_VALUE, false);
			ss.markTransient();
			ssb.add(ss, false);
		}
		
		//Busy wait
		while (!ss.isCancelled() && !ss.isAvailable()) {
			try {
				Thread.sleep(1);
			} catch (InterruptedException e) { }
		}
		
		return (ss.isAvailable() ? ss : null);
	}
	
	//Getters
	
	//Setters
	
}

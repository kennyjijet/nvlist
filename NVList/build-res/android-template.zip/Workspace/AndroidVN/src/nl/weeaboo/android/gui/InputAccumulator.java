package nl.weeaboo.android.gui;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import android.view.KeyEvent;
import android.view.MotionEvent;

public class InputAccumulator {
	
	Set<KeyEvent> keysDown;	
	Set<KeyEvent> keysLongPress;	
	Set<KeyEvent> keysMultiple;	
	Set<KeyEvent> keysUp;	
	List<TouchEvent> touchEvents;
	
	public InputAccumulator() {
		keysDown = new HashSet<KeyEvent>();
		keysLongPress = new HashSet<KeyEvent>();
		keysMultiple = new HashSet<KeyEvent>();
		keysUp = new HashSet<KeyEvent>();
		touchEvents = new ArrayList<TouchEvent>();
	}
	
	//Functions	
	public synchronized void clear() {
		keysDown.clear();
		keysLongPress.clear();
		keysMultiple.clear();
		keysUp.clear();
		touchEvents.clear();
	}
	
    public synchronized boolean onKeyDown(final KeyEvent event) {
    	if (event.getRepeatCount() == 0) {
    		keysDown.add(event);
    	}
    	return true;
	}
    public synchronized boolean onKeyLongPress(final KeyEvent event) {
    	keysLongPress.add(event);
    	return true;
	}
    public synchronized boolean onKeyMultiple(final KeyEvent event) {
    	keysMultiple.add(event);
    	return true;
	}
    public synchronized boolean onKeyUp(final KeyEvent event) {
    	keysUp.add(event);
    	return true;
	}
    public synchronized boolean onTouchEvent(MotionEvent event) {
    	touchEvents.add(new TouchEvent(event));
    	return true;
    }
    
	//Getters
	
	//Setters
    
    //Inner Classes
    public static class TouchEvent {
    	
    	private final float x, y;
    	private final int action;
    	
    	public TouchEvent(MotionEvent event) {
    		x = event.getX();
    		y = event.getY();
    		action = event.getAction();
    	}
    	
    	public float getX() { return x; }
    	public float getY() { return y; }
    	public int getAction() { return action; }
    	
    }    
	
}

package nl.weeaboo.android;

import java.io.File;
import java.io.FileDescriptor;
import java.io.FileInputStream;
import java.io.IOException;

import android.content.res.AssetFileDescriptor;
import android.content.res.AssetManager;

public abstract class FileSegment {
	
	private final File file;
	private final long offset;
	private final long length;
		
	private FileDescriptor fd;
	private int openCount;
	
	protected FileSegment(File file, long offset, long length) {
		this.file = file;
		this.offset = offset;
		this.length = length;
	}
	
	//Functions
	public static FileSegment fromFile(File file) {
		return fromFile(file, 0, file.length());
	}
	public static FileSegment fromFile(File file, long offset, long length) {
		return new DefaultFileSegment(file, offset, length);
	}
	
	public static FileSegment fromAsset(AssetManager assets, String filename, long offset, long length) {
		AssetFileDescriptor afd = null;
		try {
			afd = assets.openFd(filename);			
		} catch (IOException ioe) {
			//Ignore, instead throw the error upon FileSegment.open()
		}
		return fromAsset(assets, filename, afd, offset, length);
	}
	public static FileSegment fromAsset(AssetManager assets, String filename,
			AssetFileDescriptor afd, long offset, long length)
	{
		return new AssetFileSegment(assets, filename, null, offset, length);
	}
	
	public final FileDescriptor open() throws IOException {		
		if (openCount <= 0) {
			fd = open0();
			openCount = 1;
		} else {
			openCount++;
		}
		return fd;
	}
	
	protected abstract FileDescriptor open0() throws IOException;
	
	public final void close() throws IOException {
		if (openCount <= 1) {
			openCount = 0;
			close0(fd);
		} else {
			openCount--;			
		}
	}

	protected abstract void close0(FileDescriptor fd) throws IOException;
	
	//Getters
	/**
	 * @return The file backing this FileSegment object, or <code>null</code> if not backed by a File.
	 */
	public File getFile() {
		return file;
	}
	public long getOffset() {
		return offset;
	}
	public long getLength() {
		return length;
	}
	
	//Setters
	
	//Inner Classes
	private static class DefaultFileSegment extends FileSegment {
	
		private FileInputStream fin;
		
		public DefaultFileSegment(File file, long offset, long length) {
			super(file, offset, length);
		}

		@Override
		protected FileDescriptor open0() throws IOException {
			fin = new FileInputStream(getFile());
			return fin.getFD();
		}
		
		@Override
		protected void close0(FileDescriptor fd) throws IOException {
			fin.close();
		}
	}

	private static class AssetFileSegment extends FileSegment {
		
		private final AssetManager assets;
		private final String filename;
		
		private AssetFileDescriptor afd;
		
		public AssetFileSegment(AssetManager assets, String filename,
				AssetFileDescriptor afd, long offset, long length)
		{
			super(null, offset, length);
			
			this.assets = assets;
			this.filename = filename;
			this.afd = afd;
		}

		@Override
		public long getOffset() {
			long offset = super.getOffset();
			if (afd != null) offset += afd.getStartOffset();
			return offset;
		}
		
		@Override
		public long getLength() {
			long length = super.getLength();
			if (afd != null) length = Math.min(length, afd.getLength());
			return length;
		}
		
		@Override
		protected FileDescriptor open0() throws IOException {
			if (afd == null) {
				afd = assets.openFd(filename);
			}
			return afd.getFileDescriptor();
		}
		
		@Override
		protected void close0(FileDescriptor fd) throws IOException {
			afd.close();
			afd = null;
		}
	}
	
}

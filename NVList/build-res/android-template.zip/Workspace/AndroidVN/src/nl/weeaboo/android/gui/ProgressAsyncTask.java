package nl.weeaboo.android.gui;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.os.AsyncTask;
import android.os.Handler;

public abstract class ProgressAsyncTask<I, O> extends AsyncTask<I, Float, O> {

	protected Context context;
	protected Handler handler;
	private int showDelayMillis;
	protected ProgressDialog progress;
	private final String message;
	
	public ProgressAsyncTask(Context c, Handler h, String msg) {
		context = c;
		handler = h;
		message = msg;
	}
	
	//Functions
	@Override
	protected void onPreExecute() {
		progress = new ProgressDialog(context);
		progress.setMessage(message);
		progress.setOnCancelListener(new OnCancelListener() {
			public void onCancel(DialogInterface dialog) {
				cancel(true);
			}
		});
		progress.setCancelable(false);
		setProgressProperties(progress);

		if (showDelayMillis > 0) {
			handler.postDelayed(new Runnable() {
				@Override
				public void run() {
					if (progress != null) {
						progress.show();
					}
				}
			}, showDelayMillis);
		} else {
			progress.show();			
		}
	}	
	
	protected void setProgressProperties(ProgressDialog progress) {
		
	}

	@Override
	public void onProgressUpdate(Float... values) {
		if (progress != null) {
			progress.setProgress(Math.round(values[0] * 100f));
		}
	}
	
	@Override
	protected void onPostExecute(O result) {
		if (progress != null) {
			progress.dismiss();
			progress = null;
		}
	}
	
	@Override
	public void onCancelled() {
		super.onCancelled();
		
		if (progress != null) {
			progress.dismiss();
			progress = null;
		}
	}
	
	//Getters
	
	//Setters
	public void setShowDelay(int d) {
		showDelayMillis = d;
	}
	
}

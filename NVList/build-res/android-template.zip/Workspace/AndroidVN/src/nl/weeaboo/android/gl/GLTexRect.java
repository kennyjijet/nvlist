package nl.weeaboo.android.gl;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

import nl.weeaboo.common.Rect;
import nl.weeaboo.common.Rect2D;
import nl.weeaboo.lua2.io.LuaSerializable;

@LuaSerializable
public final class GLTexRect implements Externalizable {
	
	//--- Uses manual serialization, don't add variables ---
	private String id;
	private GLTexture texture;
	private int x, y, w, h;
	private Rect2D uv;
	//--- Uses manual serialization, don't add variables ---
	
	@Deprecated
	public GLTexRect() {
		
	}
	public GLTexRect(String i, GLTexture t, int x, int y, int w, int h) {
		this.id = i;
		this.texture = t;
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
		this.uv = new Rect2D(x, y, w, h);
	}
	
	//Functions
	@Override
	public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException {
		id = (String)in.readObject();
		texture = (GLTexture)in.readObject();
		x = in.readInt(); y = in.readInt(); w = in.readInt(); h = in.readInt();
		uv = new Rect2D(in.readDouble(), in.readDouble(), in.readDouble(), in.readDouble());		
	}

	@Override
	public void writeExternal(ObjectOutput out) throws IOException {
		out.writeObject(id); //Can't use writeUTF since it can't handle null values
		out.writeObject(texture);
		out.writeInt(x); out.writeInt(y); out.writeInt(w); out.writeInt(h);
		out.writeDouble(uv.x); out.writeDouble(uv.y); out.writeDouble(uv.w); out.writeDouble(uv.h);
	}
	
	//Getters
	public final boolean isDisposed() { return texture.isDisposed(); }
	
	public String getPath() {
		if (!(texture instanceof GLImageTexture)) {
			return null;
		}
		String filename = ((GLImageTexture)texture).getFilename();
		return filename + (id != null ? '#'+id : "");
	}
	public String getId() { return id; }
	public int getTexId() { return (texture != null ? texture.getTexId() : 0); }
	public GLTexture getTexture() { return texture; }
	public int getX() { return x; }
	public int getY() { return y; }
	public int getWidth() { return w; }
	public int getHeight() { return h; }
	public Rect2D getUV() { return uv; }
	
	public int[] getARGB(Rect r) {
		int ix=x, iy=y, iw=w, ih=h;;
		if (r != null) {
			ix += Math.max(0, Math.min(iw, r.x));
			iy += Math.max(0, Math.min(ih, r.y));
			iw = Math.max(0, Math.min(iw-ix, r.w));
			ih = Math.max(0, Math.min(ih-iy, r.h));
		}		
		return (texture != null ? texture.getARGB(iw, iy, iw, ih) : null);
	}
	public int[] getARGBPre(Rect r) {
		int ix=x, iy=y, iw=w, ih=h;;
		if (r != null) {
			ix += Math.max(0, Math.min(iw, r.x));
			iy += Math.max(0, Math.min(ih, r.y));
			iw = Math.max(0, Math.min(iw-ix, r.w));
			ih = Math.max(0, Math.min(ih-iy, r.h));
		}		
		return (texture != null ? texture.getARGBPre(ix, iy, iw, ih) : null);
	}
	
	//Setters
	
}

package nl.weeaboo.android.gui;

public class FPSAnimator {

	private volatile Thread thread;
	private volatile double frameTimeNanos;
	private volatile double currentFrameTimeNanos;
	private final AnimRunnable anim;
	private final String name;
	private final Runnable inner;
	
	public FPSAnimator(String n, Runnable r, int fps) {
		name = n;
		anim = new AnimRunnable();
		inner = r;
		
		setFPS0(fps);
	}
	
	//Functions
	public synchronized void start() {
		if (thread != null) {
			return;
		}
		
		currentFrameTimeNanos = frameTimeNanos; //Start at assumption of desired speed
		
		thread = new Thread(anim, name);
		thread.start();
	}


	public synchronized void stop() {
		if (thread != null) {
			Thread t = thread;
			thread = null;
			
			t.interrupt();
			try {
				t.join();
			} catch (InterruptedException e) {				
			}
		}
	}
	
	protected void updateCurrentFrameTime(double t) {
		currentFrameTimeNanos = currentFrameTimeNanos*.9 + t*.1;
	}
	
	//Getters
	public synchronized boolean isAnimating() {
		return thread != null;
	}
	public double getCurrentFrameTime() {
		return currentFrameTimeNanos;
	}
	public double getCurrentFPS() {
		return 1000000000.0 / getCurrentFrameTime();
	}
	
	//Setters
	public void setFPS(int fps) {
		setFPS0(fps);
	}
	private void setFPS0(int fps) {
		frameTimeNanos = 1000000000.0 / Math.max(1, fps);
	}
	
	//Inner Classes
	private class AnimRunnable implements Runnable {
		
		public AnimRunnable() {			
		}
		
		public void run() {
			long oldTime = System.nanoTime();
			while (thread != null) {
				inner.run();
				
				long time = System.nanoTime();
				
				double ftn = frameTimeNanos;				
				if (time - oldTime < ftn) {
					long wait = Math.round(ftn - time + oldTime);
					
					if (wait > 0) {
						try {
							Thread.sleep(wait/1000000, (int)(wait%1000000));
						} catch (InterruptedException e) {
						}
					}
				} else {
					ftn = time - oldTime;
				}

				oldTime += ftn;
				updateCurrentFrameTime(ftn);
			}
		}
		
	}
}

package nl.weeaboo.vn.android.impl;

import java.io.ObjectStreamException;
import java.nio.IntBuffer;

import nl.weeaboo.common.Dim;
import nl.weeaboo.common.Rect;
import nl.weeaboo.gl.tex.GLTexRect;
import nl.weeaboo.gl.tex.TextureException;
import nl.weeaboo.io.EnvironmentSerializable;
import nl.weeaboo.lua2.io.LuaSerializable;
import nl.weeaboo.vn.IImageFactory;
import nl.weeaboo.vn.ITexture;
import nl.weeaboo.vn.impl.base.BaseImageFxLib;
import android.util.Log;

@LuaSerializable
public class ImageFxLib extends BaseImageFxLib {

	private static final String TAG = "ImageFx";
	
	private final EnvironmentSerializable es;
	
	public ImageFxLib(IImageFactory imgfac) {
		super(imgfac);
		
		this.es = new EnvironmentSerializable(this);
	}
	
	//Functions
	private Object writeReplace() throws ObjectStreamException {	
		return es.writeReplace();
	}

	@Override
	protected Bitmap tryGetBitmap(ITexture tex, boolean logFailure, Rect subRect) {
		if (tex instanceof TextureAdapter) {
			TextureAdapter adapter = (TextureAdapter)tex;
			GLTexRect tr = adapter.getTexRect();
			if (tr != null) {
				if (subRect == null) {
					subRect = new Rect(0, 0, tr.getWidth(), tr.getHeight());
				}
				int[] argb = new int[subRect.w * subRect.h];			
				try {
					tr.getPixelsARGB8(IntBuffer.wrap(argb), subRect.x, subRect.y, subRect.w, subRect.h);
					return new Bitmap(argb, subRect.w, subRect.h);
				} catch (TextureException e) {
					//Tough shit
				}
			}
		}
		
		if (logFailure) {
			Log.w(TAG, "Unable to get pixels from texture: " + tex.toString());			
		}
		
		return null;
	}

	@Override
	protected Dim getBitmapSize(ITexture tex) {
		if (tex instanceof TextureAdapter) {
			TextureAdapter adapter = (TextureAdapter)tex;
			GLTexRect tr = adapter.getTexRect();
			if (tr != null) {
				return new Dim(tr.getWidth(), tr.getHeight());
			}
		}
		return new Dim(0, 0);
	}


	//Getters
	
	//Setters
	
}

package nl.weeaboo.vn.android.impl;

import java.io.ObjectStreamException;

import nl.weeaboo.android.gl.GLTexRect;
import nl.weeaboo.common.Dim;
import nl.weeaboo.common.Rect;
import nl.weeaboo.io.EnvironmentSerializable;
import nl.weeaboo.lua2.io.LuaSerializable;
import nl.weeaboo.vn.IImageFactory;
import nl.weeaboo.vn.ITexture;
import nl.weeaboo.vn.impl.base.BaseImageFxLib;
import android.util.Log;

@LuaSerializable
public class ImageFxLib extends BaseImageFxLib {

	private static final String TAG = "ImageFx";
	
	private final EnvironmentSerializable es;
	
	public ImageFxLib(IImageFactory imgfac) {
		super(imgfac);
		
		this.es = new EnvironmentSerializable(this);
	}
	
	//Functions
	private Object writeReplace() throws ObjectStreamException {	
		return es.writeReplace();
	}

	@Override
	protected Bitmap tryGetBitmap(ITexture tex, boolean logFailure, Rect subRect) {
		if (tex instanceof TextureAdapter) {
			TextureAdapter adapter = (TextureAdapter)tex;
			GLTexRect tr = adapter.getTexRect();
			if (tr != null) {
				int[] argb = tr.getARGBPre(subRect);
				if (argb != null) {
					int w = tr.getWidth();
					int h = tr.getHeight();
					if (subRect != null) {
						w = subRect.w;
						h = subRect.h;
					}
					return new Bitmap(argb, w, h);
				}
			}
		}
		
		if (logFailure) {
			Log.w(TAG, "Unable to get pixels from texture: " + tex.toString());			
		}
		
		return null;
	}

	@Override
	protected Dim getBitmapSize(ITexture tex) {
		if (tex instanceof TextureAdapter) {
			TextureAdapter adapter = (TextureAdapter)tex;
			GLTexRect tr = adapter.getTexRect();
			if (tr != null) {
				return new Dim(tr.getWidth(), tr.getHeight());
			}
		}
		return new Dim(0, 0);
	}


	//Getters
	
	//Setters
	
}

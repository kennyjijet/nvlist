package nl.weeaboo.android.vn;

import static nl.weeaboo.android.vn.AndroidConfig.ERROR_LEVEL;
import static nl.weeaboo.android.vn.AndroidConfig.LONG_PRESS_DELAY;
import static nl.weeaboo.android.vn.AndroidConfig.MIN_TOUCH_DELAY;
import static nl.weeaboo.android.vn.AndroidConfig.MIN_VISIBLE_LINES;
import static nl.weeaboo.android.vn.AndroidConfig.RENDER_ANCHOR;
import static nl.weeaboo.android.vn.AndroidConfig.SAVE_MODE;
import static nl.weeaboo.android.vn.AndroidConfig.SHOW_CLOCK;
import static nl.weeaboo.android.vn.AndroidConfig.TEXTBOX_ALPHA;
import static nl.weeaboo.android.vn.AndroidConfig.TEXTBOX_ANCHOR;
import static nl.weeaboo.android.vn.AndroidConfig.TEXT_SIZE;
import static nl.weeaboo.android.vn.AndroidConfig.USE_EMBEDDED_FONTS;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Date;
import java.util.concurrent.ExecutorService;

import javax.microedition.khronos.egl.EGLConfig;
import javax.xml.parsers.ParserConfigurationException;

import nl.weeaboo.android.AndroidFileSystem;
import nl.weeaboo.android.AndroidUtil;
import nl.weeaboo.android.AssetZipArchive;
import nl.weeaboo.android.ProgressListener;
import nl.weeaboo.android.gles.ESTextureDataLoader;
import nl.weeaboo.android.gles.ES1Manager;
import nl.weeaboo.android.gles.ES1ResCache;
import nl.weeaboo.android.gles.ESManager;
import nl.weeaboo.android.gles.ESTextureStore;
import nl.weeaboo.android.gui.FPSAnimator;
import nl.weeaboo.android.gui.FontManager;
import nl.weeaboo.android.gui.InputAccumulator;
import nl.weeaboo.android.gui.Painter;
import nl.weeaboo.android.gui.TextLayoutUtil;
import nl.weeaboo.android.gui.UserInput;
import nl.weeaboo.common.Dim;
import nl.weeaboo.common.StringUtil;
import nl.weeaboo.filesystem.IFileSystem;
import nl.weeaboo.filesystem.SecureFileWriter;
import nl.weeaboo.game.CallerRunsExecutor;
import nl.weeaboo.gl.GLManager;
import nl.weeaboo.gl.GLResCache;
import nl.weeaboo.image.FileResolutionOption;
import nl.weeaboo.image.FileResolutionPicker;
import nl.weeaboo.io.StreamUtil;
import nl.weeaboo.lua2.LuaException;
import nl.weeaboo.lua2.io.LuaSerializer;
import nl.weeaboo.lua2.io.ObjectSerializer.PackageLimit;
import nl.weeaboo.settings.INIFile;
import nl.weeaboo.styledtext.FontStyle;
import nl.weeaboo.styledtext.TextStyle;
import nl.weeaboo.vn.IAnalytics;
import nl.weeaboo.vn.IButtonDrawable;
import nl.weeaboo.vn.IDrawable;
import nl.weeaboo.vn.IImageFactory;
import nl.weeaboo.vn.IImageState;
import nl.weeaboo.vn.IInput;
import nl.weeaboo.vn.ILayer;
import nl.weeaboo.vn.INovelConfig;
import nl.weeaboo.vn.ISeenLog;
import nl.weeaboo.vn.IStorage;
import nl.weeaboo.vn.ISystemLib;
import nl.weeaboo.vn.ITextDrawable;
import nl.weeaboo.vn.ITexture;
import nl.weeaboo.vn.ITimer;
import nl.weeaboo.vn.NovelPrefs;
import nl.weeaboo.vn.android.impl.GUIFactory;
import nl.weeaboo.vn.android.impl.Globals;
import nl.weeaboo.vn.android.impl.ImageFactory;
import nl.weeaboo.vn.android.impl.ImageFxLib;
import nl.weeaboo.vn.android.impl.ImageState;
import nl.weeaboo.vn.android.impl.InputAdapter;
import nl.weeaboo.vn.android.impl.Notifier;
import nl.weeaboo.vn.android.impl.Novel;
import nl.weeaboo.vn.android.impl.Renderer;
import nl.weeaboo.vn.android.impl.SaveHandler;
import nl.weeaboo.vn.android.impl.ScriptLib;
import nl.weeaboo.vn.android.impl.ES1ShaderFactory;
import nl.weeaboo.vn.android.impl.SharedGlobals;
import nl.weeaboo.vn.android.impl.SoundFactory;
import nl.weeaboo.vn.android.impl.SoundState;
import nl.weeaboo.vn.android.impl.SystemLib;
import nl.weeaboo.vn.android.impl.TextState;
import nl.weeaboo.vn.android.impl.TweenLib;
import nl.weeaboo.vn.android.impl.VideoFactory;
import nl.weeaboo.vn.android.impl.VideoState;
import nl.weeaboo.vn.impl.base.NullAnalytics;
import nl.weeaboo.vn.impl.base.NullSeenLog;
import nl.weeaboo.vn.impl.base.Timer;
import nl.weeaboo.vn.impl.lua.EnvLuaSerializer;
import nl.weeaboo.vn.parser.ParserUtil;
import nl.weeaboo.vn.vnds.VNDSUtil;

import org.xml.sax.SAXException;

import android.content.res.AssetManager;
import android.graphics.Typeface;
import android.os.Handler;
import android.util.Log;
import android.view.Display;

public class Game {

	public static final String TAG_LUA = "Lua";
	private static final String ASSET_IMG_FOLDER = "aimg/";
	
	private final DateFormat dateFormat;
	final boolean isLowEnd;
	final boolean isDebugSigned;
	boolean isVNDS;
	private float textSize;
	private float displayDensity;
	private int vwidth, vheight;
	private int realX, realY, realW, realH; //ImageState crop rect in screen coords
	private int screenW, screenH; //Physical screen size in pixels
	Painter painter;
	
	private FPSAnimator animator;
	private AndroidVN context;
	private AssetManager assets;
	private Handler guiHandler;
	private AndroidFileSystem afs;
	private AndroidConfig config;
	private ESTextureStore texStore;
	GLResCache glResCache;
	private FileResolutionPicker imageResolutionPicker, assetImageResolutionPicker, videoResolutionPicker;
	private FontManager fontManager;
	private UserInput input;
	private LuaSerializer luaSerializer;
	private ITextDrawable clockDrawable;
	private IButtonDrawable softMenuDrawable;
	private ITextDrawable superSkipDrawable;
	private ITextDrawable autoReadDrawable;
	private Renderer renderer;
	private int renderAnchor;
	private int textboxAnchor;
	private int textboxAlpha;
	private SoftMenuMode softMenuMode;
	private boolean luaRunning;
	boolean useEmbeddedFonts;
	int minVisibleLines;
	
	// !!WARNING!! Do not add properties without adding code for saving/loading
		
	private Novel novel;
	
	public Game(AndroidVN c, Handler gh, float density, boolean debugSigned,
			InputAccumulator inputAccum, Painter p, boolean vnds)
	{
		context = c;
		assets = c.getAssets();
		isDebugSigned = debugSigned;
		displayDensity = density;
		guiHandler = gh;
		painter = p;
		textSize = 1f;
		input = new UserInput(inputAccum);
		dateFormat = android.text.format.DateFormat.getTimeFormat(c);
		renderAnchor = 5;
		textboxAnchor = 2;
		textboxAlpha = 160;
		softMenuMode = SoftMenuMode.TRANSLUCENT;
		useEmbeddedFonts = true;
		minVisibleLines = 2;
		isVNDS = vnds;
		
		//Assume low-res screen devices to also have slow processors
		Display display = context.getWindowManager().getDefaultDisplay();
		isLowEnd = Math.max(display.getWidth(), display.getHeight()) <= 480;		
	}
	
	//Functions		
	public synchronized void init(AndroidFileSystem fs, INovelConfig novelConfig,
			final ProgressListener pl) throws IOException, GameNotFoundException
	{
		afs = fs;
		
		//Folders
        String imgF = "img/";
        String sndF = "snd/";
        String videoF = "video/";
        if (isVNDS) {
        	imgF = sndF = videoF = "";
        }
		
		//Create font manager
		pl.onProgress(.80f);
		fontManager = new FontManager();
		try {
			fontManager.init(afs, assets);
		} catch (IOException e) {
			Log.w(AndroidVN.TAG, "Error initializing FontManager", e);
		}
		if (isVNDS && afs.getFileExists("default.ttf")) {
			fontManager.add(afs, "default.ttf", "vnds");
		}
		
		//Load game.ini
		pl.onProgress(.85f);
        vwidth = novelConfig.getWidth();
        vheight = novelConfig.getHeight();
        
        if (isVNDS) {
        	final String subTitle = novelConfig.getTitle();
        	guiHandler.post(new Runnable() {
				@Override
				public void run() {
		        	AndroidUtil.trySetSubtitle(context, subTitle);
				}        		
        	});
        }
        
		//Load img.ini
		Dim imgSize = readImageINI(afs, imgF + "img.ini", novelConfig);		
		
		//Load preferences
		config = new AndroidConfig(afs);
		config.loadVariables();
		
        //Initialize        		
		imageResolutionPicker = new FileResolutionPicker();
		imageResolutionPicker.addOptions(FileResolutionPicker.getOptions(afs, imgF, imgSize));

		assetImageResolutionPicker = AssetZipArchive.createAssetFolderPicker(afs, assets, ASSET_IMG_FOLDER, imgSize);
		
		videoResolutionPicker = new FileResolutionPicker();
		videoResolutionPicker.addOptions(FileResolutionPicker.getOptions(afs, videoF, imgSize));

		Display display = context.getWindowManager().getDefaultDisplay();
        int screenTexBytes = 4 * display.getWidth() * display.getHeight();
		
		ExecutorService es = new CallerRunsExecutor(); //multi-threading just leads to poor IO performance.
		SecureFileWriter sfw = new SecureFileWriter(afs);
		Notifier notifier = new Notifier();
		glResCache = new ES1ResCache();
		ESTextureDataLoader texLoader = new ESTextureDataLoader(es, afs);
        texStore = new ESTextureStore(afs, imgF, ASSET_IMG_FOLDER, glResCache, texLoader, isLowEnd);
        texStore.setMemoryLimits(7*screenTexBytes, 8*screenTexBytes);
		SaveHandler sh = new SaveHandler(afs, notifier, isDebugSigned ? PackageLimit.WARNING : PackageLimit.NONE);
		
		SharedGlobals sharedGlobals = new SharedGlobals(sfw, notifier);
		try {
			if (isVNDS) readVNDSGlobalSav(sharedGlobals, afs);
			sharedGlobals.load();
		} catch (IOException ioe) {
			notifier.d("Error loading shared globals", ioe);
			try { sharedGlobals.save(); } catch (IOException e) { }
		}
		
		ITimer timer = new Timer();
		try {
			timer.load(sharedGlobals);
		} catch (IOException ioe) {
			notifier.d("Error loading timer", ioe);
			try { timer.save(sharedGlobals); } catch (IOException e) { }
		}
		
		ISeenLog seenLog = new NullSeenLog();
		IAnalytics an = new NullAnalytics();
		
		ES1ShaderFactory shfac = new ES1ShaderFactory(notifier);
		SystemLib syslib = new SystemLib(context, this, guiHandler, isLowEnd);
		ImageFactory imgfac = new ImageFactory(fontManager, texStore, seenLog, notifier, config,
				novelConfig.getWidth(), novelConfig.getHeight());
		ImageFxLib imgfxlib = new ImageFxLib(imgfac);
		SoundFactory sndfac = new SoundFactory(afs, sndF, seenLog, notifier);
		VideoFactory vidfac = new VideoFactory(context, afs, videoF, videoF, seenLog, notifier);
		GUIFactory guifac = new GUIFactory(imgfac, notifier, context, guiHandler);
		IInput in = new InputAdapter(input);
		ScriptLib scrlib = new ScriptLib(afs, assets, notifier);
		TweenLib tweenLib = new TweenLib(notifier, imgfac, shfac);
		IStorage globals = new Globals();
		
		ImageState is = new ImageState(imgfac, novelConfig.getWidth(), novelConfig.getHeight());		
		SoundState ss = new SoundState();
		VideoState vs = new VideoState();
		TextState ts = new TextState();
		
		novel = new Novel(novelConfig, imgfac, is, imgfxlib, sndfac, ss, vidfac, vs, guifac, ts, notifier,
				in, shfac, syslib, sh, scrlib, tweenLib, sharedGlobals, globals, seenLog, an, timer,
			afs, isVNDS);
		if (isVNDS) {
			novel.setBootstrapScripts("builtin/vnds/main.lua");
		}
        luaSerializer = new EnvLuaSerializer();
        sh.setNovel(novel, luaSerializer);
        
        notifier.setTextState(ts);
	}
	
	private static Dim readImageINI(IFileSystem fs, String path, INovelConfig novelConfig) {
		int imgWidth = novelConfig.getWidth();
		int imgHeight = novelConfig.getHeight();
		
		try {
			InputStream in = fs.newInputStream(path);
			BufferedReader bin = null;
			try {
				bin = new BufferedReader(new InputStreamReader(in, "UTF-8"), 4096);
				
				INIFile imgConfig = new INIFile();
				imgConfig.read(bin);
				imgWidth = imgConfig.getInt("width", imgWidth);
				imgHeight = imgConfig.getInt("height", imgHeight);
			} finally {
				if (bin != null) {
					bin.close();
				} else {
					in.close();
				}
			}
		} catch (FileNotFoundException fnfe) {
			//Ignore
		} catch (Exception e) {
			Log.w("Game.init()", "Error reading img/img.ini", e);
		}
		return new Dim(imgWidth, imgHeight);		
	}
	
	private static void readVNDSGlobalSav(SharedGlobals out, IFileSystem fs) {
		try {
			InputStream in = null;
			if (fs.getFileExists("save/global.sav")) {
				in = fs.newInputStream("save/global.sav");					
			} else if (fs.getFileExists("save/GLOBAL.sav")) {
				in = fs.newInputStream("save/GLOBAL.sav");					
			}
			if (in != null) {
				boolean wasAutoSave = out.getAutoSave();
				try {
					out.setAutoSave(false);
					byte[] bytes = StreamUtil.readFully(in);					
					VNDSUtil.readDSGlobalSav(out, new ByteArrayInputStream(bytes));
				} catch (ParserConfigurationException e) {
					Log.d(AndroidVN.TAG, "Error reading global.sav", e);
				} catch (SAXException e) {
					Log.d(AndroidVN.TAG, "Error reading global.sav", e);
				} finally {
					out.setAutoSave(wasAutoSave);
					in.close();
				}
			}
		} catch (IOException ioe) {
			Log.d(AndroidVN.TAG, "Error reading global.sav", ioe);
		}
		
	}
	
	public void nativeStop(final boolean force) {
		guiHandler.post(new Runnable() {
			public void run() {
				if (force) {
					context.finish();
				} else {
					context.askQuit();
				}
			}
		});
	}
	
	public synchronized void dispose() {
		if (fontManager != null) {
			fontManager.dispose();
			fontManager = null;
		}		

		if (novel != null) {
			novel.savePersistent();

			SoundFactory soundFac = novel.getSoundFactory();
			if (soundFac != null) {
				soundFac.dispose();
			}
			
			novel = null;
			luaRunning = false;
		}

		if (afs != null) {
			afs.close();
		}		
	}
	
	public synchronized void start() {
		animator = new FPSAnimator("GameThread", new Runnable() {
			long lastTime = System.nanoTime();
			
			public void run() {
				long time = System.nanoTime();
				update((time-lastTime) / 1000000000.0);				
				lastTime = time;
			}
		}, 60);
		animator.start();		
	}
	
	public synchronized void stop() {
		if (animator != null) {
			animator.stop();
			animator = null;
		}
	}
	
	/**
	 * Warning: must be called from the GUI thread.
	 */
	public void restart() {
		restart("titlescreen");
	}
	protected void restart(final String mainFunc) {
		config.loadAndroid(context);
		novel.restart(luaSerializer, config, mainFunc);
        luaRunning = true;
		
		painter.repaint();
	}
	
	protected synchronized void update(double dt) {
		IImageState is = novel.getImageState();
		input.update(realX, realY, is.getWidth()/(double)realW,
				is.getHeight()/(double)realH);
		input.setEnabled(true);
		
		boolean changed = false;
		if (realW <= 0 || realH <= 0) {
			changed = true; //Keep trying to repaint if bounds not set yet
		} else {
			ILayer rootLayer = is.getRootLayer();
			
			//Update soft menu button
			if (softMenuMode != SoftMenuMode.DISABLED) {
				if (softMenuDrawable == null) {
					softMenuDrawable = createSoftMenuDrawable();
				}
				if (softMenuDrawable != null) {
					changed |= softMenuDrawable.update(rootLayer, novel.getInput(), 1.0);				
					if (softMenuDrawable.consumePress()) {
						guiHandler.post(new Runnable() {
							public void run() {
								context.openOptionsMenu();
							}
						});
					}
				}
			} else if (softMenuDrawable != null) {
				softMenuDrawable.destroy();
				softMenuDrawable = null;
			}

			//Check if auto read should be cancelled
			if (isAutoRead() && novel.getInput().consumeTextContinue()) {
				toggleAutoRead();
			}				
			
			//Update novel
			changed |= novel.update();
			
			//Update skip indicator
			if (novel.isSuperSkip()) {
				if (superSkipDrawable == null) superSkipDrawable = createSuperSkipDrawable();
				changed |= superSkipDrawable.update(rootLayer, novel.getInput(), 1.0);
			} else {
				if (superSkipDrawable != null) {
					superSkipDrawable.destroy();
					superSkipDrawable = null;
					changed = true;
				}
			}
			
			//Update auto read indicator
			if (isAutoRead()) {
				if (autoReadDrawable == null) {
					autoReadDrawable = createAutoReadDrawable();
				}
				changed |= autoReadDrawable.update(rootLayer, novel.getInput(), 1.0);
			} else {
				if (autoReadDrawable != null) {
					autoReadDrawable.destroy();
					autoReadDrawable = null;
					changed = true;
				}
			}
			
			//Update clock
			if (clockDrawable != null) {
		        if (isDebugSigned) {
		        	StringBuilder sb = new StringBuilder();
		        	sb.append(StringUtil.formatMemoryAmount(texStore.getMemoryUsage(3000)))
		        			.append("/").append(StringUtil.formatMemoryAmount(texStore.getMemoryUsage()));
		        	clockDrawable.setText(sb.toString());
		        	changed = true;
		        } else {
			        clockDrawable.setText(getDateString());		        	
		        }
		        changed |= clockDrawable.update(rootLayer, novel.getInput(), 1.0);
			}
		}
		
		if (changed) {
			painter.repaint();
		}
	}
	
	public void initGL(GLManager glm, EGLConfig config, int rwidth, int rheight) {
		glResCache.initGL(glm);
		texStore.initGL(glm);
	}	
	public void updateGL(GLManager glm) {
		glResCache.updateGL(glm);
		texStore.updateGL(glm);
	}
		
	//Can get called from any thread
	public void onPause() {
		final FPSAnimator a;		
		synchronized (this) {
			a = animator;
			novel.getSoundState().setPaused(true);			
		}
		
		if (a != null) a.stop();
	}
	
	//Can get called from any thread
	public void onResume() {
		final FPSAnimator a;
		synchronized (this) {
			a = animator;
			novel.getSoundState().setPaused(false);
			painter.repaint();
		}
		
		if (a != null) a.start();		
	}
	
	public void onFocusChanged(boolean hasFocus) {
		if (input != null) {
			input.clear();
		}
	}
	
	public void openScriptDebugJump() {
		try {
			StringBuilder sb = new StringBuilder("local __c = {");
			Collection<String> files = new ArrayList<String>();
			afs.getFiles(files, "script", true);
			int t = 0;
			for (String s : files) {
				if (t > 0) sb.append(", ");
				sb.append('"').append(ParserUtil.escape(s.substring(7))).append('"');
				t++;
			}
			sb.append("}\n");
			sb.append("call(__c[choice(__c)])\n");
			novel.eval(sb.toString());
		} catch (IOException ioe) {
			novel.onScriptError(ioe);
		} catch (LuaException e) {
			novel.onScriptError(e);
		}
	}
	
	public void toggleAutoRead() {
		config.set(NovelPrefs.AUTO_READ, !isAutoRead());
		onPrefsChanged();
	}
	
	public Renderer getRenderer(ESManager<?> glm) {
		IImageState is = novel.getImageState();		
		if (renderer == null || renderer.getGLManager() != glm) {
			ImageFactory imgfac = (ImageFactory)novel.getImageFactory();
			ISystemLib syslib = novel.getSystemLib();
			boolean allowCoordinateRounding = isLowEnd;
			AndroidRenderEnv env = new AndroidRenderEnv(vwidth, vheight,
					realX, realY, realW, realH, screenW, screenH, syslib.isTouchScreen(),
					textSize, displayDensity, allowCoordinateRounding);
		
			is.setRenderEnv(env);
			/*if (glm instanceof ES2Manager) {
				renderer = Renderer.newInstance(env, glm, imgfac, texStore);
			} else*/ {
				renderer = Renderer.newInstance(env, (ES1Manager)glm, imgfac, texStore);				
			}
		}
		return renderer;
	}

	private ITextDrawable createOSDDrawable() {
		ITextDrawable td = novel.getImageFactory().createTextDrawable();
		td.setDefaultStyle(TextLayoutUtil.getDefaultStyle().extend(new TextStyle(null, FontStyle.BOLD, 25, 9)));
		td.setZ(Short.MIN_VALUE);
		td.setClipEnabled(false);
		td.setPadding(Math.min(screenW, screenH) >> 7);
		return td;
	}
	
	protected ITextDrawable createSuperSkipDrawable() {
		ITextDrawable td = createOSDDrawable();
		td.setText(context.getString(R.string.dialog_superskip));
		return td;
	}
	
	protected ITextDrawable createAutoReadDrawable() {
		ITextDrawable td = createOSDDrawable();
		td.setText(context.getString(R.string.dialog_autoread));
		return td;
	}

	protected IButtonDrawable createSoftMenuDrawable() {
		IImageFactory imgfac = novel.getImageFactory();
		ITexture normalI = imgfac.getTexture("android/softmenu-normal", null, false);
		if (normalI == null) {
			int[] pixels = new int[32*32];
			Arrays.fill(pixels, 0xFFFFFFFF);
			normalI = imgfac.createTexture(pixels, 32, 32, 1, 1);
		}
		ITexture rolloverI = imgfac.getTexture("android/softmenu-rollover", null, true);		
		
		IButtonDrawable d = imgfac.createButtonDrawable();
		d.setNormalTexture(normalI);
		d.setRolloverTexture(rolloverI);
		d.setPressedTexture(rolloverI);
		//d.setScale(displayDensity);
        d.setZ(Short.MIN_VALUE);
        d.setClipEnabled(false);
		d.setTouchMargin(Math.min(screenW, screenH) >> 5);
        return d;
	}
	
	protected ITextDrawable createClockDrawable() {
		ITextDrawable td = createOSDDrawable();
        return td;
	}
	
	void repaint() {
		painter.repaint();		
	}
	
	public void onPrefsChanged() {
		renderer = null;

		novel.onPrefsChanged(config);
		
		textSize = ((Double)config.get(TEXT_SIZE)).floatValue();
		minVisibleLines = Math.max(1, config.get(MIN_VISIBLE_LINES));

		useEmbeddedFonts = config.get(USE_EMBEDDED_FONTS);		
		Typeface defaultFont = null;
		if (useEmbeddedFonts) {
			TextStyle defaultStyle = config.get(NovelPrefs.TEXT_STYLE);
			if (defaultStyle != null) {
				defaultFont = fontManager.getFont(defaultStyle.getFontName());
			}
		}
		fontManager.setDefaultFont(defaultFont);
		
		novel.getNotifier().setMinimumLevel(config.get(ERROR_LEVEL));
		((SaveHandler)novel.getSaveHandler()).setQuicksave(config.get(SAVE_MODE) == SaveMode.quicksave);
		((InputAdapter)novel.getInput()).setLongPressDelay(config.get(LONG_PRESS_DELAY));
		input.setMinTouchPressDelay(config.get(MIN_TOUCH_DELAY));
		
		if (config.get(SHOW_CLOCK)) {
			if (clockDrawable == null) clockDrawable = createClockDrawable();
		} else {
			if (clockDrawable != null) {
				clockDrawable.destroy();
				clockDrawable = null;
			}
		}
		
		renderAnchor = config.get(RENDER_ANCHOR);
		textboxAnchor = config.get(TEXTBOX_ANCHOR);
		textboxAlpha = config.get(TEXTBOX_ALPHA);
		
		selectAssetFolders();
		selectImageFolder();
	}
	
	//Getters
	public AndroidFileSystem getFileSystem() { return afs; }
	public Novel getNovel() { return novel; }
	public AndroidConfig getConfig() { return config; }
	public String getDateString() { return dateFormat.format(new Date()); }
	public ITextDrawable getClockDrawable() { return clockDrawable; }
	public SoftMenuMode getSoftMenuMode() { return softMenuMode; }
	public IDrawable getSoftMenuDrawable() { return softMenuDrawable; }
	public ITextDrawable getSuperSkipDrawable() { return superSkipDrawable; }
	public ITextDrawable getAutoReadDrawable() { return autoReadDrawable; }
	public int getTextBoxAlpha() { return textboxAlpha; }
	public int getRenderAnchor() { return renderAnchor; }
	public float getDisplayDensity() { return displayDensity; }
	public float getTextScale() { return textSize; }
	public int getTextBoxAnchor(boolean allowScriptOverride) {
		if (allowScriptOverride && novel != null) {
			SystemLib syslib = (SystemLib)novel.getSystemLib();
			if (syslib.isTextFullscreen()) {
				return 0;
			}
		}
		return textboxAnchor;
	}
	public boolean isAutoRead() { return config.get(NovelPrefs.AUTO_READ); }
	public int getWidth() { return vwidth; }
	public int getHeight() { return vheight; }
	
	//Setters
	public void setSoftMenu(SoftMenuMode m) {
		softMenuMode = m;
	}
		
	void setScreenBounds(int x, int y, int w, int h, int sw, int sh) {
		if (realX != x || realY != y || realW != w || realH != h
				|| screenW != sw || screenH != sh)
		{
			renderer = null;
			
			realX = x;
			realY = y;
			realW = w;
			realH = h;
			
			screenW = sw;
			screenH = sh;
						
			selectAssetFolders();
			selectImageFolder();
			
			if (novel != null) {				
				if (luaRunning) {
					try {
						//Needed to exit textlog mode, a screen size changes breaks its layout
						novel.eval("if getMode() ~= \"main\" then edt.addEvent(setMode) end");
					} catch (LuaException e) {
						novel.onScriptError(e);
					}
				}
			}
						
			painter.repaint();
		}
	}
	
	protected void selectImageFolder() {
		try {
			Dim screen = new Dim(screenW, screenH);
			FileResolutionOption opt = imageResolutionPicker.select(screen, false);
			if (opt == null) {
				opt = imageResolutionPicker.select(screen, true);
			}
			
			//Log.d(AndroidVN.TAG, "selectImageFolder: " + opt);
			
			if (opt == null) {
				throw new IOException("Image resolution picker returned null");
				//setImageFolder(GameUtil.IMAGE_FOLDER, getWidth(), getHeight());
			} else {
				if (novel != null) {
					ImageFactory imgfac = (ImageFactory)novel.getImageFactory();
					imgfac.setImageSize(opt.getWidth(), opt.getHeight());
				}
				texStore.setImageFolder(opt.getFolder());
			}
		} catch (IOException ioe) {
			Log.w(AndroidVN.TAG, "Error changing image folder", ioe);
		}
				
		painter.repaint();
	}
	
	private void selectAssetFolders() {
		final Dim screen = new Dim(screenW, screenH);

		//Select image folder
		FileResolutionOption opt = assetImageResolutionPicker.select(screen, false);
		if (opt == null) opt = assetImageResolutionPicker.select(screen, true);

		//Log.d(AndroidVN.TAG, "selectAssetFolder: " + opt);
		
		double assetImageScale = 1;
		if (novel != null && opt != null && opt.getWidth() > 0 && opt.getHeight() > 0) {
			IImageState imageState = novel.getImageState();
			assetImageScale = Math.min(imageState.getWidth() / (double)opt.getWidth(), imageState.getHeight() / (double)opt.getHeight());
		}
		texStore.setAssetImageFolder(opt != null ? opt.getFolder() : ASSET_IMG_FOLDER, assetImageScale);
		
		//Select video folder		
		opt = videoResolutionPicker.select(screen, false);
		if (opt == null) opt = videoResolutionPicker.select(screen, true);
		
		if (novel != null) {
			VideoFactory vfac = (VideoFactory)novel.getVideoFactory();
			vfac.setAssetVideoFolder(opt != null ? opt.getFolder() : vfac.getVideoFolder());
		}
		
		painter.repaint();
	}
		
}

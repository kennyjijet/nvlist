package nl.weeaboo.android.vn;

public enum SaveMode {

	full, quicksave;
	
}

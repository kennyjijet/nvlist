package nl.weeaboo.vn.android.impl;

import java.io.FileDescriptor;
import java.io.IOException;
import java.io.ObjectInputStream;

import nl.weeaboo.android.FileSegment;
import nl.weeaboo.android.vn.AndroidVN;
import nl.weeaboo.lua2.io.LuaSerializable;
import nl.weeaboo.vn.INotifier;
import nl.weeaboo.vn.impl.base.BaseVideo;
import android.content.pm.ActivityInfo;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnCompletionListener;
import android.media.MediaPlayer.OnErrorListener;
import android.media.MediaPlayer.OnPreparedListener;
import android.media.MediaPlayer.OnVideoSizeChangedListener;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

@LuaSerializable
public class Movie extends BaseVideo {

	private static final long serialVersionUID = AndroidImpl.serialVersionUID;
	
	protected static final int syncWaitTime = 3000;
	
	private VideoFactory vfac;
	private final INotifier notifier;
	private final String videoFolderPrefix;	
	
	transient volatile SurfaceView view;
	transient MediaPlayer mp;
	transient volatile boolean mpPreparing;
	transient volatile boolean mpPrepared;
	
	public Movie(VideoFactory fac, String folderPrefix) {
		vfac = fac;
		notifier = fac.getNotifier();
		videoFolderPrefix = folderPrefix;
	}
	
	//Functions
	protected void destroy() {		
		if (mp != null) {
			stop();

			final AndroidVN context = vfac.getContext();
			if (context != null) {			
				context.runOnUiThread(new Runnable() {
					public void run() {
						context.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
						context.setContentView(context.createGLView());
					}
				});
			}
		}
	}
	
	@Override
	protected void _prepare() throws IOException {	
	}	
	
	@Override
	protected void _start() throws IOException {
		final VideoFactory fac = vfac;
		if (fac == null) return;
		
		final AndroidVN context = fac.getContext();
		if (context == null) return;
		
		final String relpath = getVideoPath();
		final float volume = (float)getVolume();
		final FileSegment fileseg = fac.getFileSegment(videoFolderPrefix + relpath);

		Runnable gr = new Runnable() {
			public void run() {
				context.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
				view = new SurfaceView(context) {
				    protected void onMeasure(int wm, int hm) {
				        int width = getDefaultSize(1, wm);
				        int height = getDefaultSize(1, hm);
				        
				        if (mp != null) {
				        	int vw = mp.getVideoWidth();
				        	int vh = mp.getVideoHeight();
				        	float scale = Math.min(width/(float)vw, height/(float)vh);
				        	width = Math.max(0, Math.min(width, Math.round(scale*vw)));
				        	height = Math.max(0, Math.min(height, Math.round(scale*vh)));
				        }
				        //width = height = Math.min(width, height);
				        //System.out.println(width+"x"+height);					    	
				    	setMeasuredDimension(width, height);
				    }
				    
				    @Override
				    public boolean onTouchEvent(MotionEvent event) {
				    	//System.out.println(event);
				    	if (event.getAction() == MotionEvent.ACTION_DOWN) {
				    		destroy();
				    		return true;
				    	}
				    	return super.onTouchEvent(event);
				    }
				};
				context.setContentView(view);
				SurfaceHolder holder = view.getHolder();
				holder.setType(SurfaceHolder.SURFACE_TYPE_PUSH_BUFFERS);
				
				mpPreparing = true;
				
				Runnable r = new Runnable() {
					public void run() {
						mpPrepared = false;
								
						mp = new MediaPlayer();
						mp.reset();
						
						try {
							FileDescriptor fd = fileseg.open();
							try {
								mp.setDataSource(fd, fileseg.getOffset(), fileseg.getLength());
							} finally {
								fileseg.close();
							}
						} catch (IOException ioe) {
							notifier.w("Error playing video ("+relpath+")", ioe);
							destroy();
							return;
						}

						mp.setDisplay(view.getHolder());
						mp.setAudioStreamType(AudioManager.STREAM_MUSIC);
						mp.setScreenOnWhilePlaying(false);
						mp.setLooping(false);
						mp.setVolume(volume, volume);				
						mp.setOnPreparedListener(new OnPreparedListener() {
							public void onPrepared(MediaPlayer m) {
								if (mp == m) {
									mpPreparing = false;
									mpPrepared = true;							
								}
							}
						});
						mp.setOnCompletionListener(new OnCompletionListener() {
							public void onCompletion(MediaPlayer m) {
								if (mp == m) {
									destroy();
									mpPrepared = false;
								}
								try {
									m.release();
								} catch (IllegalStateException ise) { }
							}
						});
						mp.setOnErrorListener(new OnErrorListener() {
							public boolean onError(MediaPlayer m, int what, int extra) {
								if (mp == m) {
									destroy();
									mpPrepared = false;
									notifier.w("Error playing video ("+relpath+") what="+what+" extra="+extra);
								}
								try {
									m.release();
								} catch (IllegalStateException ise) { }
								return true;
							}
						});
						mp.setOnVideoSizeChangedListener(new OnVideoSizeChangedListener() {
							public void onVideoSizeChanged(MediaPlayer m, int what, int extra) {
								if (mp == m) {
									SurfaceHolder holder = view.getHolder();
									int w = Math.max(mp.getVideoWidth(), mp.getVideoHeight());
									int h = Math.min(mp.getVideoWidth(), mp.getVideoHeight());
									holder.setFixedSize(w, h);
									view.requestLayout();
									view.invalidate();
								}
							}
						});
						
						try {
							mp.prepare();
							mpPrepared = true;										
							mpPreparing = false;					
							mp.start();
						} catch (Exception e) {
							mpPreparing = false;	
							notifier.w("Error playing video ("+relpath+")");
							destroy();
						}
					}
				};
				post(r);
				
			}
		};
		context.runOnUiThread(gr);		
	}

	@Override
	protected void _pause() {
		Runnable r = new Runnable() {
			public void run() {
				if (mp != null && mpPrepared) {
					try { mp.pause(); } catch (IllegalStateException ise) { }
				}
			}
		};
		post(r);
	}

	@Override
	protected void _resume() {
		Runnable r = new Runnable() {
			public void run() {
				if (mp != null && mpPrepared) {
					try { mp.start(); } catch (IllegalStateException ise) { }
				}
			}
		};
		post(r);
	}
	
	@Override
	protected void _stop() {
		Runnable r = new Runnable() {
			public void run() {
				if (mp != null) {
					if (mpPrepared) {
						try {
							mp.stop();
						} catch (IllegalStateException ise) { }
					}
					destroy();
					try {
						mp.release();
					} catch (IllegalStateException ise) { }
					mp = null;
					mpPrepared = false;
				}
			}
		};
		post(r);
	}

	@Override
	protected void onVolumeChanged() {
		final float volume = (float)getVolume();
		
		Runnable r = new Runnable() {
			public void run() {
				if (mp != null) {
					mp.setVolume(volume, volume);
				}
			}
		};
		post(r);
	}
	
	protected void post(Runnable r) {
		final VideoFactory fac = vfac;
		if (fac != null) {
			fac.getVideoHandler().post(r);
		}
	}
	
	private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
		in.defaultReadObject();

		//Restart automatically when loaded
		if (!isStopped()) {
			_start();
			if (isPaused()) {
				_pause();
			}
		}
	}
			
	//Getters
	
	//Setters
	
}

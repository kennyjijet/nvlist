package nl.weeaboo.vn.android.impl;

import nl.weeaboo.lua2.io.LuaSerializable;
import nl.weeaboo.vn.impl.base.BaseImageDrawable;

@LuaSerializable
public class ImageDrawable extends BaseImageDrawable {

	private static final long serialVersionUID = AndroidImpl.serialVersionUID;
	
	public ImageDrawable() {
	}

	//Functions
	
	//Getters	
	
	//Setters
	
}

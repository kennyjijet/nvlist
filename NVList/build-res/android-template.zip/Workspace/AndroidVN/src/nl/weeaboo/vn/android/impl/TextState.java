package nl.weeaboo.vn.android.impl;

import nl.weeaboo.lua2.io.LuaSerializable;
import nl.weeaboo.vn.impl.base.BaseTextState;

@LuaSerializable
public class TextState extends BaseTextState {

	private static final long serialVersionUID = AndroidImpl.serialVersionUID;

	public TextState() {		
	}
	
	//Functions
	
	//Getters
	
	//Setters
	
}

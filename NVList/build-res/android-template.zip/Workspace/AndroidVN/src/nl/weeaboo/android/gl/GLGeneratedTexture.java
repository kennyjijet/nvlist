package nl.weeaboo.android.gl;

import nl.weeaboo.lua2.io.LuaSerializable;
import android.graphics.Bitmap;

@LuaSerializable
public class GLGeneratedTexture extends GLTexture {

	private static final long serialVersionUID = -7475904880071086691L;
	
	public GLGeneratedTexture(int id, int w, int h) {
		super(id, w, h, 0, 0, w, h);
	}

	//Functions
	
	//Getters
	public Bitmap getBitmap() {
		return bitmap;
	}
	
	//Setters
	
}

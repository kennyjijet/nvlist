package nl.weeaboo.vn.android.impl;

import nl.weeaboo.android.gles.ES1Manager;
import nl.weeaboo.android.gles.ESManager;
import nl.weeaboo.android.gles.ESTextureStore;
import nl.weeaboo.android.vn.AndroidRenderEnv;
import nl.weeaboo.vn.impl.base.BaseRenderer;

public abstract class Renderer extends BaseRenderer {

	private final ESManager<?> glm;
	protected final ImageFactory imgfac;
	protected final ESTextureStore texStore;
	private final DrawBuffer drawBuffer;
	
	protected Renderer(AndroidRenderEnv env, ESManager<?> glm, ImageFactory imgfac, ESTextureStore ts) {
		super(env, null);
		
		this.glm = glm;
		this.imgfac = imgfac;
		this.texStore = ts;
		this.drawBuffer = new DrawBuffer(env);
	}

	//Functions
	public static Renderer newInstance(AndroidRenderEnv env, ES1Manager glm, ImageFactory imgfac,
			ESTextureStore ts)
	{
		return new ES1Renderer(env, glm, imgfac, ts);
	}
	
	@Override
	public DrawBuffer getDrawBuffer() {
		return drawBuffer;
	}

	//Getters
	public ESManager<?> getGLManager() {
		return glm;
	}
	
	//Setters
	
}

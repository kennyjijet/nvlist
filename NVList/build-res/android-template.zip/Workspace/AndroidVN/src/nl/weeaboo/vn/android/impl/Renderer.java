package nl.weeaboo.vn.android.impl;

import javax.microedition.khronos.opengles.GL;
import javax.microedition.khronos.opengles.GL10;

import nl.weeaboo.android.gl.GLGeneratedTexture;
import nl.weeaboo.android.gl.GLImageTexture;
import nl.weeaboo.android.gl.GLTexRect;
import nl.weeaboo.android.gl.GLTexture;
import nl.weeaboo.android.gl.TextureCache;
import nl.weeaboo.vn.ITexture;
import nl.weeaboo.vn.impl.base.BaseRenderer;

public abstract class Renderer extends BaseRenderer {

	protected final TextureCache texCache;
	protected final double displayDensity;
	protected final double textScale;
	
	protected Renderer(TextureCache tc, int w, int h, int rx, int ry, int rw, int rh,
			int sw, int sh, double displayDensity, double textScale)
	{
		super(w, h, rx, ry, rw, rh, sw, sh, null);
		
		this.texCache = tc;
		this.displayDensity = displayDensity;
		this.textScale = textScale;
	}

	//Functions
	public static Renderer newInstance(GL10 gl, TextureCache tc, int w, int h, int rx, int ry, int rw, int rh,
			int sw, int sh, double displayDensity, double textScale)
	{
		return new RendererGL10(gl, tc, w, h, rx, ry, rw, rh, sw, sh, displayDensity, textScale);
	}
	
	public void forceLoad(GL gl, ITexture tex) {
		if (tex instanceof TextureAdapter) {
			TextureAdapter adapter = (TextureAdapter)tex;
			GLTexRect internalRect = adapter.getTexRect();
			GLTexture internal = internalRect.getTexture();
			if (internalRect.isDisposed()) {
				if (internal instanceof GLImageTexture) {
					TextureAdapter ta = texCache.get(gl, adapter.getId());
					if (ta != null) {
						internalRect = ta.getTexRect();
						if (internalRect != null && !internalRect.isDisposed()) {
							adapter.setTexRect(internalRect, ta.getScaleX(), ta.getScaleY());
						}
					}
				} else if (internal instanceof GLGeneratedTexture) {
					GLGeneratedTexture gentex = (GLGeneratedTexture)internal;
					internal = texCache.generateTexture(gl, gentex.getBitmap());
					internalRect = internal.getTexRect(0);
					if (internalRect != null && !internalRect.isDisposed()) {
						adapter.setTexRect(internalRect, adapter.getScaleX(), adapter.getScaleY());
					}
				} else {
					throw new RuntimeException("Unreloadable texture type: " + tex.getClass());
				}				
			}
		} else {
			throw new RuntimeException("Unsupported texture type: " + tex.getClass());
		}
	}

	//Getters
	public abstract GL getGL();
	
	public GLTexture createTexture(int argb[], int w, int h) {
		return texCache.generateTexture(getGL(), argb, w, h);
	}
	
	public GLTexture createTexture(int w, int h) {
		return texCache.generateTexture(getGL(), w, h);
	}
	
	public double getDisplayDensity() {
		return displayDensity;
	}
	
	public double getTextScale() {
		return textScale;
	}
	
	//Setters
	
}

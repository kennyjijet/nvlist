package nl.weeaboo.vn.android.impl;

import javax.microedition.khronos.opengles.GL;
import javax.microedition.khronos.opengles.GL10;

import nl.weeaboo.android.gl.GLGeneratedTexture;
import nl.weeaboo.android.gl.GLImageTexture;
import nl.weeaboo.android.gl.GLTexRect;
import nl.weeaboo.android.gl.GLTexture;
import nl.weeaboo.android.gl.TextureCache;
import nl.weeaboo.android.vn.AndroidRenderEnv;
import nl.weeaboo.android.vn.DrawBuffer;
import nl.weeaboo.vn.ITexture;
import nl.weeaboo.vn.impl.base.BaseRenderer;
import android.graphics.Bitmap;

public abstract class Renderer extends BaseRenderer {

	protected final TextureCache texCache;
	private final DrawBuffer drawBuffer;
	
	protected Renderer(AndroidRenderEnv env, GL gl, TextureCache tc) {
		super(env, null);
		
		this.texCache = tc;
		this.drawBuffer = new DrawBuffer(env, gl);
	}

	//Functions
	public static Renderer newInstance(AndroidRenderEnv env, GL10 gl, TextureCache tc) {
		return new RendererGL10(env, gl, tc);
	}
	
	@Override
	public DrawBuffer getDrawBuffer() {
		return drawBuffer;
	}
	
	public void forceLoad(GL gl, ITexture tex) {
		if (tex instanceof TextureAdapter) {
			TextureAdapter adapter = (TextureAdapter)tex;
			GLTexRect internalRect = adapter.getTexRect();
			GLTexture internal = internalRect.getTexture();
			if (internalRect.isDisposed()) {
				if (internal instanceof GLImageTexture) {
					TextureAdapter ta = texCache.get(gl, adapter.getId());
					if (ta != null) {
						internalRect = ta.getTexRect();
						if (internalRect != null && !internalRect.isDisposed()) {
							adapter.setTexRect(internalRect, ta.getScaleX(), ta.getScaleY());
						}
					}
				} else if (internal instanceof GLGeneratedTexture) {
					GLGeneratedTexture gentex = (GLGeneratedTexture)internal;
					Bitmap bitmap = gentex.getBitmap();
					if (bitmap != null) {
						internal = texCache.generateTexture(gl, bitmap);
						internalRect = internal.getTexRect(0);
						if (internalRect != null && !internalRect.isDisposed()) {
							adapter.setTexRect(internalRect, adapter.getScaleX(), adapter.getScaleY());
						}
					}
				} else {
					throw new RuntimeException("Unreloadable texture type: " + tex.getClass());
				}				
			}
		} else {
			throw new RuntimeException("Unsupported texture type: " + tex.getClass());
		}
	}

	//Getters
	public abstract GL getGL();
	
	//Setters
	
}

package nl.weeaboo.vn.android.impl;

import nl.weeaboo.android.gles.ESManager;
import nl.weeaboo.android.gles.ESTextureStore;
import nl.weeaboo.android.vn.AndroidRenderEnv;
import nl.weeaboo.vn.IRenderer;
import nl.weeaboo.vn.impl.base.BaseRenderer;

public abstract class Renderer extends BaseRenderer {

	private final ESManager<?> glm;
	protected final ImageFactory imgfac;
	protected final ESTextureStore texStore;
	private final DrawBuffer drawBuffer;
	
	protected Renderer(AndroidRenderEnv env, ESManager<?> glm, ImageFactory imgfac, ESTextureStore ts) {
		super(env, null);
		
		this.glm = glm;
		this.imgfac = imgfac;
		this.texStore = ts;
		this.drawBuffer = new DrawBuffer(env);
	}

	//Functions
	public static Renderer cast(IRenderer r) {
		return (Renderer)r;
	}
	
	@Override
	public DrawBuffer getDrawBuffer() {
		return drawBuffer;
	}

	//Getters
	public ESManager<?> getGLManager() {
		return glm;
	}
	
	//Setters
	
}

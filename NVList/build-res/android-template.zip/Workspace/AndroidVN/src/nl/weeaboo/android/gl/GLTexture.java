package nl.weeaboo.android.gl;

import static javax.microedition.khronos.opengles.GL10.GL_LINEAR_MIPMAP_NEAREST;
import static javax.microedition.khronos.opengles.GL10.GL_TEXTURE_2D;
import static javax.microedition.khronos.opengles.GL10.GL_TEXTURE_MIN_FILTER;
import static nl.weeaboo.android.gl.GLDraw.createCompatibleBitmap;
import static nl.weeaboo.android.gl.GLDraw.isPOT;
import static nl.weeaboo.android.gl.GLDraw.supportsNPOT;
import static nl.weeaboo.android.gl.GLDraw.toPowerOfTwo;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import javax.microedition.khronos.opengles.GL;
import javax.microedition.khronos.opengles.GL10;

import nl.weeaboo.common.Rect2D;
import nl.weeaboo.lua2.io.LuaSerializable;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.opengl.GLUtils;

@LuaSerializable
public abstract class GLTexture implements Serializable {

	private static final long serialVersionUID = 5528938670878294499L;
	
	private transient int texId;
	private int width, height;
	private int cropX, cropY, cropW, cropH;
	private boolean mipmap;
	private Rect2D uv;
	
	protected transient List<GLTexRect> texRects;	
	protected transient boolean serializeBitmap;
	protected transient Bitmap bitmap;
	
	public GLTexture(int id, int w, int h, int cx, int cy, int cw, int ch) {
		texId = id;
		width = w;
		height = h;
		
		cropX = cx;
		cropY = cy;
		cropW = cw;
		cropH = ch;
		
		texRects = new ArrayList<GLTexRect>();
		texRects.add(new GLTexRect(null, this, cx, cy, cw, ch));

		uv = new Rect2D(cx, cy, cw, ch);
		serializeBitmap = true;
	}
	
	//Functions
	public void dispose() {
		texId = 0;
	}
	
	public void disposePixels() {
		bitmap = null;
	}
	
	private void writeObject(ObjectOutputStream out) throws IOException {
		out.defaultWriteObject();
		
		out.writeInt(texRects.size());
		for (GLTexRect tr : texRects) {
			out.writeObject(tr);
		}
		
		out.writeBoolean(serializeBitmap);
		if (serializeBitmap) {
			bitmap.compress(Bitmap.CompressFormat.PNG, 100, out);
		}
	}
	private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
		in.defaultReadObject();
		
		int texRectsL = in.readInt();
		texRects = new ArrayList<GLTexRect>(texRectsL);
		for (int n = 0; n < texRectsL; n++) {
			texRects.add((GLTexRect)in.readObject());
		}
		
		serializeBitmap = in.readBoolean();
		if (serializeBitmap) {
			bitmap = BitmapFactory.decodeStream(in);
		}
	}	
	
	public void setPixels(GL gl, int argb[], int w, int h) {
		Bitmap bitmap = Bitmap.createBitmap(argb, width, height, Bitmap.Config.ARGB_8888);
		setPixels(gl, bitmap);
	}

	public void setPixels(GL gl, Bitmap b) {
		setPixels(gl, b, false);
	}
	
	protected  void setPixels(GL gl, Bitmap b, boolean mipmap) {
		if (bitmap != b && bitmap != null) {
			bitmap.recycle();
		}
		
		this.bitmap = b;
		this.mipmap = mipmap;
		
		if (gl == null) {
			dispose(); //Marks texture as dirty
		} else {
			if (texId == 0) {
				throw new IllegalStateException("Can't set pixels for a texture that's disposed");
			}
				
			GL10 gl10 = (GL10)gl;
	        gl10.glBindTexture(GL_TEXTURE_2D, texId);
	        if (mipmap) {
		        gl10.glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_NEAREST);	        	
	        }
	        
	        boolean needsPadding = !supportsNPOT(gl) && !isPOT(bitmap.getWidth(), bitmap.getHeight());
	        if (!mipmap && !needsPadding) { //Some GLES NPOT extensions don't allow mipmaps to be used.
	            width = bitmap.getWidth();
	            height = bitmap.getHeight();
            	GLUtils.texImage2D(GL_TEXTURE_2D, 0, bitmap, 0);
	        } else {
	        	
	    		//Pad the bitmap up to an allowable size
	        	int bw = bitmap.getWidth();
	        	int bh = bitmap.getHeight();
	    		int pw = toPowerOfTwo(bw);
	    		int ph = toPowerOfTwo(bh);
				Bitmap padded = createCompatibleBitmap(gl, pw, ph, bitmap);	        	
	        	
				//Copy pixels to padded one row at a time
				int[] rowPixels = new int[bw];
				for (int y = 0; y < bh; y++) {
					bitmap.getPixels(rowPixels, 0, bw, 0, y, bw, 1);
					padded.setPixels(rowPixels, 0, bw, 0, y, bw, 1);
				}
				
	            width = padded.getWidth();
	            height = padded.getHeight();
	            
	        	GLUtils.texImage2D(GL_TEXTURE_2D, 0, padded, 0);
	        	if (mipmap) {
		        	int level = 1;
		            while (padded.getWidth() > 1 || padded.getHeight() > 1) {
		            	//Bitmap scaled = scaleHalf(padded);
		            	Bitmap scaled = Bitmap.createScaledBitmap(padded,
		            			Math.max(1, padded.getWidth()/2),
		            			Math.max(1, padded.getHeight()/2), true);
				        padded.recycle();
				        padded = scaled;
				        
			        	GLUtils.texImage2D(GL_TEXTURE_2D, level, padded, 0);
				        level++;
		            }
	        	}
	        	padded.recycle();
	        }
		}
	}	
	
	@Override
	public String toString() {
		return String.format("GLTexture(id=%d)", texId);
	}
		
	//Getters
	public boolean isDisposed() {
		return texId == 0;
	}
	public int getTexId() {
		return texId;
	}
	public int getTexWidth() {
		return width;
	}
	public int getTexHeight() {
		return height;
	}
	public boolean isMipmapped() {
		return mipmap;
	}
	
	public int getCropX() {
		return cropX;
	}
	public int getCropY() {
		return cropY;
	}
	public int getCropWidth() {
		return cropW;
	}
	public int getCropHeight() {
		return cropH;
	}
	
	public Rect2D getUV() {
		return uv;
	}
	
	public Collection<GLTexRect> getTexRects() {
		return texRects;
	}
	public GLTexRect getTexRect(int index) {
		return texRects.get(index);
	}
	public GLTexRect getTexRect(String id) {
		for (GLTexRect tr : texRects) {
			if (id == tr.getId() || (id != null && id.equals(tr.getId()))) {
				return tr;
			}
		}
		return getTexRect(0);
	}
	
	public int[] getARGB() {
		return getARGB(getCropX(), getCropY(), getCropWidth(), getCropHeight());
	}
	public int[] getARGB(int x, int y, int w, int h) {
		final int cx = getCropX();
		final int cy = getCropY();
		final int cw = getCropWidth();
		final int ch = getCropHeight();
		
		if (x < cx || y < cy || w < 0 || h < 0 || x >= cx+cw || y >= cy+ch) {
			throw new IllegalArgumentException(String.format(
					"Subrect out of bounds, rect=(%d, %d, %d, %d) bounds=(%d, %d, %d, %d)",
					x, y, w, h, cx, cy, cw, ch));
		}
		
		int[] dst = new int[getTexWidth() * getTexHeight()];
		bitmap.getPixels(dst, 0, getTexWidth(), getCropX(), getCropY(), getCropWidth(), getCropHeight());
		return dst;
	}
	public int[] getARGBPre() {
		return getARGBPre(getCropX(), getCropY(), getCropWidth(), getCropHeight());
	}
	public int[] getARGBPre(int x, int y, int w, int h) {
		int[] argb = getARGB(x, y, w, h);
		//TODO: Premultiply
		return argb;
	}
	
	//Setters
	
}

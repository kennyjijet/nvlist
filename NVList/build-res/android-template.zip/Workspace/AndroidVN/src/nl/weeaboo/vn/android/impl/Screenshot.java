package nl.weeaboo.vn.android.impl;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.lang.ref.SoftReference;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

import static nl.weeaboo.gl.GLConstants.*;

import nl.weeaboo.android.gles.ESManager;
import nl.weeaboo.common.Rect;
import nl.weeaboo.common.StringUtil;
import nl.weeaboo.lua2.io.LuaSerializable;
import nl.weeaboo.vn.IScreenshot;
import nl.weeaboo.vn.ITexture;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

@LuaSerializable
public class Screenshot implements IScreenshot {

	private static final long serialVersionUID = 1L;
		
	private static SoftReference<ByteBuffer> tempBuffer; //Cached buffer for glReadPixels
	
	private final short z;
	private final boolean isVolatile;
	private boolean cancelled;	
	private int screenWidth, screenHeight;
	protected transient Bitmap bitmap;
	private transient ITexture volatilePixels;
	private boolean isTransient;
	protected boolean isAvailable;
	
	public Screenshot(short z, boolean isVolatile) {
		this.z = z;
		this.isVolatile = isVolatile;
	}
	
	//Functions
	@Override
	@Deprecated
	public final void makeTransient() {
		markTransient();
	}
	
	@Override
	public void markTransient() {
		isTransient = true;
	}
	
	private void writeObject(ObjectOutputStream out) throws IOException {
		out.defaultWriteObject();
		
		boolean write = !isTransient && bitmap != null;
		out.writeBoolean(write);
		if (write) {
			bitmap.compress(Bitmap.CompressFormat.PNG, 100, out);
		}
	}
	
	private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
		in.defaultReadObject();
		
		boolean hasBitmap = in.readBoolean();
		if (hasBitmap) {
			bitmap = BitmapFactory.decodeStream(in);
		}
	}
	
	public Bitmap toBitmap() {
		return bitmap;
	}
	
	@Override
	public void cancel() {
		cancelled = true;
	}
	
	public void save(File file, int downSample) throws IOException {
		FileOutputStream fout = new FileOutputStream(file);
		try {
			boolean done = false;
			if (downSample > 1) {
				try {
					Bitmap scaled = Bitmap.createScaledBitmap(bitmap,
							Math.max(1, bitmap.getWidth() / downSample),
							Math.max(1, bitmap.getHeight() / downSample),
							true);
					scaled.compress(Bitmap.CompressFormat.JPEG, 90, fout);
					if (bitmap != scaled) {
						scaled.recycle();
					}
					done = true;
				} catch (OutOfMemoryError e) {
					//Downscaling the bitmap uses some temporary memory...
				}
			}
			
			if (!done) {
				bitmap.compress(Bitmap.CompressFormat.JPEG, 90, fout);
			}
		} finally {
			try {
				if (fout != null) fout.close();
			} catch (IOException ioe) {
				//Ignore
			}
		}		
	}
	
	@Override
	public String toString() {
		return String.format(StringUtil.LOCALE, "%s[%dx%d]", getClass().getSimpleName(), getPixelsWidth(), getPixelsHeight());
	}
	
	private static void vflip(byte[] buf, int scansize, int lines) {
		byte temp[] = new byte[scansize];

		int end = scansize * lines;
		int t = 0;
		for (int y = 0; y < lines>>1; y++) {
			System.arraycopy(buf, t, temp, 0, scansize);
			System.arraycopy(buf, end - t - scansize, buf, t, scansize);
			System.arraycopy(temp, 0, buf, end - t - scansize, scansize);
			t += scansize;
		}
	}
	
	//Getters
	@Override
	public boolean isAvailable() {
		return !isCancelled() && isAvailable;
	}

	@Override
	public boolean isCancelled() {
		return cancelled;
	}

	@Override
	public int[] getPixels() {
		if (bitmap == null) return null;
		
		int w = getPixelsWidth();
		int h = getPixelsHeight();
		int[] argb = new int[w * h];
		bitmap.getPixels(argb, 0, w, 0, 0, w, h);
		return argb;
	}

	@Override
	public int getPixelsWidth() {
		return bitmap != null ? bitmap.getWidth() : 0;
	}

	@Override
	public int getPixelsHeight() {
		return bitmap != null ? bitmap.getHeight() : 0;
	}

	@Override
	public ITexture getVolatilePixels() {
		return volatilePixels;
	}
	
	@Override
	public short getZ() {
		return z;
	}

	@Override
	public int getScreenWidth() {
		return screenWidth;
	}

	@Override
	public int getScreenHeight() {
		return screenHeight;
	}
	
	@Override
	public boolean isTransient() {
		return isTransient;
	}

	@Override
	public boolean isVolatile() {
		return isVolatile && bitmap == null; //Setting non-volatile pixels overrides volatile state
	}
	
	private static synchronized ByteBuffer getTempBuffer(int capacity) {
		ByteBuffer buf = (tempBuffer != null ? tempBuffer.get() : null);
		if (buf == null || buf.capacity() < capacity) {
			buf = ByteBuffer.allocate(capacity);
			buf.order(ByteOrder.nativeOrder());
			tempBuffer = new SoftReference<ByteBuffer>(buf);
		}
		buf.rewind();
		buf.limit(capacity);
		return buf;
	}
	
	//Setters
	public void setPixels(ESManager<?> glm, Rect glScreenRect, int rw, int rh) {
		setPixels(glm, glScreenRect.x, glScreenRect.y, glScreenRect.w, glScreenRect.h, rw, rh);
	}
	void setPixels(ESManager<?> glm, int dx, int dy, int w, int h, int rw, int rh) {
		boolean highQuality = false;

		int[] bits = glm.getRenderTargetBits();
		boolean isRGB565 = (bits[0] == 5 && bits[1] == 6 && bits[2] == 5);
		int add = (isRGB565 ? 0xFF070307 : 0xFF000000);
		if (!highQuality && isRGB565) {
			//Benchmark.tick();
			int scansize = w*2; //((w*2) + 3) & ~3; //Round up to nearest multiple of 4 (match pack alignment)
			ByteBuffer buf = getTempBuffer(scansize * h);
			glm.glReadPixels(dx, dy, w, h, GL_RGB, GL_UNSIGNED_SHORT_5_6_5, buf);
			vflip(buf.array(), scansize, h);
			
			bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.RGB_565);
			bitmap.copyPixelsFromBuffer(buf);
			//Benchmark.tock("RGB565=%s");
			
			/*
			//RGB565 loses brightness when mixing, must be converted to ARGB8888			
			int[] rgb = new int[w*h];
			for (int n = 0; n < rgb.length; n++) {
				int c = (buf.get()&0xFF)|((buf.get()&0xFF)<<8);
				int r = (c>>11) & 31;
				r = (r<<3)|(r>>2);
				int g = (c>>5 ) & 63;
				g = (g<<2)|(g>>4);
				int b = (c    ) & 31;
				b = (b<<3)|(b>>2);
				rgb[n] = 0xFF000000|(r<<16)|(g<<8)|b;
			}
			bitmap = Bitmap.createBitmap(rgb, w, h, Bitmap.Config.ARGB_8888);
			*/
		} else {
			//Benchmark.tick();
			int scansize = w * 4;
			ByteBuffer buf = getTempBuffer(scansize * h);
			glm.glReadPixels(dx, dy, w, h, GL_RGBA, GL_UNSIGNED_BYTE, buf);
						
			bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
			int[] line = new int[w];
			for (int y = 0; y < h; y++) {
				for (int x = 0; x < w; x++) {
					int c = buf.getInt();
					c = (c&0xFF00FF00) | ((c<<16)&0xFF0000) | ((c>>16)&0xFF);
					line[x] = add|c;
				}
				bitmap.setPixels(line, 0, w, 0, h-y-1, w, 1);
			}
			//Benchmark.tock("RGBA8888=%s");
		}		
		volatilePixels = null;
		screenWidth = rw;
		screenHeight = rh;
		isAvailable = true;
	}
	
	public void setVolatilePixels(ITexture tex, int rw, int rh) {
		bitmap = null;
		volatilePixels = tex;
		screenWidth = rw;
		screenHeight = rh;
		isAvailable = true;
	}

	
}

package nl.weeaboo.vn.android.impl;

import java.io.IOException;
import java.io.ObjectStreamException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import nl.weeaboo.android.AndroidFileSystem;
import nl.weeaboo.android.FileSegment;
import nl.weeaboo.android.vn.AndroidVN;
import nl.weeaboo.filesystem.FileSystemUtil;
import nl.weeaboo.io.EnvironmentSerializable;
import nl.weeaboo.lua2.io.LuaSerializable;
import nl.weeaboo.vn.INotifier;
import nl.weeaboo.vn.ISeenLog;
import nl.weeaboo.vn.IVideo;
import nl.weeaboo.vn.impl.base.BaseVideoFactory;
import android.os.Handler;

@LuaSerializable
public class VideoFactory extends BaseVideoFactory implements Serializable {
	
	private final AndroidVN context;
	private final AndroidFileSystem afs;
	private final String videoFolder;
	private String assetVideoFolder;
	private final Handler handler;
	
	private final EnvironmentSerializable es;
	
	public VideoFactory(AndroidVN c, AndroidFileSystem afs, String videoFolder,
			String assetVideoFolder, ISeenLog sl, INotifier ntf)
	{
		super(sl, ntf);
		
		this.context = c;
		this.afs = afs;
		this.videoFolder = videoFolder;
		this.assetVideoFolder = assetVideoFolder;
		this.handler = c.getHandler();
				
		this.es = new EnvironmentSerializable(this);

		setDefaultExts("ogv", "mp4");		
	}
	
	//Functions
	private Object writeReplace() throws ObjectStreamException {	
		return es.writeReplace();
	}
	
	@Override
	public IVideo movieNormalized(String filename) throws IOException {
		String folder = (afs.getFileExists(assetVideoFolder) ? assetVideoFolder : videoFolder);
		Movie movie = new Movie(this, folder);
		movie.setVideoPath(filename);
		movie.start();
		return movie;
	}
	
	@Override
	protected void preloadNormalized(String filename) {
		//Video is streamed directly from the disk, nothing to preload
	}
	
	//Getters
	@Override
	protected boolean isValidFilename(String filename) {
		return afs.getFileExists(videoFolder + filename)
			|| afs.getFileExists(assetVideoFolder + filename);
	}
	
	public INotifier getNotifier() {
		return notifier;
	}
	public FileSegment getFileSegment(String path) throws IOException {
		return afs.getFileSegment(path);
	}
	public AndroidVN getContext() {
		return context;
	}
	public Handler getVideoHandler() {
		return handler;
	}

	@Override
	protected List<String> getFiles(String folder) {
		List<String> all = new ArrayList<String>();
		getVideoFiles(all, folder, true);
		return all;
	}
	
	private void getVideoFiles(Collection<String> out, String folder, boolean recursive) {
		try {
			Collection<String> videoFiles = new ArrayList<String>();
			afs.getSubFolders(videoFiles, videoFolder + folder, true);
			videoFiles = FileSystemUtil.withoutPathPrefix(videoFiles, videoFolder);		
			out.addAll(videoFiles);
		} catch (IOException ioe) {
			//Ignore
		}
		
		if (!assetVideoFolder.equals(videoFolder)) {
			try {
				Collection<String> videoFiles = new ArrayList<String>();
				afs.getSubFolders(videoFiles, assetVideoFolder + folder, true);
				videoFiles = FileSystemUtil.withoutPathPrefix(videoFiles, assetVideoFolder);		
				out.addAll(videoFiles);
			} catch (IOException ioe) {
				//Ignore
			}
		}		
	}
	
	public String getVideoFolder() {
		return videoFolder;
	}
	
	//Setters
	public void setAssetVideoFolder(String folder) {
		assetVideoFolder = folder;
	}
	
}

package nl.weeaboo.vn.android.impl;

import java.io.IOException;
import java.io.ObjectStreamException;
import java.io.Serializable;
import java.util.Collection;
import java.util.Collections;

import nl.weeaboo.android.ResourceManager;
import nl.weeaboo.android.vn.AndroidVN;
import nl.weeaboo.io.EnvironmentSerializable;
import nl.weeaboo.lua2.io.LuaSerializable;
import nl.weeaboo.vn.INotifier;
import nl.weeaboo.vn.ISeenLog;
import nl.weeaboo.vn.IVideo;
import nl.weeaboo.vn.impl.base.BaseVideoFactory;
import android.os.Handler;

@LuaSerializable
public class VideoFactory extends BaseVideoFactory implements Serializable {
	
	private final AndroidVN context;
	private final ResourceManager rm;
	private final String videoFolder;
	private String assetVideoFolder;
	private final Handler handler;
	
	private final EnvironmentSerializable es;
	
	public VideoFactory(AndroidVN c, ResourceManager rm, String videoFolder,
			String assetVideoFolder, ISeenLog sl, INotifier ntf)
	{
		super(sl, ntf);
		
		this.context = c;
		this.rm = rm;
		this.videoFolder = videoFolder;
		this.assetVideoFolder = assetVideoFolder;
		this.handler = c.getHandler();
				
		this.es = new EnvironmentSerializable(this);

		setDefaultExts("ogv", "mp4");		
	}
	
	//Functions
	private Object writeReplace() throws ObjectStreamException {	
		return es.writeReplace();
	}
	
	@Override
	public IVideo movieNormalized(String filename) throws IOException {
		String folder = (rm.getFileExists(assetVideoFolder) ? assetVideoFolder : videoFolder);
		Movie movie = new Movie(this, folder);
		movie.setVideoPath(filename);
		movie.start();
		return movie;
	}
	
	@Override
	protected void preloadNormalized(String filename) {
		//Video is streamed directly from the disk, nothing to preload
	}
	
	//Getters
	@Override
	protected boolean isValidFilename(String filename) {
		return rm.getFileExists(videoFolder + filename)
			|| rm.getFileExists(assetVideoFolder + filename);
	}
	
	public INotifier getNotifier() {
		return notifier;
	}
	public ResourceManager getResourceManager() {
		return rm;
	}
	public AndroidVN getContext() {
		return context;
	}
	public Handler getVideoHandler() {
		return handler;
	}

	@Override
	protected Collection<String> getFiles(String folder) {
		try {
			return rm.getFolderContents(folder, true);
		} catch (IOException e) {
			notifier.d("Folder doesn't exist or can't be read: " + folder, e);
		}
		return Collections.emptyList();
	}
	
	//Setters
	public void setAssetVideoFolder(String folder) {
		assetVideoFolder = folder;
	}
	
}

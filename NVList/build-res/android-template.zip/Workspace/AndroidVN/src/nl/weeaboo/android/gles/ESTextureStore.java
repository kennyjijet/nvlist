package nl.weeaboo.android.gles;

import static nl.weeaboo.gl.GLConstants.GL_RGBA;
import static nl.weeaboo.gl.GLConstants.GL_UNSIGNED_BYTE;

import java.io.BufferedInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectStreamException;
import java.io.Serializable;
import java.nio.IntBuffer;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import nl.weeaboo.android.AndroidFileSystem;
import nl.weeaboo.common.Dim;
import nl.weeaboo.filesystem.FileSystemUtil;
import nl.weeaboo.filesystem.IFileSystem;
import nl.weeaboo.gl.GLInfo;
import nl.weeaboo.gl.GLLog;
import nl.weeaboo.gl.GLManager;
import nl.weeaboo.gl.GLResCache;
import nl.weeaboo.gl.tex.AbstractTextureStore;
import nl.weeaboo.gl.tex.PackedTexture;
import nl.weeaboo.gl.tex.TextureId;
import nl.weeaboo.image.ImageDesc;
import nl.weeaboo.image.ImageDescUtil;
import nl.weeaboo.io.BufferUtil;
import nl.weeaboo.io.EnvironmentSerializable;
import nl.weeaboo.lua2.io.LuaSerializable;

import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;

import android.graphics.Bitmap;

@LuaSerializable
public class ESTextureStore extends AbstractTextureStore implements Serializable {
	
	private final AndroidFileSystem afs;
	
	private Set<String> assetImages;
	private String assetImagePrefix;
	private double assetImageScale;
	private transient boolean assetsInitialized;
	
	private final EnvironmentSerializable es;
		
	public ESTextureStore(AndroidFileSystem afs, String imagePrefix, String assetImagePrefix,
			GLResCache rc, ESTextureDataLoader loader, boolean isLowEnd)
	{
		super(afs, imagePrefix, rc, loader);
		
		this.afs = afs;
		this.assetImages = new HashSet<String>();
		this.assetImagePrefix = assetImagePrefix;
		this.assetImageScale = 1;
		
		loader.setAssetPrefix(assetImagePrefix);
		
		long maxMemory = Runtime.getRuntime().maxMemory();
		setMemoryLimits(maxMemory/2, maxMemory);
		
		es = new EnvironmentSerializable(this);
	}

	//Functions
	private Object writeReplace() throws ObjectStreamException {	
		return es.writeReplace();
	}
	
	@Override
	public void initGL(GLManager glm) {
		super.initGL(glm);
		
		if (!assetsInitialized) {
			onImageFolderChanged();
		}
	}
	
	@Override
	protected void onImageFolderChanged() {
		if (!assetsInitialized) {
			assetsInitialized = true;
			assetImages.clear();
			getLoader().setAssetPrefix(assetImagePrefix);
		}
		
		super.onImageFolderChanged();
	}
	
	@Override
	public ESTextureData newARGB8TextureData(IntBuffer argb, boolean isARGBReadOnly, int tw, int th) {
		GLInfo glInfo = getGLInfo();
		int glFormat = glInfo.getDefaultPixelFormatARGB();
		int glType = glInfo.getDefaultPixelTypeARGB();
		return newARGB8TextureData(argb, isARGBReadOnly, tw, th, glFormat, glType);
	}
	
	@Override
	public ESTextureData newARGB8TextureData(IntBuffer argb, boolean isARGBReadOnly, int tw, int th, int glFormat, int glType) {
		reserveTextureMemory(tw * th * 4);		
		Bitmap bitmap = Bitmap.createBitmap(BufferUtil.toArray(argb), tw, th, Bitmap.Config.ARGB_8888);
		
		BitmapRef bitmapRef = BitmapRef.fromBitmap(bitmap, false);
		return new ESTextureData(tw, th, GL_RGBA, GL_RGBA, GL_UNSIGNED_BYTE, bitmapRef);		
	}
	
	@Override
	protected PackedTexture newPackedTexture(int w, int h) {
		Dim texSize = toTexSize(w, h);
		
		TextureId texId = new TextureId();
		PackedTexture tex = new ESPackedTexture(texId, this, texSize);
		register(tex, true);
		return tex;
	}
	
	@Override
	protected void initImageDescs(Map<String, ImageDesc> out, IFileSystem fs) {
		super.initImageDescs(out, fs);
		
		try {
			Map<String, ImageDesc> temp = new HashMap<String, ImageDesc>();
			ImageDescUtil.fromFileManager(temp, afs, assetImagePrefix);			
			for (Entry<String, ImageDesc> entry : temp.entrySet()) {
				String key = entry.getKey();
				assetImages.add(key);
				out.put(key, entry.getValue());
			}			
		} catch (IOException ioe) {
			Throwable t = ioe.getCause();
			if (t instanceof SAXParseException) {
				SAXParseException spe = (SAXParseException)t;
				String extra = spe.getLineNumber() + ":" + spe.getColumnNumber() + " :: " + spe.getMessage();
				GLLog.w("Parse error reading image descs (" + ioe.getMessage() + ") " + extra, spe);				
			} else if (t instanceof SAXException) {
				SAXException se = (SAXException)t;
				String extra = (se != null ? " :: " + se.getMessage() : "");
				GLLog.w("Parse error reading image descs (" + ioe.getMessage() + ") " + extra, se);				
			} else {
				String extra = (ioe.getCause() != null ? " :: " + ioe.getCause() : "");
				GLLog.w("IO error reading image descs (" + ioe.getMessage() + ") " + extra, ioe);
			}
		}		
	}
	
	protected ImageDesc loadImageDesc(String filename) throws IOException {
		try {
			ImageDesc desc;
			InputStream in = new BufferedInputStream(afs.newInputStream(assetImagePrefix + filename), 4096);
			try {
				desc = ImageDescUtil.fromImageFile(filename, in);
				assetImages.add(filename);
			} finally {
				in.close();
			}
			return desc;
		} catch (FileNotFoundException fnfe) {
			return super.loadImageDesc(filename);
		}
	}
	
	//Getters
	@Override
	protected ESTextureDataLoader getLoader() {
		return (ESTextureDataLoader)super.getLoader();
	}
	
	public boolean isAssetImage(String filename) {
		return assetImages.contains(filename);
	}
	
	@Override
	public void getFiles(Collection<String> out, String folder, boolean recursive) throws IOException {
		super.getFiles(out, folder, recursive);
		
		if (!assetImagePrefix.equals(getImagePrefix())) {
			Collection<String> assetFiles = new ArrayList<String>();
			afs.getSubFolders(assetFiles, assetImagePrefix + folder, true);
			assetFiles = FileSystemUtil.withoutPathPrefix(assetFiles, assetImagePrefix);		
			out.addAll(assetFiles);
		}		
	}
	
	public double getAssetImageScale() {
		return assetImageScale;
	}

	//Setters
	public void setAssetImageFolder(String folder, double scale) {
		if (folder.length() > 0 && !folder.endsWith("/")) {
			folder += "/";
		}
		
		if (!folder.equals(assetImagePrefix) || assetImageScale != scale) {
			assetsInitialized = false;
			assetImagePrefix = folder;
			assetImageScale = scale;
			
			onImageFolderChanged();			
		}
	}

}

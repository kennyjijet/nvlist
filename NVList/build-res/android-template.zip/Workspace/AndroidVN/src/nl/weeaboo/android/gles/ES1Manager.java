package nl.weeaboo.android.gles;

import static javax.microedition.khronos.opengles.GL10.GL_BLUE_BITS;
import static javax.microedition.khronos.opengles.GL10.GL_CLAMP_TO_EDGE;
import static javax.microedition.khronos.opengles.GL10.GL_GREEN_BITS;
import static javax.microedition.khronos.opengles.GL10.GL_LINEAR;
import static javax.microedition.khronos.opengles.GL10.GL_NEAREST;
import static javax.microedition.khronos.opengles.GL10.GL_NEAREST_MIPMAP_LINEAR;
import static javax.microedition.khronos.opengles.GL10.GL_RED_BITS;
import static javax.microedition.khronos.opengles.GL10.GL_TEXTURE_2D;
import static javax.microedition.khronos.opengles.GL10.GL_TEXTURE_MAG_FILTER;
import static javax.microedition.khronos.opengles.GL10.GL_TEXTURE_MIN_FILTER;
import static javax.microedition.khronos.opengles.GL10.GL_TEXTURE_WRAP_S;
import static javax.microedition.khronos.opengles.GL10.GL_TEXTURE_WRAP_T;

import java.nio.Buffer;

import javax.microedition.khronos.opengles.GL10;

import nl.weeaboo.gl.GLDraw;
import nl.weeaboo.gl.GLManager;
import nl.weeaboo.gl.GLResCache;
import nl.weeaboo.gl.GLResId;
import nl.weeaboo.gl.GLUtil;
import nl.weeaboo.gl.tex.GLTexture;

public class ES1Manager extends ESManager<GL10> {

	private final boolean isLowEnd;
	
	public ES1Manager(ES1Draw draw, GLResCache resCache, boolean isLowEnd) {
		super(GL10.class, draw, resCache);
		
		this.isLowEnd = isLowEnd;
	}
	
	//Functions
	@Override
	protected String glOptString(GL10 gl, int glIdentifier, String defaultVal) {
		String s = gl.glGetString(glIdentifier);
		return (s != null ? s : defaultVal);
	}
	
	@Override
	protected int glGetInteger(GL10 gl, int glIdentifier) {
		int temp[] = new int[1];
		gl.glGetIntegerv(glIdentifier, temp, 0);
		return temp[0];
	}	
	
	@Override
	public GLResId newTextureId(int minF, int magF, int wrapS, int wrapT) {
		GLDraw draw = getGLDraw();
		GLTexture oldtex = draw.getTexture();		

		if (isLowEnd) {
			if (GLUtil.isMipmapScaleFilter(minF)) {
				minF = GL_NEAREST_MIPMAP_LINEAR;
			} else {
				minF = GL_NEAREST;
			}
		}
		
		if (minF == 0) minF = GL_LINEAR;
		if (magF == 0) magF = GL_LINEAR;
		if (wrapS == 0) wrapS = GL_CLAMP_TO_EDGE;
		if (wrapT == 0) wrapT = GL_CLAMP_TO_EDGE;
		
		GLResId texId = ES1ResId.newTextureInstance(gl, getGLResCache());
		//System.out.println("CREATE: " + texId);
		
		gl.glEnable(GL_TEXTURE_2D);
		gl.glBindTexture(GL_TEXTURE_2D, texId.getId());
        gl.glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, minF);
        gl.glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, magF);
        gl.glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, wrapS);
        gl.glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, wrapT);
		draw.setTexture(oldtex, true);
        
		return texId;
	}

	@Override
	public GLResId newBufferId() {		
		throw new RuntimeException("Not implemented for GLES 1.x");
	}

	@Override
	public GLResId newProgramId() {
		throw new RuntimeException("Not implemented for GLES 1.x");
	}
	
	//Getters
	public static GL10 getGL(GLManager glm) {
		return ((ES1Manager)glm).getGL();
	}
	
	public ES1Draw getGLDraw() {
		return (ES1Draw)super.getGLDraw();
	}

	@Override
	public int[] getRenderTargetBits() {
		int bits[] = new int[3];
		gl.glGetIntegerv(GL_RED_BITS, bits, 0);
		gl.glGetIntegerv(GL_GREEN_BITS, bits, 1);
		gl.glGetIntegerv(GL_BLUE_BITS, bits, 2);
		return bits;
	}
	
	@Override
	public void glReadPixels(int x, int y, int w, int h, int fmt, int type, Buffer buf) {
		gl.glReadPixels(x, y, w, h, fmt, type, buf);
	}
	
	//Setters
	
}

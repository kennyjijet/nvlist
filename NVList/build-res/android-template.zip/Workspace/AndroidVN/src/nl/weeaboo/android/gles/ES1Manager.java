package nl.weeaboo.android.gles;

import static javax.microedition.khronos.opengles.GL10.GL_BLEND;
import static javax.microedition.khronos.opengles.GL10.GL_BLUE_BITS;
import static javax.microedition.khronos.opengles.GL10.GL_CCW;
import static javax.microedition.khronos.opengles.GL10.GL_CLAMP_TO_EDGE;
import static javax.microedition.khronos.opengles.GL10.GL_COLOR_BUFFER_BIT;
import static javax.microedition.khronos.opengles.GL10.GL_CULL_FACE;
import static javax.microedition.khronos.opengles.GL10.GL_DEPTH_TEST;
import static javax.microedition.khronos.opengles.GL10.GL_DITHER;
import static javax.microedition.khronos.opengles.GL10.GL_GREEN_BITS;
import static javax.microedition.khronos.opengles.GL10.GL_LINEAR;
import static javax.microedition.khronos.opengles.GL10.GL_MODELVIEW;
import static javax.microedition.khronos.opengles.GL10.GL_NEAREST;
import static javax.microedition.khronos.opengles.GL10.GL_NEAREST_MIPMAP_LINEAR;
import static javax.microedition.khronos.opengles.GL10.GL_ONE;
import static javax.microedition.khronos.opengles.GL10.GL_ONE_MINUS_SRC_ALPHA;
import static javax.microedition.khronos.opengles.GL10.GL_PACK_ALIGNMENT;
import static javax.microedition.khronos.opengles.GL10.GL_PROJECTION;
import static javax.microedition.khronos.opengles.GL10.GL_RED_BITS;
import static javax.microedition.khronos.opengles.GL10.GL_SMOOTH;
import static javax.microedition.khronos.opengles.GL10.GL_TEXTURE_2D;
import static javax.microedition.khronos.opengles.GL10.GL_TEXTURE_MAG_FILTER;
import static javax.microedition.khronos.opengles.GL10.GL_TEXTURE_MIN_FILTER;
import static javax.microedition.khronos.opengles.GL10.GL_TEXTURE_WRAP_S;
import static javax.microedition.khronos.opengles.GL10.GL_TEXTURE_WRAP_T;
import static javax.microedition.khronos.opengles.GL10.GL_UNPACK_ALIGNMENT;

import java.nio.Buffer;

import javax.microedition.khronos.opengles.GL10;

import nl.weeaboo.gl.GLDraw;
import nl.weeaboo.gl.GLManager;
import nl.weeaboo.gl.GLResCache;
import nl.weeaboo.gl.GLResId;
import nl.weeaboo.gl.GLUtil;
import nl.weeaboo.gl.tex.GLTexture;

public class ES1Manager extends ESManager<GL10> {

	private final boolean isLowEnd;
	
	public ES1Manager(ES1Draw draw, GLResCache resCache, boolean isLowEnd) {
		super(GL10.class, draw, resCache);
		
		this.isLowEnd = isLowEnd;
	}
	
	//Functions
	@Override
	public void init(Object glRaw, boolean contextChanged) {		
		super.init(glRaw, contextChanged);				
		
		gl.glClearColor(0f, 0f, 0f, 1f);
		
		//Clearing the depth buffer can cause a segfault when rapidly changing orientation on real hardware		
		//gl.glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
		gl.glClear(GL_COLOR_BUFFER_BIT);
		
		gl.glDisable(GL_DITHER);
        gl.glShadeModel(GL_SMOOTH);
        gl.glEnable(GL_BLEND);
        gl.glEnable(GL_TEXTURE_2D);
        gl.glDisable(GL_DEPTH_TEST);
        gl.glBlendFunc(GL_ONE, GL_ONE_MINUS_SRC_ALPHA);
        gl.glFrontFace(GL_CCW);
        gl.glDisable(GL_CULL_FACE);
    	gl.glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
    	gl.glPixelStorei(GL_PACK_ALIGNMENT, 1);
        gl.glColor4x(0x10000, 0x10000, 0x10000, 0x10000);        		
	}
	
	@Override
	protected String glOptString(int glIdentifier, String defaultVal) {
		String s = gl.glGetString(glIdentifier);
		return (s != null ? s : defaultVal);
	}
	
	@Override
	protected int glGetInteger(int glIdentifier) {
		int temp[] = new int[1];
		gl.glGetIntegerv(glIdentifier, temp, 0);
		return temp[0];
	}	
	
	@Override
	protected void glTexParameterf(int target, int pname, float value) {
		gl.glTexParameterf(target, pname, value);
	}
	
	@Override
	public GLResId newTextureId(int minF, int magF, int wrapS, int wrapT) {
		GLDraw draw = getGLDraw();
		GLTexture oldtex = draw.getTexture();		

		if (isLowEnd) {
			if (GLUtil.isMipmapScaleFilter(minF)) {
				minF = GL_NEAREST_MIPMAP_LINEAR;
			} else {
				minF = GL_NEAREST;
			}
		}
		
		if (minF == 0) minF = GL_LINEAR;
		if (magF == 0) magF = GL_LINEAR;
		if (wrapS == 0) wrapS = GL_CLAMP_TO_EDGE;
		if (wrapT == 0) wrapT = GL_CLAMP_TO_EDGE;
		
		GLResId texId = ES1ResId.newTextureInstance(gl, getGLResCache());
		
		//Log.d("GLManager", "newTextureId: " + texId);
		
		gl.glEnable(GL_TEXTURE_2D);
		gl.glBindTexture(GL_TEXTURE_2D, texId.getId());
        gl.glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, minF);
        gl.glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, magF);
        gl.glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, wrapS);
        gl.glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, wrapT);
		draw.setTexture(oldtex, true);
        
		return texId;
	}

	@Override
	public GLResId newBufferId() {		
		throw new RuntimeException("Not implemented for GLES 1.x");
	}

	@Override
	public GLResId newProgramId() {
		throw new RuntimeException("Not implemented for GLES 1.x");
	}
	
	//Getters
	public static GL10 getGL(GLManager glm) {
		return ((ES1Manager)glm).getGL();
	}
	
	public ES1Draw getGLDraw() {
		return (ES1Draw)super.getGLDraw();
	}

	@Override
	public int[] getRenderTargetBits() {
		int bits[] = new int[3];
		gl.glGetIntegerv(GL_RED_BITS, bits, 0);
		gl.glGetIntegerv(GL_GREEN_BITS, bits, 1);
		gl.glGetIntegerv(GL_BLUE_BITS, bits, 2);
		return bits;
	}
	
	@Override
	public void glReadPixels(int x, int y, int w, int h, int fmt, int type, Buffer buf) {
		gl.glReadPixels(x, y, w, h, fmt, type, buf);
	}
	
	//Setters
	@Override
	public void initProjection(int w, int h) {
		super.initProjection(w, h);

		gl.glViewport(0, 0, w, h);
		
        gl.glMatrixMode(GL_PROJECTION);
        gl.glLoadIdentity();
        gl.glOrthof(0f, w, 0f, h, 0f, 1f);
        
        gl.glMatrixMode(GL_MODELVIEW);
        gl.glLoadIdentity();		
	}
	
}

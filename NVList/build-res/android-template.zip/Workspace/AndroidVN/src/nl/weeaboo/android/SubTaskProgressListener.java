package nl.weeaboo.android;


public abstract class SubTaskProgressListener implements ProgressListener {

	private final float min, max;
	
	public SubTaskProgressListener(float min, float max) {
		this.min = min;
		this.max = max;
	}
	
	//Functions
	@Override
	public void onProgress(float frac) {
		onMainProgress(min + (max-min) * frac);
	}
	
	protected abstract void onMainProgress(float val);
	
	//Getters
	
	//Setters
	
}

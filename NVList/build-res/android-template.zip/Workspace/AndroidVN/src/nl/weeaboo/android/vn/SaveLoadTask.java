package nl.weeaboo.android.vn;

import nl.weeaboo.android.gui.ProgressAsyncTask;
import nl.weeaboo.common.StringUtil;
import nl.weeaboo.vn.IProgressListener;
import nl.weeaboo.vn.IScreenshot;
import nl.weeaboo.vn.IStorage;
import nl.weeaboo.vn.android.impl.Novel;
import nl.weeaboo.vn.android.impl.SaveHandler;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.res.Resources;
import android.os.Handler;
import android.util.Log;
import android.widget.Toast;

public class SaveLoadTask extends ProgressAsyncTask<Integer, Boolean>
	implements IProgressListener
{

	private String baseMessage;
	private Game game;
	private boolean isSave;
	private IStorage metaData;
	private IScreenshot screenshot;
	private Runnable onPostExecuteListener;
	
	private transient Throwable err;
	
	protected SaveLoadTask(Context c, Game g, Handler h, String msg, boolean save, IStorage meta, IScreenshot ss) {
		super(c, h, msg);
		
		game = g;
		baseMessage = msg;
		isSave = save;
		metaData = meta;
		screenshot = ss;
	}

	//Functions
	public static SaveLoadTask createSaveTask(Context context, Game game, Handler h, IStorage meta, IScreenshot ss) {
		Resources res = context.getResources();
		String msg = res.getString(R.string.dialog_save_message);
		return new SaveLoadTask(context, game, h, msg, true, meta, ss);
	}
	public static SaveLoadTask createLoadTask(Context context, Game game, Handler h) {
		Resources res = context.getResources();
		String msg = res.getString(R.string.dialog_load_message);
		return new SaveLoadTask(context, game, h, msg, false, null, null);
	}

	@Override
	protected void setProgressProperties(ProgressDialog progress) {
		super.setProgressProperties(progress);
		
		if (!isSave) {
			progress.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
		}		
	}
	
	@Override
	public void onProgressUpdate(Float... values) {
		if (progress != null && isSave) {
			long bytes = values[0].longValue();
			progress.setMessage(baseMessage + "\n" + StringUtil.formatMemoryAmount(bytes));
		} else {
			super.onProgressUpdate(values);			
		}
	}
		
	@Override
	protected Boolean doInBackground(Integer... params) {		
		if (!isSave) {
			synchronized (game) {
				try {
					Novel nvl = game.getNovel();
					SaveHandler sh = (SaveHandler)nvl.getSaveHandler();
					sh.load(params[0], this);
				} catch (Throwable t) {
					err = t;
					return false;
				}				
			}			
			return true;
		} else {				
			synchronized (game) {
				if (isSave) {
					try {
						Novel nvl = game.getNovel();
						SaveHandler sh = (SaveHandler)nvl.getSaveHandler();
						sh.save(params[0], screenshot, metaData, this);
						//sh.save(params[0], screenshot, null);
					} catch (Exception e) {
						err = e;
						return false;
					}
				}
			}
			return true;
		}
	}
	
	@Override
	protected void onPostExecute(Boolean result) {
		super.onPostExecute(result);
		
		if (err != null) {
			Log.e("SaveLoad", "Error, isSave="+isSave+" screenshot="+screenshot, err);
			Toast toast = Toast.makeText(context, err.toString(), Toast.LENGTH_SHORT);
			toast.show();
		} else {
			if (onPostExecuteListener != null) onPostExecuteListener.run();
		}
	}
	
	//Getters
	
	//Setters
	public void setOnPostExecuteListener(Runnable r) {
		onPostExecuteListener = r;
	}

	@Override
	public void onProgressChanged(float frac) {
		publishProgress(frac);
	}
	
}

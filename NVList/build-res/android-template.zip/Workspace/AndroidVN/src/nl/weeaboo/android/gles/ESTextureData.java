package nl.weeaboo.android.gles;

import static nl.weeaboo.android.gles.ESUtil.createCompatibleBitmap;
import static nl.weeaboo.gl.GLConstants.GL_LINEAR;
import static nl.weeaboo.gl.GLConstants.GL_RGB;
import static nl.weeaboo.gl.GLConstants.GL_RGBA;
import static nl.weeaboo.gl.GLConstants.GL_TEXTURE_2D;
import static nl.weeaboo.gl.GLConstants.GL_TEXTURE_MIN_FILTER;
import static nl.weeaboo.gl.GLConstants.GL_UNSIGNED_SHORT_5_6_5;
import static nl.weeaboo.gl.GLUtil.isPowerOfTwo;

import java.nio.IntBuffer;

import nl.weeaboo.common.Dim;
import nl.weeaboo.gl.GLDraw;
import nl.weeaboo.gl.GLException;
import nl.weeaboo.gl.GLInfo;
import nl.weeaboo.gl.GLManager;
import nl.weeaboo.gl.GLUtil;
import nl.weeaboo.gl.tex.AbstractTextureData;
import nl.weeaboo.gl.tex.GLTexture;
import nl.weeaboo.gl.tex.TextureUploadInfo;
import nl.weeaboo.lua2.io.LuaSerializable;
import android.graphics.Bitmap;
import android.opengl.GLUtils;

@LuaSerializable
public class ESTextureData extends AbstractTextureData {
		
	private static final long serialVersionUID = 1L;

	private BitmapRef bitmapRef;
	
	public ESTextureData(int w, int h, int ifmt, int fmt, int type, BitmapRef bitmap) {
		super(w, h, ifmt, fmt, type);
		
		this.bitmapRef = bitmap;
	}

	//Functions
	public static ESTextureData fromBitmap(GLInfo glInfo, Dim texSize, Bitmap bitmap, boolean shared) {
		int ifmt, fmt, type;
		if (bitmap.getConfig() == Bitmap.Config.RGB_565) {
			ifmt = GL_RGB;
			fmt = GL_RGB;
			type = GL_UNSIGNED_SHORT_5_6_5;
		} else {
			ifmt = GL_RGBA;
			fmt = glInfo.getDefaultPixelFormatARGB();
			type = glInfo.getDefaultPixelTypeARGB();
		}
		
		BitmapRef bitmapRef = BitmapRef.fromBitmap(bitmap, shared);					
        return new ESTextureData(texSize.w, texSize.h, ifmt, fmt, type, bitmapRef);		
	}
	
	public BitmapRef takeBitmap() {
		BitmapRef oldref = bitmapRef;
		bitmapRef = null;
		return oldref;
	}
	
	public void disposeBitmap() {
		if (bitmapRef != null) {
			bitmapRef.dispose();
			bitmapRef = null;
		}
	}

	@Override
	public int getMipmapLevels() {
		return 1;
	}

	@Override
	public void getPixelsARGB8(IntBuffer out, int x, int y, int w, int h) {
		Bitmap bm = BitmapRef.tryGetBitmap(bitmapRef);
		if (bm != null) {
			int pixels = w * h;
			if (out.hasArray()) {
				int off = out.arrayOffset() + out.position();
				int[] arr = out.array();
				bm.getPixels(arr, off, w, x, y, w, h);
				for (int n = 0; n < pixels; n++) {
					arr[off+n] = GLUtil.premultiplyAlpha(arr[off+n]);
				}
			} else {
				int[] temp = new int[pixels];
				bm.getPixels(temp, 0, w, x, y, w, h);
				for (int n = 0; n < pixels; n++) {
					temp[n] = GLUtil.premultiplyAlpha(temp[n]);
				}
				out.put(temp);
				out.rewind();
			}
		}
	}

	@Override
	public void texImage2D(GLManager glm, GLTexture tex, TextureUploadInfo outInfo, boolean mipmap)
			throws GLException
	{
        Bitmap bm = BitmapRef.tryGetBitmap(bitmapRef);
        if (bm == null) {
        	tex.glUnload();
        	return;
        }

        ESManager<?> esm = (ESManager<?>)glm;
        GLInfo glInfo = glm.getGLInfo();
        GLDraw glDraw = glm.getGLDraw();
        glDraw.setTexture(tex, true);
        
        int tw = tex.getTexWidth();
        int th = tex.getTexHeight();

    	int bw = bm.getWidth();
    	int bh = bm.getHeight();
        
        boolean needsPadding = (bw != tw || bh != th);
        
        if (mipmap && !isPowerOfTwo(tw, th)) {
        	//Panic: disable mipmap (NPOT mipmapped textures not supported on GLES)
        	esm.glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        }
        
        if (!needsPadding) {
        	GLUtils.texImage2D(GL_TEXTURE_2D, 0, bm, 0);

        	//texWidth = bm.getWidth();
            //texHeight = bm.getHeight();
        	outInfo.texImage2D(1, internalFormat, format, type, bm.getWidth(), bm.getHeight());
        } else {
    		//Pad the bitmap up to an allowable size        	
			Bitmap padded;
			if (tw >= bw && th >= bh) {
				padded = createCompatibleBitmap(glInfo, tw, th, bm);	        	        	
				//Copy pixels to padded one row at a time
				int[] rowPixels = new int[bw];
				for (int y = 0; y < bh; y++) {
					bm.getPixels(rowPixels, 0, bw, 0, y, bw, 1);
					padded.setPixels(rowPixels, 0, bw, 0, y, bw, 1);
				}
			} else {
				padded = Bitmap.createScaledBitmap(bm, tw, th, true);
			}
			            
        	GLUtils.texImage2D(GL_TEXTURE_2D, 0, padded, 0);
        	int levels = 1;
        	if (mipmap) {
	            while (padded.getWidth() > 1 || padded.getHeight() > 1) {
	            	//Bitmap scaled = scaleHalf(padded);
	            	Bitmap scaled = Bitmap.createScaledBitmap(padded,
	            			Math.max(1, padded.getWidth()/2),
	            			Math.max(1, padded.getHeight()/2), true);
			        padded.recycle();
			        padded = scaled;
			        
		        	GLUtils.texImage2D(GL_TEXTURE_2D, levels, padded, 0);
			        levels++;
	            }
        	}
        	padded.recycle();
        	
            //texWidth = padded.getWidth();
            //texHeight = padded.getHeight();
			outInfo.texImage2D(1, internalFormat, format, type, tw, th);        	
        }
	}

	@Override
	public void texSubImage2D(GLManager glm, GLTexture tex, TextureUploadInfo outInfo, boolean mipmap,
			int x, int y, int w, int h) throws GLException
	{
		//Just do a full update for now
		texImage2D(glm, tex, outInfo, mipmap);
	}
	
	//Getters
	public Bitmap getBitmap() {
		return BitmapRef.tryGetBitmap(bitmapRef);
	}

	@Override
	public int getMemoryUsage() {
		Bitmap bitmap = getBitmap();
		if (bitmap == null) {
			return 0;
		}
		return bitmap.getRowBytes() * bitmap.getHeight();
	}

	//Setters
	
}

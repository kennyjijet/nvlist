package nl.weeaboo.vn.android.impl;

import java.io.ObjectStreamException;
import java.io.Serializable;

import nl.weeaboo.io.EnvironmentSerializable;
import nl.weeaboo.lua2.io.LuaSerializable;
import nl.weeaboo.vn.IPixelShader;
import nl.weeaboo.vn.impl.base.BaseNotifier;
import nl.weeaboo.vn.impl.base.BaseShaderFactory;

@LuaSerializable
public class ES1ShaderFactory extends BaseShaderFactory implements Serializable {
	
	private final EnvironmentSerializable es;
	
	public ES1ShaderFactory(BaseNotifier ntf) {
		super(ntf);
		
		es = new EnvironmentSerializable(this);
	}
	
	//Functions
	private Object writeReplace() throws ObjectStreamException {	
		return es.writeReplace();
	}
	
	@Override
	public IPixelShader createGLSLShader(String filename) {
		notifier.d("Shaders not supported under OpenGL ES 1.x");
		return null;
	}
	
	//Getters
	@Override
	public String getGLSLVersion() {
		return "0";
	}
	
	//Setters
	
}

package nl.weeaboo.vn.android.impl;

import java.io.Serializable;

import nl.weeaboo.lua2.io.LuaSerializable;
import nl.weeaboo.vn.ErrorLevel;
import nl.weeaboo.vn.ITextState;
import nl.weeaboo.vn.impl.base.BaseNotifier;
import android.util.Log;

@LuaSerializable
public class Notifier extends BaseNotifier implements Serializable {

	private static final long serialVersionUID = AndroidImpl.serialVersionUID;

	private static final String TAG = "AndroidVN";
	
	private ITextState textState;
	
	public Notifier() {
	}
	
	//Functions
	@Override
	public void log(ErrorLevel level, String message, Throwable t) {
		if (t != null) {
			switch (level) {
			case VERBOSE: Log.v(TAG, message, t); break;
			case DEBUG:   Log.d(TAG, message, t); break;
			case WARNING: Log.w(TAG, message, t); break;
			case ERROR:   Log.e(TAG, message, t); break;
			case MESSAGE: break;
			}
		} else {
			switch (level) {
			case VERBOSE: Log.v(TAG, message); break;
			case DEBUG:   Log.d(TAG, message); break;
			case WARNING: Log.w(TAG, message); break;
			case ERROR:   Log.e(TAG, message); break;
			case MESSAGE: break;
			}
		}
		
		if (textState == null || level.compareTo(minimumLevel) < 0) {
			return;
		}
		
		switch (level) {
		case VERBOSE: textState.setText(String.format("\\x1b[36;0m%s\\x1b[0m", message)); break;
		case DEBUG:   textState.setText(String.format("\\x1b[33;1m%s\\x1b[0m", message)); break;
		case WARNING: textState.setText(String.format("\\x1b[33;1m%s\\x1b[0m", message)); break;
		case ERROR:   textState.setText(String.format("\\x1b[31;1m%s\\x1b[0m", message)); break;
		case MESSAGE: break;
		}
	}

	public void setTextState(ITextState ts) {
		this.textState = ts;
	}
	
}

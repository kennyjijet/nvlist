package nl.weeaboo.vn.android.impl;

import static javax.microedition.khronos.opengles.GL10.GL_BLEND;
import static javax.microedition.khronos.opengles.GL10.GL_FLOAT;
import static javax.microedition.khronos.opengles.GL10.GL_ONE;
import static javax.microedition.khronos.opengles.GL10.GL_ONE_MINUS_SRC_ALPHA;
import static javax.microedition.khronos.opengles.GL10.GL_RGB;
import static javax.microedition.khronos.opengles.GL10.GL_SCISSOR_TEST;
import static javax.microedition.khronos.opengles.GL10.GL_TEXTURE0;
import static javax.microedition.khronos.opengles.GL10.GL_TEXTURE_2D;
import static javax.microedition.khronos.opengles.GL10.GL_TEXTURE_COORD_ARRAY;
import static javax.microedition.khronos.opengles.GL10.GL_TRIANGLE_STRIP;
import static javax.microedition.khronos.opengles.GL10.GL_UNSIGNED_BYTE;
import static javax.microedition.khronos.opengles.GL10.GL_VERTEX_ARRAY;
import static nl.weeaboo.android.gles.ESUtil.round;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;

import javax.microedition.khronos.opengles.GL10;

import nl.weeaboo.android.gles.ES1Draw;
import nl.weeaboo.android.gles.ES1Manager;
import nl.weeaboo.android.gles.ESTextureStore;
import nl.weeaboo.android.vn.AndroidRenderEnv;
import nl.weeaboo.common.Area2D;
import nl.weeaboo.common.Rect;
import nl.weeaboo.common.Rect2D;
import nl.weeaboo.gl.GLInfo;
import nl.weeaboo.gl.GLUtil;
import nl.weeaboo.gl.tex.GLTexRect;
import nl.weeaboo.gl.tex.GLTexture;
import nl.weeaboo.gl.tex.GLWritableTexture;
import nl.weeaboo.vn.BlendMode;
import nl.weeaboo.vn.IDistortGrid;
import nl.weeaboo.vn.IPixelShader;
import nl.weeaboo.vn.IScreenshot;
import nl.weeaboo.vn.ITexture;
import nl.weeaboo.vn.RenderCommand;
import nl.weeaboo.vn.impl.base.TriangleGrid;
import nl.weeaboo.vn.math.Matrix;

class ES1Renderer extends Renderer {

	private final ES1Manager glm;
	private final boolean allowCoordinateRounding;
	private final boolean enableCopyTexSubImage;
	
	protected final ES1FadeQuadRenderer fadeQuadRenderer;	
	protected final ES1BlendQuadRenderer blendQuadRenderer;	
	protected final ES1DistortQuadRenderer distortQuadRenderer;
	
	//--- Properties only valid between renderBegin() and renderEnd() beneath this line ---
	private ES1Draw glDraw;
	private GLInfo glInfo;
	private GL10 gl;
	private float dx, dy;
	//-------------------------------------------------------------------------------------

	protected ES1Renderer(AndroidRenderEnv env, ES1Manager glm, ImageFactory imgfac, ESTextureStore ts) {
		super(env, glm, imgfac, ts);
		
		this.glm = glm;
		this.glDraw = glm.getGLDraw();
		this.allowCoordinateRounding = env.allowCoordinateRounding;
		this.enableCopyTexSubImage = false;
		
		this.fadeQuadRenderer = new ES1FadeQuadRenderer(this);
		this.blendQuadRenderer = new ES1BlendQuadRenderer(this);
		this.distortQuadRenderer = new ES1DistortQuadRenderer(this);
	}
	
	//Functions
	@Override
	protected void renderBegin() {
		//rendering = true;
		
		glDraw = glm.getGLDraw();
		glInfo = glm.getGLInfo();
		gl = glm.getGL();
		
		gl.glPushMatrix();
		
		//Translate and scale to virtual screen coords
		final float scale = (float)env.scale;
		dx = env.rx / scale;
		dy = env.ry / scale;
		gl.glScalef(scale, -scale, 1);
		gl.glTranslatef(dx, dy-env.sh/scale, 0);
		
		//Init GL state
		gl.glEnable(GL_SCISSOR_TEST);
		gl.glEnable(GL_BLEND);
		gl.glBlendFunc(GL_ONE, GL_ONE_MINUS_SRC_ALPHA);
		glDraw.setColor(0xFFFFFFFF);
		glDraw.setTexture(null, true);
	}
	
	@Override
	protected void renderEnd() {
		//Restore GL state
		glDraw.setTexture(null, true);
		glDraw.setColor(0xFFFFFFFF);
		gl.glEnable(GL_BLEND);
		gl.glBlendFunc(GL_ONE, GL_ONE_MINUS_SRC_ALPHA);
		gl.glDisable(GL_SCISSOR_TEST);
		
		gl.glPopMatrix();
		
		//rendering = false;
	}
		
	@Override
	protected void setClip(boolean c) {
		if (c) {
			gl.glEnable(GL_SCISSOR_TEST);
		} else {
			gl.glDisable(GL_SCISSOR_TEST);
		}
	}

	@Override
	protected void setColor(int argb) {
		glDraw.setColor(argb);
	}

	@Override
	protected void setBlendMode(BlendMode bm) {
		switch (bm) {
		case DEFAULT: gl.glEnable(GL_BLEND);  gl.glBlendFunc(GL_ONE, GL_ONE_MINUS_SRC_ALPHA); break;
		case ADD:     gl.glEnable(GL_BLEND);  gl.glBlendFunc(GL_ONE, GL_ONE); break;
		case OPAQUE:  gl.glDisable(GL_BLEND); break;
		}
	}
				
	@Override
	protected void setClipRect(Rect glRect) {
		gl.glScissor(glRect.x, glRect.y, glRect.w, glRect.h);
	}

	@Override
	protected void translate(double x, double y) {
		float tx = (float)x;
		float ty = (float)y;
		gl.glTranslatef(tx, ty, 0f);
		this.dx += tx;
		this.dy += ty;
	}
	
	private static FloatBuffer toGLFloatBuffer(FloatBuffer buf) {
		ByteBuffer resultB = ByteBuffer.allocateDirect(buf.limit() * 4);
		resultB.order(ByteOrder.nativeOrder());
		FloatBuffer result = resultB.asFloatBuffer();
		result.put(buf);
		result.rewind();
		return result;
	}
	
	@Override
	public void renderTriangleGrid(TriangleGrid grid) {
		gl.glEnableClientState(GL_VERTEX_ARRAY);
		for (int n = 0; n < grid.getTextures(); n++) {
			gl.glClientActiveTexture(GL_TEXTURE0 + n);
			gl.glEnableClientState(GL_TEXTURE_COORD_ARRAY);
		}
		for (int row = 0; row < grid.getRows(); row++) {
			gl.glVertexPointer(2, GL_FLOAT, 0, toGLFloatBuffer(grid.getPos(row)));
			for (int n = 0; n < grid.getTextures(); n++) {
				gl.glClientActiveTexture(GL_TEXTURE0 + n);
			    gl.glTexCoordPointer(2, GL_FLOAT, 0, toGLFloatBuffer(grid.getTex(n, row)));
			}
		    gl.glDrawArrays(GL_TRIANGLE_STRIP, 0, grid.getVertexCount(row));
		}
		for (int n = grid.getTextures()-1; n >= 0; n--) {
			gl.glClientActiveTexture(GL_TEXTURE0 + n);
			gl.glEnableClientState(GL_TEXTURE_COORD_ARRAY);
		}
	    gl.glDisableClientState(GL_VERTEX_ARRAY);		
	}
			
	@Override
	public void renderQuad(ITexture itex, Matrix t, Area2D bounds, Area2D uv, IPixelShader ps) {
		if (ps != null) ps.preDraw(this);
		
		GLTexture tex = null;
		boolean mipmap = false;
		boolean tiling = false;
		double u = uv.x;
		double v = uv.y;
		double uw = uv.w;
		double vh = uv.h;
		if (itex instanceof TextureAdapter) {			
			TextureAdapter ta = (TextureAdapter)itex;
			ta.glTryLoad(glm);
			GLTexRect tr = ta.getTexRect();

			Area2D texUV = tr.getUV();
			u  = texUV.x + u * texUV.w;
			v  = texUV.y + v * texUV.h;
			uw = texUV.w * uw;
			vh = texUV.h * vh;

			tex = tr.getTexture();			
			mipmap = tex.isMipmapped();
			tiling = tex.getWrapS() == GL10.GL_REPEAT || tex.getWrapT() == GL10.GL_REPEAT;
		}
		glDraw.setTexture(tex);
		
		//System.out.println((tex != null ? tex.glId() : 0) + " " + tex + " " + bounds);
		
		//System.out.printf("%d {%.0f,%.0f,%.0f,%.0f} {%.0f,%.0f,%.0f,%.0f}%n", texId, x, y, w, h, u, v, uw, vh);
		
		double x = bounds.x;
		double y = bounds.y;
		double w = bounds.w;
		double h = bounds.h;
		if (t.hasShear()) {			
			gl.glPushMatrix();
			gl.glMultMatrixf(t.toGLMatrix(), 0);
			glDraw.fillRect(x, y, w, h, u, v, uw, vh);
			gl.glPopMatrix();			
		} else {
			if (tex != null && tex.glIsLoaded() && glInfo.isDrawTexSupported() && !mipmap && !tiling) {
				double sx = t.getScaleX();
				double sy = t.getScaleY();
	
				v += vh;
				vh = -vh;
				
				double scale = env.scale;
				w = scale * (sx * w);
				h = scale * (sy * h);
				x = scale * (dx + sx * x + t.getTranslationX());
				y = env.sh - scale * (dy + sy * y + t.getTranslationY()) - h;
				
				int texId = tex.glId();
				int tw = tex.getTexWidth();
				int th = tex.getTexHeight();
				if (allowCoordinateRounding) {
					glDraw.drawTexRecti(texId, tw, th, round(x), round(y), round(w), round(h), tw*u, th*v, tw*uw, th*vh);
				} else {
					glDraw.drawTexRectf(texId, tw, th, x, y, w, h, tw*u, th*v, tw*uw, th*vh);
				}
			} else {
				double sx = t.getScaleX();
				double sy = t.getScaleY();
				x = x * sx + t.getTranslationX();
				y = y * sy + t.getTranslationY();
				w = w * sx;
				h = h * sy;
				
				glDraw.fillRect(x, y, w, h, u, v, uw, vh);
			}
		}
		
		if (ps != null) ps.postDraw(this);				
	}

	@Override
	public void renderBlendQuad(ITexture tex0, double alignX0, double alignY0, ITexture tex1, double alignX1,
			double alignY1, double frac, Matrix transform, IPixelShader ps)
	{
		blendQuadRenderer.renderBlendQuad(tex0, alignX0, alignY0, tex1, alignX1, alignY1, frac, transform, ps);
	}

	@Override
	public void renderFadeQuad(ITexture tex, Matrix transform, int color0, int color1,
			Area2D bounds, Area2D uv, IPixelShader ps,
			int dir, boolean fadeIn, double span, double frac)
	{
		//System.out.println(x + " " + y + " " + w + " " + h);
		
		//renderQuad(tex, transform, x, y, w, h, ps, 0, 0, 1, 1);
		fadeQuadRenderer.renderFadeQuad(tex, transform, color0, color1, bounds, uv, ps, dir, fadeIn, span, frac);
	}

	@Override
	public void renderDistortQuad(ITexture tex, Matrix transform, int argb,
			Area2D bounds, Area2D uv, IPixelShader ps,
			IDistortGrid grid, Rect2D clampBounds)
	{
		distortQuadRenderer.renderDistortQuad(tex, transform, argb, bounds, uv, ps, grid, clampBounds);
	}

	@Override
	public void renderScreenshot(IScreenshot out, Rect glScreenRect) {
		Screenshot ss = (Screenshot)out;
		
		boolean done = false;
		if (enableCopyTexSubImage && ss.isVolatile()) {
			GLWritableTexture glTex = texStore.newWritableTexture(glScreenRect.w, glScreenRect.h);
			GLTexRect glTexRect = glTex.getSubRect(GLUtil.TEXRECT_FLIPPED);

			final int fmt = GL_RGB;
			final int type = GL_UNSIGNED_BYTE;
			
			gl.glEnable(GL_TEXTURE_2D);
			gl.glBindTexture(GL_TEXTURE_2D, glTex.glId());
			gl.glTexImage2D(GL_TEXTURE_2D, 0, fmt, glTex.getTexWidth(), glTex.getTexHeight(), 0, fmt, type, null);
			gl.glCopyTexSubImage2D(GL_TEXTURE_2D, 0, 0, 0, glScreenRect.x, glScreenRect.y, glScreenRect.w, glScreenRect.h);
			int err = gl.glGetError();
			gl.glBindTexture(GL_TEXTURE_2D, 0);
			
			if (err == 0) {			
				ITexture tex = imgfac.createTexture(glTexRect, env.vw / (double)env.rw, env.vh / (double)env.rh);			
				ss.setVolatilePixels(tex, env.rw, env.rh);
				done = true;
			} else {
				glTex.glUnload();
			}
		}
		
		if (!done) { //Non-volatile or volatile copy failed.
			ss.setPixels(glm, glScreenRect, env.rw, env.rh);
			done = true;
		}
	}

	@Override
	protected boolean renderUnknownCommand(RenderCommand cmd) {
		return false;
	}
	
}

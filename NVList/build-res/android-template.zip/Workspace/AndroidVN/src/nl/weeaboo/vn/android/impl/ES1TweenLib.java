package nl.weeaboo.vn.android.impl;

import java.io.ObjectStreamException;

import nl.weeaboo.gl.GLInfo;
import nl.weeaboo.io.EnvironmentSerializable;
import nl.weeaboo.lua2.io.LuaSerializable;
import nl.weeaboo.vn.IImageTween;
import nl.weeaboo.vn.IInterpolator;
import nl.weeaboo.vn.INotifier;
import nl.weeaboo.vn.IShaderFactory;
import nl.weeaboo.vn.impl.base.CrossFadeTween;
import nl.weeaboo.vn.impl.lua.LuaTweenLib;

@LuaSerializable
public class ES1TweenLib extends LuaTweenLib {

	private static final long serialVersionUID = AndroidImpl.serialVersionUID;

	private final ImageFactory imgfac;
	//private final IShaderFactory shfac;
	private final EnvironmentSerializable es;
	
	public ES1TweenLib(INotifier ntf, ImageFactory imgfac, IShaderFactory shfac) {
		super(ntf, imgfac, shfac);
		
		this.imgfac = imgfac;
		//this.shfac = shfac;
		this.es = new EnvironmentSerializable(this);
	}

	//Functions
	private Object writeReplace() throws ObjectStreamException {	
		return es.writeReplace();
	}
	
	@Override
	protected IImageTween newCrossFadeTween(double duration, IInterpolator i) {
		return new CrossFadeTween(duration, i);
	}

	@Override
	protected IImageTween newBitmapTween(String fadeFilename, double duration, double range,
			IInterpolator i, boolean fadeTexTile)
	{
		throw new RuntimeException("Unsupported operation");
	}

	//Getters
	@Override
	public boolean isCrossFadeTweenAvailable() {
		GLInfo glInfo = imgfac.getGLInfo();
		return ES1BlendQuadRenderer.isAvailable(glInfo);
	}

	@Override
	public boolean isBitmapTweenAvailable() {
		return false;
	}
	
	//Setters
	
}

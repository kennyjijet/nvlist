package nl.weeaboo.vn.android.impl;

import java.io.IOException;
import java.io.ObjectStreamException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import nl.weeaboo.android.AndroidFileSystem;
import nl.weeaboo.android.FileSegment;
import nl.weeaboo.filesystem.FileSystemUtil;
import nl.weeaboo.io.EnvironmentSerializable;
import nl.weeaboo.lua2.io.LuaSerializable;
import nl.weeaboo.vn.INotifier;
import nl.weeaboo.vn.ISeenLog;
import nl.weeaboo.vn.ISound;
import nl.weeaboo.vn.SoundType;
import nl.weeaboo.vn.impl.base.BaseSoundFactory;
import android.os.Handler;
import android.os.Looper;

@LuaSerializable
public final class SoundFactory extends BaseSoundFactory implements Serializable {

	private final AndroidFileSystem afs;
	private final String soundFolderPrefix;
	private SoundLooper soundLooper;

	private final EnvironmentSerializable es;
	
	public SoundFactory(AndroidFileSystem afs, String soundFolderPrefix,
			ISeenLog sl, INotifier ntf)
	{
		super(sl, ntf);
		
		this.afs = afs;
		this.soundFolderPrefix = soundFolderPrefix;
		
		soundLooper = new SoundLooper();
	
		this.es = new EnvironmentSerializable(this);
		
		Thread thread = new Thread(soundLooper, "SoundLooper");
		thread.setDaemon(true);
		thread.start();
	}
	
	//Functions
	private Object writeReplace() throws ObjectStreamException {	
		return es.writeReplace();
	}
	
	public void dispose() {
		Handler handler = getSoundHandler();
		handler.getLooper().quit();
		
		soundLooper = null;
	}
	
	@Override
	protected void preloadNormalized(String filename) {
		//TODO Implement preload?
	}
	
	@Override
	public ISound createSoundNormalized(SoundType stype, String filename,
			String[] callStack) throws IOException
	{
		return new Sound(this, stype, soundFolderPrefix, filename);
	}
	
	//Getters
	public INotifier getNotifier() {
		return notifier;
	}
	public FileSegment getFileSegment(String path) throws IOException {
		return afs.getFileSegment(path);
	}
	public Handler getSoundHandler() {
		return soundLooper.getHandler();
	}
	
	@Override
	public String getNameNormalized(String filename) {
		return null; //Not supported in Android
	}

	@Override
	protected boolean isValidFilename(String filename) {
		return afs.getFileExists(soundFolderPrefix + filename);
	}
	
	@Override
	protected List<String> getFiles(String folder) {
		List<String> out = new ArrayList<String>();
		try {
			getSoundFiles(out, folder, true);
		} catch (IOException e) {
			notifier.d("Folder doesn't exist or can't be read: " + folder, e);
		}
		return out;
	}
	
	private void getSoundFiles(Collection<String> out, String folder, boolean recursive) throws IOException {
		Collection<String> temp = new ArrayList<String>();
		afs.getFiles(temp, soundFolderPrefix + folder, recursive);
		temp = FileSystemUtil.withoutPathPrefix(temp, soundFolderPrefix);
		out.addAll(temp);
	}
	
	//Setters
	
	//Inner Classes
	private static class SoundLooper implements Runnable {

		private volatile Handler msgHandler;
		
		@Override
		public void run() {
			Looper.prepare();
			msgHandler = new Handler();
			Looper.loop();
		}
		
		public Handler getHandler() {
			if (msgHandler != null) {
				return msgHandler;
			}
			
			for (int n = 0; msgHandler == null && n < 1000; n++) {
				try {
					Thread.sleep(1);
				} catch (InterruptedException e) { }
			}
			if (msgHandler == null) {
				throw new RuntimeException("Unable to create messagehandler");
			}
			return msgHandler;
		}
		
	}
	
}

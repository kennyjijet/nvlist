package nl.weeaboo.vn.android.impl;

import java.io.IOException;
import java.io.ObjectStreamException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

import nl.weeaboo.android.ResourceManager;
import nl.weeaboo.io.EnvironmentSerializable;
import nl.weeaboo.lua2.io.LuaSerializable;
import nl.weeaboo.vn.INotifier;
import nl.weeaboo.vn.ISeenLog;
import nl.weeaboo.vn.ISound;
import nl.weeaboo.vn.SoundType;
import nl.weeaboo.vn.impl.base.BaseSoundFactory;
import android.os.Handler;
import android.os.Looper;

@LuaSerializable
public final class SoundFactory extends BaseSoundFactory implements Serializable {

	private final ResourceManager rm;
	private final String soundFolderPrefix;
	private SoundLooper soundLooper;

	private final EnvironmentSerializable es;
	
	public SoundFactory(ResourceManager rm, String soundFolderPrefix,
			ISeenLog sl, INotifier ntf)
	{
		super(sl, ntf);
		
		this.rm = rm;
		this.soundFolderPrefix = soundFolderPrefix;
		
		soundLooper = new SoundLooper();
	
		this.es = new EnvironmentSerializable(this);
		
		Thread thread = new Thread(soundLooper, "SoundLooper");
		thread.setDaemon(true);
		thread.start();
	}
	
	//Functions
	private Object writeReplace() throws ObjectStreamException {	
		return es.writeReplace();
	}
	
	public void dispose() {
		Handler handler = getSoundHandler();
		handler.getLooper().quit();
		
		soundLooper = null;
	}
	
	@Override
	protected void preloadNormalized(String filename) {
		//TODO Implement preload?
	}
	
	@Override
	public ISound createSoundNormalized(SoundType stype, String filename,
			String[] callStack) throws IOException
	{
		return new Sound(this, stype, soundFolderPrefix, filename);
	}
	
	//Getters
	public INotifier getNotifier() {
		return notifier;
	}
	public ResourceManager getResourceManager() {
		return rm;
	}
	public Handler getSoundHandler() {
		return soundLooper.getHandler();
	}
	
	@Override
	public String getNameNormalized(String filename) {
		return null; //Not supported in Android
	}

	@Override
	protected boolean isValidFilename(String filename) {
		return rm.getFileExists(soundFolderPrefix + filename);
	}
	
	@Override
	protected Collection<String> getFiles(String folder) {
		try {
			return getSoundFiles(folder, true);
		} catch (IOException e) {
			notifier.d("Folder doesn't exist or can't be read: " + folder, e);
		}
		return Collections.emptyList();
	}
	
	private Collection<String> getSoundFiles(String folder, boolean recursive) throws IOException {
		List<String> result = new ArrayList<String>();
		for (String path : rm.getFolderContents(soundFolderPrefix + folder, recursive)) {
			if (path.length() > soundFolderPrefix.length()
					&& path.charAt(soundFolderPrefix.length()) == '/')
			{
				//Path without pathPrefix would start with a '/'
				result.add(path.substring(soundFolderPrefix.length()+1));
			} else {
				result.add(path.substring(soundFolderPrefix.length()));
			}
		}
		return result;
	}
	
	//Setters
	
	//Inner Classes
	private static class SoundLooper implements Runnable {

		private volatile Handler msgHandler;
		
		@Override
		public void run() {
			Looper.prepare();
			msgHandler = new Handler();
			Looper.loop();
		}
		
		public Handler getHandler() {
			if (msgHandler != null) {
				return msgHandler;
			}
			
			for (int n = 0; msgHandler == null && n < 1000; n++) {
				try {
					Thread.sleep(1);
				} catch (InterruptedException e) { }
			}
			if (msgHandler == null) {
				throw new RuntimeException("Unable to create messagehandler");
			}
			return msgHandler;
		}
		
	}
	
}

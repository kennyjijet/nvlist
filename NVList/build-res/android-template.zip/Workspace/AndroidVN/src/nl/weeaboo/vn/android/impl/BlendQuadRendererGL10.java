package nl.weeaboo.vn.android.impl;

import static javax.microedition.khronos.opengles.GL10.GL_MODULATE;
import static javax.microedition.khronos.opengles.GL10.GL_SRC_ALPHA;
import static javax.microedition.khronos.opengles.GL10.GL_SRC_COLOR;
import static javax.microedition.khronos.opengles.GL10.GL_TEXTURE0;
import static javax.microedition.khronos.opengles.GL10.GL_TEXTURE1;
import static javax.microedition.khronos.opengles.GL10.GL_TEXTURE_2D;
import static javax.microedition.khronos.opengles.GL10.GL_TEXTURE_ENV;
import static javax.microedition.khronos.opengles.GL10.GL_TEXTURE_ENV_COLOR;
import static javax.microedition.khronos.opengles.GL10.GL_TEXTURE_ENV_MODE;
import static javax.microedition.khronos.opengles.GL11.GL_COMBINE;
import static javax.microedition.khronos.opengles.GL11.GL_COMBINE_ALPHA;
import static javax.microedition.khronos.opengles.GL11.GL_COMBINE_RGB;
import static javax.microedition.khronos.opengles.GL11.GL_CONSTANT;
import static javax.microedition.khronos.opengles.GL11.GL_INTERPOLATE;
import static javax.microedition.khronos.opengles.GL11.GL_OPERAND0_ALPHA;
import static javax.microedition.khronos.opengles.GL11.GL_OPERAND0_RGB;
import static javax.microedition.khronos.opengles.GL11.GL_OPERAND1_ALPHA;
import static javax.microedition.khronos.opengles.GL11.GL_OPERAND1_RGB;
import static javax.microedition.khronos.opengles.GL11.GL_OPERAND2_ALPHA;
import static javax.microedition.khronos.opengles.GL11.GL_OPERAND2_RGB;
import static javax.microedition.khronos.opengles.GL11.GL_PREVIOUS;
import static javax.microedition.khronos.opengles.GL11.GL_PRIMARY_COLOR;
import static javax.microedition.khronos.opengles.GL11.GL_SRC0_ALPHA;
import static javax.microedition.khronos.opengles.GL11.GL_SRC0_RGB;
import static javax.microedition.khronos.opengles.GL11.GL_SRC1_ALPHA;
import static javax.microedition.khronos.opengles.GL11.GL_SRC1_RGB;
import static javax.microedition.khronos.opengles.GL11.GL_SRC2_ALPHA;
import static javax.microedition.khronos.opengles.GL11.GL_SRC2_RGB;

import javax.microedition.khronos.opengles.GL;
import javax.microedition.khronos.opengles.GL10;

import nl.weeaboo.android.gl.GLDraw;
import nl.weeaboo.common.Rect2D;
import nl.weeaboo.vn.ITexture;
import nl.weeaboo.vn.impl.base.BlendQuadHelper;
import nl.weeaboo.vn.impl.base.TriangleGrid;
import nl.weeaboo.vn.impl.base.TriangleGrid.TextureWrap;
import nl.weeaboo.vn.math.Matrix;

class BlendQuadRendererGL10 extends BlendQuadHelper {

	public static String[] REQUIRED_EXTENSIONS = new String[] {
		"GL_ARB_texture_env_crossbar",
		"GL_ARB_texture_env_combine"
	};
	
	private final Renderer renderer;
	
	public BlendQuadRendererGL10(Renderer r) {
		super(r);
		
		renderer = r;
	}

	//Functions
	@Override
	protected void renderQuad(ITexture tex, Matrix transform, int mixColorARGB, Rect2D bounds) {
		GL10 gl = (GL10)renderer.getGL();
		GLDraw.setColorPre(gl, GLDraw.premultiplyAlpha(mixColorARGB));
		renderer.renderQuad(tex, transform, bounds.x, bounds.y, bounds.w, bounds.h, null, 0, 0, 1, 1);
	}

	@Override
	protected void renderMultitextured(ITexture tex0, Rect2D bounds0, ITexture tex1, Rect2D bounds1,
			Matrix transform, float tex0Factor)
	{
		GL10 gl = (GL10)renderer.getGL();
		
		float f = tex0Factor;
		int texId0 = getTexId(tex0);
		int texId1 = getTexId(tex1);
		Rect2D uv0 = tex0.getUV();
		Rect2D uv1 = tex1.getUV();
		
		//Set texture 0
		gl.glActiveTexture(GL_TEXTURE0);
		gl.glEnable(GL_TEXTURE_2D);
		gl.glBindTexture(GL_TEXTURE_2D, texId0);

		gl.glTexEnvfv(GL_TEXTURE_ENV, GL_TEXTURE_ENV_COLOR, new float[] {f, f, f, f}, 0);
		gl.glTexEnvx(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_COMBINE);
		
		gl.glTexEnvx(GL_TEXTURE_ENV, GL_COMBINE_RGB, GL_INTERPOLATE);
		gl.glTexEnvx(GL_TEXTURE_ENV, GL_SRC0_RGB, GL_TEXTURE0);
		gl.glTexEnvx(GL_TEXTURE_ENV, GL_SRC1_RGB, GL_TEXTURE1);
		gl.glTexEnvx(GL_TEXTURE_ENV, GL_SRC2_RGB, GL_CONSTANT);
		gl.glTexEnvx(GL_TEXTURE_ENV, GL_OPERAND0_RGB, GL_SRC_COLOR);
		gl.glTexEnvx(GL_TEXTURE_ENV, GL_OPERAND1_RGB, GL_SRC_COLOR);
		gl.glTexEnvx(GL_TEXTURE_ENV, GL_OPERAND2_RGB, GL_SRC_COLOR);

		gl.glTexEnvx(GL_TEXTURE_ENV, GL_COMBINE_ALPHA, GL_INTERPOLATE);
		gl.glTexEnvx(GL_TEXTURE_ENV, GL_SRC0_ALPHA, GL_TEXTURE0);
		gl.glTexEnvx(GL_TEXTURE_ENV, GL_SRC1_ALPHA, GL_TEXTURE1);
		gl.glTexEnvx(GL_TEXTURE_ENV, GL_SRC2_ALPHA, GL_CONSTANT);
		gl.glTexEnvx(GL_TEXTURE_ENV, GL_OPERAND0_ALPHA, GL_SRC_ALPHA);
		gl.glTexEnvx(GL_TEXTURE_ENV, GL_OPERAND1_ALPHA, GL_SRC_ALPHA);
		gl.glTexEnvx(GL_TEXTURE_ENV, GL_OPERAND2_ALPHA, GL_SRC_ALPHA);
		
		// Set texture 1
		gl.glActiveTexture(GL_TEXTURE1);
		gl.glEnable(GL_TEXTURE_2D);
		gl.glBindTexture(GL_TEXTURE_2D, texId1);
		
		gl.glTexEnvfv(GL_TEXTURE_ENV, GL_TEXTURE_ENV_COLOR, new float[] {1, 1, 1, 1}, 0);
		gl.glTexEnvx(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_COMBINE);
		
		gl.glTexEnvx(GL_TEXTURE_ENV, GL_COMBINE_RGB, GL_MODULATE);
		gl.glTexEnvx(GL_TEXTURE_ENV, GL_SRC0_RGB, GL_PREVIOUS);
		gl.glTexEnvx(GL_TEXTURE_ENV, GL_SRC1_RGB, GL_PRIMARY_COLOR);
		gl.glTexEnvx(GL_TEXTURE_ENV, GL_OPERAND0_RGB, GL_SRC_COLOR);
		gl.glTexEnvx(GL_TEXTURE_ENV, GL_OPERAND1_RGB, GL_SRC_COLOR);

		gl.glTexEnvx(GL_TEXTURE_ENV, GL_COMBINE_ALPHA, GL_MODULATE);
		gl.glTexEnvx(GL_TEXTURE_ENV, GL_SRC0_ALPHA, GL_PREVIOUS);
		gl.glTexEnvx(GL_TEXTURE_ENV, GL_SRC1_ALPHA, GL_PRIMARY_COLOR);
		gl.glTexEnvx(GL_TEXTURE_ENV, GL_OPERAND0_ALPHA, GL_SRC_ALPHA);
		gl.glTexEnvx(GL_TEXTURE_ENV, GL_OPERAND1_ALPHA, GL_SRC_ALPHA);		
		
		//Render triangle grid
		gl.glPushMatrix();
		gl.glMultMatrixf(transform.toGLMatrix(), 0);		
		TriangleGrid grid = TriangleGrid.layout2(
				bounds0, uv0, TextureWrap.CLAMP,
				bounds1, uv1, TextureWrap.CLAMP);			
		renderer.renderTriangleGrid(grid);
	    gl.glPopMatrix();
		
		//Reset texture
		gl.glActiveTexture(GL_TEXTURE1);
		gl.glTexEnvx(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
		gl.glDisable(GL_TEXTURE_2D);
		gl.glActiveTexture(GL_TEXTURE0);
		gl.glTexEnvx(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
	}
	
	//Getters
	protected int getTexId(ITexture tex) {
		GL gl = renderer.getGL();
		TextureAdapter ta = (TextureAdapter)tex;
		renderer.forceLoad(gl, ta);
		return ta.getTexId();
	}
	
	@Override
	protected boolean isFallbackRequired() {
		for (String ext : REQUIRED_EXTENSIONS) {
			if (!GLDraw.isGLExtensionAvailable(ext)) {
				return true;
			}
		}
		return false;
	}
	
	//Setters
	
}

package nl.weeaboo.android.gui;

import nl.weeaboo.styledtext.MutableTextStyle;
import nl.weeaboo.styledtext.TextStyle;
import android.text.BoringLayout;
import android.text.Layout;
import android.text.Layout.Alignment;
import android.text.StaticLayout;
import android.text.TextPaint;

public final class TextLayoutUtil {

	private TextLayoutUtil() {		
	}
	
	public static TextPaint getTextPaint() {
		return getTextPaint(1f);
	}
	public static TextPaint getTextPaint(double density) {
		TextPaint paint = new TextPaint();
		paint.setTextSize((float)(paint.getTextSize() * 2.0 * density));
		paint.setAntiAlias(true);
		paint.setARGB(0xff, 0xff, 0xff, 0xff);
		return paint;
	}
	
	public static Layout doLayout(CharSequence text, int width) {
		return doLayout(text, width, getTextPaint(), Alignment.ALIGN_NORMAL);
	}
	public static Layout doLayout(CharSequence text, int width, TextPaint paint, Alignment align) {
		if (text.length() == 0) {
			BoringLayout.Metrics boringMetrics = BoringLayout.isBoring(text, paint);
			if (boringMetrics != null) {
				return new BoringLayout(text, paint, width, align, 1f, 0f, boringMetrics, true);
			}
		}
		return new StaticLayout(text, paint, width, align, 1f, 0f, true);
	}
	
	public static TextStyle getDefaultStyle() {
		double shadowOffset = TextLayoutUtil.getTextPaint().getTextSize() / 18;
		
		MutableTextStyle mts = new MutableTextStyle();
		mts.setShadowColor(0xFF000000);
		mts.setShadowDx(shadowOffset);
		mts.setShadowDy(shadowOffset);
		return mts.immutableCopy();
	}
	
}

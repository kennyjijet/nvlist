package nl.weeaboo.android.gui;

public interface Painter {

	public void repaint();
	
}

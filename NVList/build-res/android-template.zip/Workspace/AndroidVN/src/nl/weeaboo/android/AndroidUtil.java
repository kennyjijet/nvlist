package nl.weeaboo.android;

import java.lang.reflect.Method;

import nl.weeaboo.android.gui.ProgressAsyncTask;
import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Handler;
import android.os.Message;
import android.util.Log;

public class AndroidUtil {
	
	private static final String TAG = "AndroidUtil";
	
	public static Message createMessage(Handler h, int what) {
		return createMessage(h, what, null);
	}
	public static Message createMessage(Handler h, int what, Object data) {
		Message msg = Message.obtain();
		msg.what = what;
		msg.obj = data;
		msg.setTarget(h);
		return msg;
	}
	
	public static boolean isTaskRunning(AsyncTask<?, ?, ?> task) {
    	return task != null && !task.isCancelled()
    		&& task.getStatus() != AsyncTask.Status.FINISHED;
	}
	
	public static void cancelTask(AsyncTask<?, ?, ?> task) {
		if (isTaskRunning(task)) {
			task.cancel(true);
			if (task instanceof ProgressAsyncTask) {
				((ProgressAsyncTask<?, ?>)task).onCancelled();
			}
		}
	}
	
	public static void initStrictMode() {
		try {
			Class<?> strictModeClass = Class.forName("android.os.StrictMode");
			strictModeClass.getMethod("enableDefaults").invoke(null);
		} catch (ClassNotFoundException e) {
			//StrictMode not supported, Android version probably < 2.3
		} catch (Exception e) {
			Log.w(TAG, "Error initializing StrictMode", e);
		}		
	}
	
	private static Object getActionBar(Activity activity) {
		try {
			Method getter = activity.getClass().getMethod("getActionBar");
			if (getter == null) return null;
			return getter.invoke(activity);
		} catch (NoSuchMethodException e) {
			//No getter for action bar
		} catch (Exception e) {
			//Something went wrong
		}
		return null;
	}
	
	public static boolean supportsActionBar(Activity activity) {
		try {
			return activity.getClass().getMethod("getActionBar") != null;
		} catch (Exception e) {
			//Something went wrong
		}
		return Build.VERSION.SDK_INT >= 11; //Assume action bar exists after 3.0
	}
	
	public static boolean trySetSubtitle(Activity activity, String title) {
		try {
			Object actionBar = getActionBar(activity);
			if (actionBar != null) {
				actionBar.getClass().getMethod("setSubtitle", CharSequence.class).invoke(actionBar, title);
				return true;
			}
		} catch (RuntimeException re) {
			Log.e(TAG, "Exception while trying to set subtitle", re);
		} catch (Exception e) {
			Log.e(TAG, "Exception while trying to set subtitle", e);
		}
		return false;
	}

	public static void setActionBarVisible(Activity activity, boolean v) {
		try {
			Object actionBar = getActionBar(activity);
			if (actionBar != null) {
				actionBar.getClass().getMethod(v ? "show" : "hide").invoke(actionBar);
			}
		} catch (RuntimeException re) {
			Log.e(TAG, "Exception while trying to set visibility", re);
		} catch (Exception e) {
			Log.e(TAG, "Exception while trying to set visibility", e);
		}
	}
	
	private static final String DEBUG_KEY = "308201e53082014ea00302010202044e81c149300d06092a864886f70d01010505003037310b30090603550406130255533110300e060355040a1307416e64726f6964311630140603550403130d416e64726f6964204465627567301e170d3131303932373132323735335a170d3431303931393132323735335a3037310b30090603550406130255533110300e060355040a1307416e64726f6964311630140603550403130d416e64726f696420446562756730819f300d06092a864886f70d010101050003818d0030818902818100c936d546ecdb23a0b40c3fc5fcdda5dca2e35d5ff2051f16530cf7d3a37ed7e96927d3514e8eca5906f6e0a1f4291336eea10f112f0b89abaa577290970adc4176064e6122bb8ae2c8324e6b7372771e8ae8fb573a587bedd16f72669f29c03716e1de1bc59a25861326544bb933a87118f682931c8bc4e7aea4879044e78b530203010001300d06092a864886f70d0101050500038181003028566b0fc6ed4444bdd24ca8752d2d1ab20eccece1e0a0857b5afab8262ede216a2d183c2eaf1ec208ddc6f674416f7754bd27b8a39169cf09098bc4193d5c6a4bb880a9b22897f4a5b6e279f5e23c2922788512f87a96374e4b12dfd178df0fa3d1bce8947a28c7ab1cb59e1e53a501d4da4792cb4d9e2e5616d20a801f51";    

	public static boolean isDebugSigned(Context context, Class<?> clazz) {
		try {
			ComponentName compName = new ComponentName(context, clazz);
			PackageInfo pinfo = context.getPackageManager().getPackageInfo(compName.getPackageName(),
					PackageManager.GET_SIGNATURES);

			//Print all signatures to console (for debugging purposes)
			//for (Signature sig : pinfo.signatures) Log.d(TAG, sig.toCharsString());
			
			if (pinfo.signatures.length > 0 && DEBUG_KEY.equals(pinfo.signatures[0].toCharsString())) {
				//Log.d(TAG, "USES DEBUG KEY");
				return true;
			} else {
				return false;
			}	
		} catch (NameNotFoundException e) {
			return false;
		}

	}
}

package nl.weeaboo.vn.android.impl;

import nl.weeaboo.lua2.io.LuaSerializable;
import nl.weeaboo.vn.ILayer;
import nl.weeaboo.vn.impl.base.BaseViewport;

@LuaSerializable
public class Viewport extends BaseViewport {

	private static final long serialVersionUID = AndroidImpl.serialVersionUID;

	public Viewport(ILayer layer) {
		super(layer);
	}
	
	//Functions
	
	//Getters
	
	//Setters
	
}

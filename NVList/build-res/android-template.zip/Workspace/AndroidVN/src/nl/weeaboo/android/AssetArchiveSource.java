package nl.weeaboo.android;

import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import nl.weeaboo.common.StringUtil;
import nl.weeaboo.filesystem.IArchiveSource;
import nl.weeaboo.obfuscator.IObfuscator;
import nl.weeaboo.zip.IFileArchive;
import android.content.res.AssetManager;

public class AssetArchiveSource implements IArchiveSource {

	public static final String ASSETS_FILENAME = "$assets";
	
	private final AssetManager assets;
	private final int versionCode;
	private final IObfuscator obfuscator;
	private final Set<String> obfuscatedExtensions;
	private final File cacheFolder;
	
	public AssetArchiveSource(AssetManager assets, int versionCode, IObfuscator obf, File cacheFolder) {
		this.assets = assets;
		this.versionCode = versionCode;
		this.obfuscator = obf;
		this.obfuscatedExtensions = new HashSet<String>(Arrays.asList("obb", "enc", "nvl"));
		this.cacheFolder = cacheFolder;
	}

	//Functions
	@Override
	public IFileArchive newArchive(String filename) {
		boolean obfuscate = obfuscatedExtensions.contains(StringUtil.getExtension(filename));
		return new AssetZipArchive(cacheFolder, versionCode, (obfuscate ? obfuscator : null));
	}
	
	//Functions
	@Override
	public void openArchive(IFileArchive arc, String filename) throws IOException {
		if (!getArchiveExists(filename)) {
			return;
		}
		
		AssetZipArchive azip = (AssetZipArchive)arc;
		azip.open(assets);
	}

	@Override
	public boolean getArchiveExists(String filename) {
		return filename.equals(ASSETS_FILENAME);
	}
	
	//Getters
	
	//Setters

}

package nl.weeaboo.vn.android.impl;

import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectStreamException;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;

import nl.weeaboo.android.AndroidFileSystem;
import nl.weeaboo.common.Dim;
import nl.weeaboo.common.ScaleUtil;
import nl.weeaboo.common.StringUtil;
import nl.weeaboo.io.EnvironmentSerializable;
import nl.weeaboo.lua2.io.LuaSerializable;
import nl.weeaboo.lua2.io.ObjectSerializer;
import nl.weeaboo.lua2.io.ObjectSerializer.PackageLimit;
import nl.weeaboo.vn.INotifier;
import nl.weeaboo.vn.IScreenshot;
import nl.weeaboo.vn.impl.lua.LuaSaveHandler;
import nl.weeaboo.vn.impl.lua.LuaSaveInfo;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.util.Log;

@LuaSerializable
public class SaveHandler extends LuaSaveHandler {

	private static final String TAG = "SaveHandler";
	
	private static final String pathPrefix = "save/";
	private final AndroidFileSystem afs;
	private final INotifier notifier;
	
	private final EnvironmentSerializable es;
	
	public SaveHandler(AndroidFileSystem afs, INotifier n, PackageLimit pl) {
		super(1);
		
		this.afs = afs;
		this.notifier = n;
		setPackageLimit(pl);
		
		addAllowedPackages(
				"nl.weeaboo.image",			//For ImageDesc (used by TexLoadParam)
				"nl.weeaboo.game.resmgr",	//For DataHolder
				"nl.weeaboo.gl",
				"nl.weeaboo.gl.shader",
				"nl.weeaboo.gl.tex",
				"nl.weeaboo.gl.tex.loader"	//For TexLoadParam
				);
		
		es = new EnvironmentSerializable(this);
	}
	
	//Functions
	private Object writeReplace() throws ObjectStreamException {	
		return es.writeReplace();
	}
	
	@Override
	protected LuaSaveInfo newSaveInfo(int slot) {
		return new SaveInfo(slot);
	}
	
	@Override
	public void delete(int slot) throws IOException {
		try {
			afs.delete(getFilename(slot));
		} catch (FileNotFoundException fnfe) {
			//Ignore
		}
		
		if (getSaveExists(slot)) {
			throw new IOException("Deletion of slot " + slot + " failed");
		}
	}
	
	@Override
	protected byte[] encodeScreenshot(IScreenshot ss, Dim maxSize) {
		if (ss == null || ss.isCancelled() || !ss.isAvailable()) {
			return new byte[0];
		}
		
		Bitmap bitmap = null;
		if (ss instanceof Screenshot) {
			bitmap = ((Screenshot)ss).toBitmap();
		} else {
			int[] argb = ss.getPixels();
			int w = ss.getPixelsWidth();
			int h = ss.getPixelsHeight();
			if (argb != null && w > 0 && h > 0) {
				bitmap = Bitmap.createBitmap(argb, w, h, Bitmap.Config.RGB_565);
			}
		}
		
		if (bitmap == null) {
			return new byte[0];
		}
		
		if (maxSize != null && (maxSize.w < bitmap.getWidth() || maxSize.h < bitmap.getHeight())) {
			Dim d = ScaleUtil.scaleProp(bitmap.getWidth(), bitmap.getHeight(), maxSize.w, maxSize.h);
			if (d.w > 0 && d.h > 0) {
				bitmap = Bitmap.createScaledBitmap(bitmap, d.w, d.h, true);
			}
		}
		
		ByteArrayOutputStream bout = new ByteArrayOutputStream(16<<10);
		bitmap.compress(CompressFormat.JPEG, 80, bout);
		bitmap.recycle();
		return bout.toByteArray();
	}
	
	//Getters
	protected String getFilename(int slot) {
		return String.format(StringUtil.LOCALE, "%ssave-%03d.sav", pathPrefix, slot);		
	}
	
	protected int getSlot(String filename) {
		if (filename.endsWith(".sav")) {
			int index = filename.lastIndexOf('-');
			String part = filename.substring(index+1, filename.length()-4);
			if (part.length() == 3 || (part.length() > 0 && part.charAt(0) != '0')) {
				try {
					return Integer.parseInt(part);
				} catch (NumberFormatException nfe) {
					//Ignore
				}
			}			
		}
		return 0;
	}
	
	@Override
	public boolean getSaveExists(int slot) {
		return afs.getFileExists(getFilename(slot));
	}

	@Override
	public LuaSaveInfo[] getSaves(int start, int end) {
		List<LuaSaveInfo> result = new ArrayList<LuaSaveInfo>();

		Collection<String> existingFiles = new ArrayList<String>();
		try {
			afs.getFiles(existingFiles, pathPrefix, false);
		} catch (IOException ioe) {
			Log.w(TAG, "Error getting file list", ioe);
		}
		
		for (String filename : existingFiles) {
			int slot = getSlot(filename);
			if (slot >= start && slot < end) {
				try {
					LuaSaveInfo si = loadSaveInfo(slot);
					result.add(si);
				} catch (IOException e) {
					Log.w(TAG, "Unreadable save slot: " + filename, e);
					
					try {
						afs.delete(filename);
						//rm.delete(filename+".bak");
						//rm.rename(filename, filename+".bak");
					} catch (IOException ioe2) {
						//Ignore
					}
				}
			}
		}
		return result.toArray(new LuaSaveInfo[result.size()]);
	}
	
	@Override
	protected InputStream openSaveInputStream(int slot) throws IOException {
		return afs.newInputStream(getFilename(slot));
	}

	@Override
	protected OutputStream openSaveOutputStream(int slot) throws IOException {
		String filename = getFilename(slot);
		if (afs.getFileExists(filename + ".bak")) {
			afs.delete(filename + ".bak");
		}
		return afs.newOutputStream(filename, false);
	}

	@Override
	protected void onSaveWarnings(String[] warnings) {
		notifier.w(ObjectSerializer.toErrorString(Arrays.asList(warnings)));
	}
	
	public void setQuicksave(boolean qs) {
		if (qs) {
			chunkSaveIgnoreList.add(CHUNK_DATA_ID);
		} else {
			chunkSaveIgnoreList.remove(CHUNK_DATA_ID);
		}
	}
	
	//Inner Classes
	private static class SaveInfo extends LuaSaveInfo {

		protected SaveInfo(int slot) {
			super(slot);
		}

		@Override
		protected IScreenshot decodeScreenshot(ByteBuffer buf, Dim maxSize) {
			return new JpegDecodingScreenshot(buf, 1);
		}
		
	}
}

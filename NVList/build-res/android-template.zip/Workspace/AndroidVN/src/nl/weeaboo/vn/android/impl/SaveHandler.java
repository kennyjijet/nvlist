package nl.weeaboo.vn.android.impl;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectStreamException;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

import nl.weeaboo.android.ResourceManager;
import nl.weeaboo.android.gl.Screenshot;
import nl.weeaboo.io.EnvironmentSerializable;
import nl.weeaboo.lua2.io.LuaSerializable;
import nl.weeaboo.lua2.io.ObjectSerializer;
import nl.weeaboo.lua2.io.ObjectSerializer.PackageLimit;
import nl.weeaboo.vn.INotifier;
import nl.weeaboo.vn.IScreenshot;
import nl.weeaboo.vn.impl.lua.LuaSaveHandler;
import nl.weeaboo.vn.impl.lua.SaveInfo;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.util.Log;

@LuaSerializable
public class SaveHandler extends LuaSaveHandler {

	private static final String TAG = "SaveHandler";
	
	private static final String pathPrefix = "save/";
	private final ResourceManager rm;
	private final INotifier notifier;
	
	private final EnvironmentSerializable es;
	
	public SaveHandler(ResourceManager rm, INotifier n, PackageLimit pl) {
		super(1);
		
		this.rm = rm;
		this.notifier = n;
		setPackageLimit(pl);
		
		es = new EnvironmentSerializable(this);
	}
	
	//Functions
	private Object writeReplace() throws ObjectStreamException {	
		return es.writeReplace();
	}
	
	@Override
	public void delete(int slot) throws IOException {
		if (!rm.delete(getFilename(slot))) {
			if (getSaveExists(slot)) {
				throw new IOException("Deletion of slot " + slot + " failed");
			}
		}
	}
	
	@Override
	protected byte[] encodeScreenshot(IScreenshot ss) {
		if (ss == null || ss.isCancelled() || !ss.isAvailable()) {
			return new byte[0];
		}
		
		ByteArrayOutputStream bout = new ByteArrayOutputStream(16<<10);
		Bitmap bitmap;
		if (ss instanceof Screenshot) {
			bitmap = ((Screenshot)ss).toBitmap();
		} else {
			bitmap = Bitmap.createBitmap(ss.getARGB(), ss.getWidth(), ss.getHeight(),
					Bitmap.Config.RGB_565);
		}
		bitmap.compress(CompressFormat.JPEG, 80, bout);
		bitmap.recycle();
		return bout.toByteArray();
	}
	
	@Override
	protected IScreenshot decodeScreenshot(ByteBuffer buf) {
		return new JpegDecodingScreenshot(buf, 1);
	}
	
	//Getters
	protected String getFilename(int slot) {
		return String.format("%ssave-%03d.sav", pathPrefix, slot);		
	}
	
	protected int getSlot(String filename) {
		if (filename.endsWith(".sav")) {
			int index = filename.lastIndexOf('-');
			String part = filename.substring(index+1, filename.length()-4);
			if (part.length() == 3 || (part.length() > 0 && part.charAt(0) != '0')) {
				try {
					return Integer.parseInt(part);
				} catch (NumberFormatException nfe) {
					//Ignore
				}
			}			
		}
		return 0;
	}
	
	@Override
	public boolean getSaveExists(int slot) {
		return rm.getFileExists(getFilename(slot));
	}

	@Override
	public SaveInfo[] getSaves(int start, int end) {
		List<SaveInfo> result = new ArrayList<SaveInfo>();

		Collection<String> existingFiles;
		try {
			existingFiles = rm.getWriteFolderContents(pathPrefix, false);
		} catch (IOException ioe) {
			Log.w(TAG, "Error getting file list", ioe);
			existingFiles = Collections.emptySet();
		}
		
		for (String filename : existingFiles) {
			int slot = getSlot(filename);
			if (slot >= start && slot < end) {
				try {
					SaveInfo si = loadSaveInfo(slot);
					result.add(si);
				} catch (IOException e) {
					Log.w(TAG, "Unreadable save slot: " + filename, e);
					rm.delete(filename);
					//rm.delete(filename+".bak");
					//rm.rename(filename, filename+".bak");
				}
			}
		}
		return result.toArray(new SaveInfo[result.size()]);
	}
	
	@Override
	protected InputStream openSaveInputStream(int slot) throws IOException {
		return rm.getInputStream(getFilename(slot));
	}

	@Override
	protected OutputStream openSaveOutputStream(int slot) throws IOException {
		String filename = getFilename(slot);
		rm.delete(filename + ".bak");
		return rm.getOutputStream(filename);
	}

	@Override
	protected void onSaveWarnings(String[] warnings) {
		notifier.w(ObjectSerializer.toErrorString(Arrays.asList(warnings)));
	}
	
	public void setQuicksave(boolean qs) {
		if (qs) {
			chunkSaveIgnoreList.add(CHUNK_DATA_ID);
		} else {
			chunkSaveIgnoreList.remove(CHUNK_DATA_ID);
		}
	}
	
}

package nl.weeaboo.vn.android.impl;

import java.io.Serializable;

import nl.weeaboo.lua2.io.LuaSerializable;
import nl.weeaboo.vn.impl.base.BaseStorage;

@LuaSerializable
public class Globals extends BaseStorage implements Serializable {

	private static final long serialVersionUID = 1L;

	public Globals() {
	}
	
	//Functions
		
	//Getters
	
	//Setters
	
}

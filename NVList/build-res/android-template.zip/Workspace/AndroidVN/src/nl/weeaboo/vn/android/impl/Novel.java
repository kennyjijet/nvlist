package nl.weeaboo.vn.android.impl;

import static org.luaj.vm2.LuaValue.valueOf;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Field;

import nl.weeaboo.filemanager.FileManager;
import nl.weeaboo.lua2.LuaException;
import nl.weeaboo.lua2.LuaRunState;
import nl.weeaboo.lua2.io.LuaSerializable;
import nl.weeaboo.vn.IAnalytics;
import nl.weeaboo.vn.IImageState;
import nl.weeaboo.vn.IInput;
import nl.weeaboo.vn.INovelConfig;
import nl.weeaboo.vn.IPersistentStorage;
import nl.weeaboo.vn.ISeenLog;
import nl.weeaboo.vn.ISoundState;
import nl.weeaboo.vn.IStorage;
import nl.weeaboo.vn.ITextState;
import nl.weeaboo.vn.ITimer;
import nl.weeaboo.vn.IVideoState;
import nl.weeaboo.vn.impl.base.BaseGUIFactory;
import nl.weeaboo.vn.impl.lua.AbstractKeyCodeMetaFunction;
import nl.weeaboo.vn.impl.lua.LuaMediaPreloader;
import nl.weeaboo.vn.impl.lua.LuaNovel;
import nl.weeaboo.vn.vnds.VNDSUtil;

import org.luaj.vm2.LuaBoolean;
import org.luaj.vm2.LuaFunction;
import org.luaj.vm2.LuaInteger;
import org.luaj.vm2.LuaString;
import org.luaj.vm2.LuaTable;
import org.luaj.vm2.LuaValue;

import android.view.KeyEvent;

public class Novel extends LuaNovel {

	private static final LuaString S_QUICKREAD = valueOf("quickRead");
	
	private transient FileManager fm;
	private transient boolean isVNDS;
	private transient boolean isSuperSkip;
	private transient boolean handlingScriptError;
	
	// !!WARNING!! Do not add properties without adding code for saving/loading
	
	public Novel(INovelConfig nc, ImageFactory imgfac, IImageState is, ImageFxLib imgfxlib,
			SoundFactory sndfac, ISoundState ss, VideoFactory vf, IVideoState vs, BaseGUIFactory gf,
			ITextState ts, Notifier n, IInput in, SystemLib syslib, SaveHandler sh, ScriptLib scrlib,
			TweenLib tl, IPersistentStorage sharedGlobals, IStorage globals, ISeenLog seenLog,
			IAnalytics an, ITimer tmr,
			FileManager fm, boolean isVNDS)
	{
		super(nc, imgfac, is, imgfxlib, sndfac, ss, vf, vs, gf, ts, n, in, syslib, sh, scrlib,
				tl, sharedGlobals, globals, seenLog, an, tmr);
		
		this.fm = fm;
		this.isVNDS = isVNDS;
		
		//Disable preloader
		getPreloader().setLookAhead(0);
	}
	
	//Functions
	@Override
	public void reset() {
		isSuperSkip = false;
		
		super.reset();
	}
	
	@Override
	protected void initPreloader(LuaMediaPreloader preloader) {
		preloader.clear();
		try {
			try {
				InputStream in = fm.getInputStream("preloader-default.bin");
				try {
					preloader.load(in);
				} finally {
					in.close();
				}
			} catch (FileNotFoundException fnfe) {
				//Ignore
			}
			
			try {
				InputStream in = fm.getInputStream("preloader.bin");
				try {
					preloader.load(in);
				} finally {
					in.close();
				}
			} catch (FileNotFoundException fnfe) {
				//Ignore
			}
		} catch (IOException ioe) {
			getNotifier().d("Error initializing preloader", ioe);
		}
	}
	
	@Override
	public void initLuaRunState() {
		LuaRunState lrs = getLuaRunState();
		LuaValue globals = lrs.getGlobalEnvironment();
		try {
			//Register globals
			globals.rawset("android", LuaBoolean.TRUE);
			
			//Register types

			//Register libraries
			if (isVNDS) registerVNDSLib();
		} catch (LuaException e) {
			onScriptError(e);
		}		

		super.initLuaRunState();
	}

	@Override
	protected boolean updateScript(IInput input) {
		boolean result = super.updateScript(input);
		
		if (result) {
			LuaTable globals = getLuaRunState().getGlobalEnvironment();
			//System.out.println(isSuperSkip + " " + Arrays.toString(globals.keys()));
			if (!globals.get(S_QUICKREAD).toboolean()) {
				isSuperSkip = false;
			}
		}
		
		return result;
	}
	
	@Override
	public void onScriptError(Exception e) {
		if (handlingScriptError) {
			return;
		}
		
		handlingScriptError = true;
		try {
			ITextState ts = getTextState();
			if (ts != null) {
				ts.setText(String.format("\\x1b[31;1m%s\\x1b[0m", e.toString()));			
			}
			
			getNotifier().e("Script Error", e);		
			
			setWait(60);
			setWaitClick(true);
		} finally {
			handlingScriptError = false;			
		}
	}

	@Override
	protected void addKeyCodeConstants(final LuaTable table) throws LuaException {
		addKeyCodeConstants(table, new KeyCodeMetaFunction(table));
	}
	
	@Override
	protected void addKeyCodeConstants(LuaTable table, LuaFunction meta) throws LuaException {
		super.addKeyCodeConstants(table, meta);
		
		table.rawset("LEFT",  KeyEvent.KEYCODE_DPAD_LEFT);
		table.rawset("RIGHT", KeyEvent.KEYCODE_DPAD_RIGHT);
		table.rawset("UP",    KeyEvent.KEYCODE_DPAD_UP);
		table.rawset("DOWN",  KeyEvent.KEYCODE_DPAD_DOWN);
	}
	
	public void superSkip() {
		VNDSUtil.superSkip(this);
		isSuperSkip = true;
	}
	
	//Getters
	@Override
	public SoundFactory getSoundFactory() {
		return (SoundFactory)super.getSoundFactory();
	}

	public boolean isSuperSkip() {
		return isSuperSkip;
	}
	
	//Setters
	
	//Inner classes
	@LuaSerializable
	private static class KeyCodeMetaFunction extends AbstractKeyCodeMetaFunction {

		private static final long serialVersionUID = 1L;
		
		public KeyCodeMetaFunction(LuaTable t) {
			super(t);
		}

		@Override
		protected LuaValue getKeyCode(String name) {
			try {
				Field field = KeyEvent.class.getField("KEYCODE_" + name);
				return LuaInteger.valueOf((Integer)field.get(null));
			} catch (NoSuchFieldException nsfe) {
				//Ignore
			} catch (IllegalArgumentException e) {
				//Ignore
			} catch (IllegalAccessException e) {
				//Ignore
			}
			return null;
		}
		
	}
	
}

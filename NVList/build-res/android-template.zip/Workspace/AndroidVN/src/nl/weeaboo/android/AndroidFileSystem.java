package nl.weeaboo.android;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Collection;

import nl.weeaboo.filesystem.ArchiveFileSystem;
import nl.weeaboo.filesystem.IFileSystem;
import nl.weeaboo.filesystem.LocalFileSystem;
import nl.weeaboo.filesystem.MultiFileSystem;
import nl.weeaboo.zip.FileRecord;
import nl.weeaboo.zip.FilterFileArchive;
import nl.weeaboo.zip.IFileArchive;
import nl.weeaboo.zip.ZipArchive;

public class AndroidFileSystem extends MultiFileSystem {

	private final File cacheFolder;
	
	public AndroidFileSystem(Collection<IFileSystem> fs, File cacheFolder) {
		super(fs);
		
		this.cacheFolder = cacheFolder;
	}
	
	public FileSegment getFileSegment(String path) throws IOException {
		for (IFileSystem fs : fileSystems) {
			if (!fs.getFileExists(path)) {
				continue;
			}
			
			if (fs instanceof LocalFileSystem) {
				LocalFileSystem lfs = (LocalFileSystem)fs;				
				return FileSegment.fromFile(lfs.getFile(path));
			} else if (fs instanceof ArchiveFileSystem) {
				IFileArchive arc = ((ArchiveFileSystem)fs).getBackingArchive();
				
				//Unwrap FilterFileArchives until we find the root
				while (arc instanceof FilterFileArchive) {
					arc = ((FilterFileArchive)arc).getInner();
				}
				
				//Regular File-backed ZIP file
				if (arc instanceof ZipArchive) {
					ZipArchive zip = (ZipArchive)arc;
					FileRecord r = zip.get(path);
					if (r != null && zip.getFile() != null) {
						return FileSegment.fromFile(zip.getFile(), r.offset, r.compressedLength);
					}
				}
				
				//Asset-backed archive
				if (arc instanceof AssetZipArchive) {
					AssetZipArchive azip = (AssetZipArchive)arc;
					FileRecord r = azip.get(path);
					if (r != null && azip.getAssets() != null) {
						String fn = r.getFilename();
						return FileSegment.fromAsset(azip.getAssets(), fn, null, 0, r.compressedLength);
					}
				}				
			}
		}
				
		throw new FileNotFoundException(path);
	}
	
	public File getCacheFolder() {
		return cacheFolder;
	}
	
}

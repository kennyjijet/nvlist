package nl.weeaboo.vn.android.impl;

import java.io.ObjectStreamException;

import nl.weeaboo.android.vn.AndroidVN;
import nl.weeaboo.android.vn.Game;
import nl.weeaboo.io.EnvironmentSerializable;
import nl.weeaboo.lua2.LuaException;
import nl.weeaboo.lua2.io.LuaSerializable;
import nl.weeaboo.vn.impl.base.BaseSystemLib;
import nl.weeaboo.vn.impl.lua.LuaNovel;
import android.content.Intent;
import android.net.Uri;
import android.os.Handler;

@LuaSerializable
public class SystemLib extends BaseSystemLib {

	private final AndroidVN context;
	private final Game game;
	private final Handler guiHandler;
	private final boolean isTouchScreen;
	private final boolean isLowEnd;
	private final EnvironmentSerializable es;
	
	private boolean textFullscreen;
	
	public SystemLib(AndroidVN ctxt, Game game, Handler h, boolean isLowEnd) {
		this.context = ctxt;
		this.game = game;
		this.guiHandler = h;
		
		//Assume Android devices are (or act like) touchscreen devices.
		this.isTouchScreen = true;
		this.isLowEnd = isLowEnd;		
		
		this.es = new EnvironmentSerializable(this);
	}

	//Functions
	private Object writeReplace() throws ObjectStreamException {	
		return es.writeReplace();
	}
		
	@Override
	public void exit(boolean force) {
		game.nativeStop(force);
	}

	@Override
	public void softExit() throws LuaException {
		LuaNovel novel = game.getNovel();
		novel.onExit();
	}
	
	@Override
	public void restart() {
		guiHandler.post(new Runnable() {
			@Override
			public void run() {
				synchronized (game) {
					game.restart();
				}
			}
		});
	}

	@Override
	public void openWebsite(final String url) {
		guiHandler.post(new Runnable() {
			@Override
			public void run() {
				Intent i = new Intent(Intent.ACTION_VIEW);
				i.setData(Uri.parse(url));
				if (i.resolveActivity(context.getPackageManager()) != null) {
					context.startActivity(i);
				}
			}
		});		
	}
	
	//Getters
	@Override
	public boolean canExit() {
		return true;
	}
		
	@Override
	public boolean isTouchScreen() {
		return isTouchScreen;
	}

	@Override
	public boolean isLowEnd() {
		return isLowEnd;
	}
	
	public boolean isTextFullscreen() {
		return textFullscreen;
	}
	
	//Setters
	@Override
	public void setTextFullscreen(boolean fullscreen) {
		textFullscreen = fullscreen;
	}
	
}

package nl.weeaboo.vn.android.impl;

import java.io.ObjectStreamException;
import java.io.Serializable;

import nl.weeaboo.android.vn.AndroidVN;
import nl.weeaboo.android.vn.Game;
import nl.weeaboo.io.EnvironmentSerializable;
import nl.weeaboo.lua2.io.LuaSerializable;
import nl.weeaboo.vn.IChoice;
import nl.weeaboo.vn.ISaveLoadScreen;
import nl.weeaboo.vn.impl.base.BaseSystemLib;
import android.content.Intent;
import android.net.Uri;
import android.os.Handler;
import android.view.Display;

@LuaSerializable
public class SystemLib extends BaseSystemLib {

	private final AndroidVN context;
	private final Game game;
	private final Handler guiHandler;
	private final boolean isTouchScreen;
	private final boolean isLowEnd;
	private final EnvironmentSerializable es;
	
	private boolean textFullscreen;
	
	public SystemLib(AndroidVN ctxt, Game game, Handler h) {
		this.context = ctxt;
		this.game = game;
		this.guiHandler = h;
		
		//No way to query, and we currently don't support changing the touchscreen flag at runtime
		this.isTouchScreen = true;
		
		//Assume low-res screen devices to also have slow processors
		Display display = ctxt.getWindowManager().getDefaultDisplay();
		this.isLowEnd = Math.max(display.getWidth(), display.getHeight()) <= 480;
		
		this.es = new EnvironmentSerializable(this);
	}

	//Functions
	private Object writeReplace() throws ObjectStreamException {	
		return es.writeReplace();
	}
		
	@Override
	public void exit(boolean force) {
		guiHandler.post(new Runnable() {
			public void run() {
				context.askQuit();
			}
		});
	}

	@Override
	public IChoice createChoice(String... options) {
		return new ChoiceView(context, guiHandler, options);
	}

	@Override
	public ISaveLoadScreen createSaveScreen() {
		context.openSaveScreen();
		return new SaveLoadScreen(true);
	}

	@Override
	public ISaveLoadScreen createLoadScreen() {
		context.openLoadScreen();
		return new SaveLoadScreen(false);
	}

	@Override
	public void restart() {
		guiHandler.post(new Runnable() {
			@Override
			public void run() {
				synchronized (game) {
					game.restart();
				}
			}
		});
	}

	@Override
	public void openWebsite(final String url) {
		guiHandler.post(new Runnable() {
			@Override
			public void run() {
				Intent i = new Intent(Intent.ACTION_VIEW);
				i.setData(Uri.parse(url));
				context.startActivity(i);
			}
		});		
	}
	
	//Getters
	@Override
	public boolean canExit() {
		return true;
	}
	
	@Override
	public boolean isTouchScreen() {
		return isTouchScreen;
	}

	@Override
	public boolean isLowEnd() {
		return isLowEnd;
	}
	
	public boolean isTextFullscreen() {
		return textFullscreen;
	}
	
	//Setters
	@Override
	public void setTextFullscreen(boolean fullscreen) {
		textFullscreen = fullscreen;
	}

	//Inner Classes
	@LuaSerializable
	private static class SaveLoadScreen implements ISaveLoadScreen, Serializable {
		
		private static final long serialVersionUID = 7750032018427801944L;
		
		public SaveLoadScreen(boolean isSave) {
		}

		@Override
		public boolean isFinished() {
			// The activity is paused while the save/load screen is active, when
			// we get to execute code again the save/load screen must've been
			// closed.
			return true;
		}
	}
	
}

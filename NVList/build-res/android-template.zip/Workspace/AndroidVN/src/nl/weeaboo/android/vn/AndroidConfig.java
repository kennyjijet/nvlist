package nl.weeaboo.android.vn;

import static nl.weeaboo.settings.Preference.*;
import static nl.weeaboo.vn.NovelPrefs.*;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import nl.weeaboo.filemanager.FileManager;
import nl.weeaboo.settings.BaseConfig;
import nl.weeaboo.settings.INIFile;
import nl.weeaboo.settings.Preference;
import nl.weeaboo.vn.ErrorLevel;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.content.res.Resources;
import android.preference.PreferenceManager;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;

public class AndroidConfig extends BaseConfig {

	private static final String TAG = "AndroidConfig";
	public static final String CONSTANTS_FILENAME = "game.ini";
	public static final String VARIABLES_INIT_FILENAME = "prefs-default.ini";
	
	public static final Preference<Integer> PREFERRED_ORIENTATION = newPreference("android.preferredOrientation", -1, "", "");
	public static final Preference<Integer> ACTION_BAR_ALGORITHM = newPreference("android.actionBarAlgorithm", -1, "", "");
	public static final Preference<Double> TEXT_SIZE = newPreference("android.textSize", .8, "", "");
	public static final Preference<Boolean> USE_EMBEDDED_FONTS = newPreference("android.useEmbeddedFonts", true, "", "");
	public static final Preference<Integer> MIN_TOUCH_DELAY = newPreference("android.minTouchDelay", 100, "", "");
	public static final Preference<Boolean> SHOW_CLOCK = newPreference("android.showClock", false, "", "");
	public static final Preference<Integer> RENDER_ANCHOR = newPreference("android.renderAnchor", 5, "", "");
	public static final Preference<Integer> TEXTBOX_ANCHOR = newPreference("android.textboxAnchor", 2, "", "");
	public static final Preference<Integer> TEXTBOX_ALPHA = newPreference("android.textboxAlpha", 160, "", "");
	public static final Preference<ErrorLevel> ERROR_LEVEL = newPreference("android.errorLevel", ErrorLevel.class, ErrorLevel.WARNING, "", "");
	public static final Preference<SaveMode> SAVE_MODE = newPreference("android.saveMode", SaveMode.class, SaveMode.full, "", "");
	
	private FileManager fm;
	
	public AndroidConfig(FileManager fm) {
		this.fm = fm;
	}

	private void initProperties(Set<Entry<String, String>> entries, boolean constants) {
		for (Entry<String, String> entry : entries) {
			String key = entry.getKey();
			String val = entry.getValue();
			
			Var var = map.get(key);
			if (var != null && var.isConstant() && !constants) {
				if (!var.getRaw().equals(val)) {
					Log.w(TAG, "Almost overwrote a constant with a variable while loading config, maybe you're accidentally using the same name for two different properties? :: " + key + " -> " + val);
				}
			} else {
				map.put(key, new Var(constants, val));
			}
		}		
	}
	
	@Override
	public void init(Map<String, String> overrides) throws IOException {
		load(CONSTANTS_FILENAME, true);
		loadVariables();
		if (overrides != null) {
			initProperties(overrides.entrySet(), false);
		}
	}

	private void load(String filename, boolean constants) throws IOException {
		try {
			InputStream in = fm.getInputStream(filename);
			try {
				INIFile iniFile = new INIFile();
				iniFile.read(new BufferedReader(new InputStreamReader(in, "UTF-8"), 4096));
				initProperties(iniFile.entrySet(), constants);
			} finally {
				in.close();
			}			
		} catch (FileNotFoundException fnfe) {
			//Ignore, config files are allowed to be absent
			Log.v(TAG, "Config file \"" + filename + "\" doesn't exist");
		}		
	}
	
	@Override
	public void loadVariables() throws IOException {
		load(VARIABLES_INIT_FILENAME, false);
	}

	public void loadAndroid(AndroidVN context) {
		Resources res = context.getResources();
		SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(context);				        		
		
		Display display = context.getWindowManager().getDefaultDisplay();
		DisplayMetrics metrics = new DisplayMetrics();
		display.getMetrics(metrics);
		
		set(PREFERRED_ORIENTATION, getStringAsInt(prefs, res, R.string.pref_orientation, ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED));
		set(ACTION_BAR_ALGORITHM, getStringAsInt(prefs, res, R.string.pref_soft_menu, -1));	
		set(TEXT_SIZE, .1 * getInt(prefs, res, R.string.pref_text_size, 8));
		set(USE_EMBEDDED_FONTS, getBoolean(prefs, res, R.string.pref_embedded_fonts, true));
		set(AUTO_READ_WAIT, getInt(prefs, res, R.string.pref_autoread_wait, 1000));
		set(MIN_TOUCH_DELAY, getInt(prefs, res, R.string.pref_doubleclick, 100));
		set(EFFECT_SPEED, getStringAsDouble(prefs, res, R.string.pref_effect_speed, 1.0));				
		set(SHOW_CLOCK, getBoolean(prefs, res, R.string.pref_show_clock, false));
		set(RENDER_ANCHOR, getStringAsInt(prefs, res, R.string.pref_render_anchor, 5));
		set(TEXTBOX_ANCHOR, getStringAsInt(prefs, res, R.string.pref_textbox_anchor, 2));
		set(TEXTBOX_ALPHA, getInt(prefs, res, R.string.pref_textbox_alpha, 160));
		set(SOUND_VOLUME, .01 * getInt(prefs, res, R.string.pref_sound_volume, 80));
		set(MUSIC_VOLUME, .01 * getInt(prefs, res, R.string.pref_music_volume, 50));
		set(VOICE_VOLUME, .01 * getInt(prefs, res, R.string.pref_voice_volume, 100));
		
		double textSpeed = 1.0;
		if (Math.min(metrics.widthPixels, metrics.heightPixels) <= 320) {
			textSpeed = 999999.0;
		}
		set(TEXT_SPEED, 0.5 * getStringAsDouble(prefs, res, R.string.pref_text_speed, textSpeed));
		
		
		ErrorLevel errorLevel = null;
		try {
			errorLevel = ErrorLevel.fromString(getString(prefs, res, R.string.pref_error_level, "warning"));
		} catch (IllegalArgumentException iae) { }
		errorLevel = ErrorLevel.WARNING;
		set(ERROR_LEVEL, errorLevel);
		
		SaveMode saveMode = null;
		try {
			saveMode = SaveMode.valueOf(getString(prefs, res, R.string.pref_savemode, ""));
		} catch (IllegalArgumentException iae) { }
		if (saveMode == null) saveMode = SaveMode.full;
		set(SAVE_MODE, saveMode);
	}

	private static String getString(SharedPreferences prefs, Resources res, int nameId, String defaultVal) {
		return prefs.getString(res.getString(nameId), defaultVal);
	}
	
	private static int getInt(SharedPreferences prefs, Resources res, int nameId, int defaultVal) {
		return prefs.getInt(res.getString(nameId), defaultVal);
	}
	
	private static boolean getBoolean(SharedPreferences prefs, Resources res, int nameId, boolean defaultVal) {
		return prefs.getBoolean(res.getString(nameId), defaultVal);
	}
	
	private static int getStringAsInt(SharedPreferences prefs, Resources res, int nameId, int defaultVal) {
		String raw = prefs.getString(res.getString(nameId), "");
		try {
			return Integer.parseInt(raw);
		} catch (NumberFormatException nfe) {
			return defaultVal;
		}
	}
	
	private static double getStringAsDouble(SharedPreferences prefs, Resources res, int nameId, double defaultVal) {
		String raw = prefs.getString(res.getString(nameId), "");
		try {
			return Double.parseDouble(raw);
		} catch (NumberFormatException nfe) {
			return defaultVal;
		}
	}
	
	@Override
	public void saveVariables() throws IOException {
		throw new RuntimeException("Not implemented");
	}
	
}

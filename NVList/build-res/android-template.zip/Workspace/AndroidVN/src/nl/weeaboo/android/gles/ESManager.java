package nl.weeaboo.android.gles;

import static javax.microedition.khronos.opengles.GL10.GL_EXTENSIONS;
import static javax.microedition.khronos.opengles.GL10.GL_MAX_TEXTURE_SIZE;
import static javax.microedition.khronos.opengles.GL10.GL_RENDERER;
import static javax.microedition.khronos.opengles.GL10.GL_RGBA;
import static javax.microedition.khronos.opengles.GL10.GL_UNSIGNED_BYTE;
import static javax.microedition.khronos.opengles.GL10.GL_VERSION;

import java.nio.Buffer;
import java.util.HashSet;
import java.util.Set;

import android.opengl.Matrix;

import nl.weeaboo.gl.AbstractGLManager;
import nl.weeaboo.gl.GLDraw;
import nl.weeaboo.gl.GLInfo;
import nl.weeaboo.gl.GLInfo.CapsBuilder;
import nl.weeaboo.gl.GLResCache;

public abstract class ESManager<G> extends AbstractGLManager<G> {
	
	private final float[] projectionMatrix;
	
	public ESManager(Class<? extends G> glClass, GLDraw draw, GLResCache resCache) {
		super(glClass, new GLInfo(), draw, resCache);

		this.projectionMatrix = new float[16];
		int w = 800, h = 600; //Shouldn't matter unless I don't properly set the matrix later
		Matrix.orthoM(projectionMatrix, 0, 0f, w, 0f, h, 0f, 1f);
	}

	//Functions
	@Override
	protected void initGLCaps(G gl, CapsBuilder b) {
		Set<String> exts = new HashSet<String>();			
		for (String ext : glOptString(GL_EXTENSIONS, "").split(" ")) {
			exts.add(ext);
		}
		
		b.glVersion = glOptString(GL_VERSION, "");		
		b.renderer = glOptString(GL_RENDERER, "");
		b.isDesktopGL = false;
		b.texNPOTSupported = exts.contains("GL_IMG_texture_npot")
				|| exts.contains("GL_OES_texture_npot")
				|| exts.contains("GL_ARB_texture_non_power_of_two");
		b.pboSupported = false;
		b.fboSupported = false;
		b.generateMipmapSupported = false;
		b.autoGenerateMipmapSupported = false;
		b.drawTexSupported = exts.contains("GL_OES_draw_texture");
		
		b.defaultPixelFormatARGB = GL_RGBA;
		b.defaultPixelTypeARGB = GL_UNSIGNED_BYTE;
		
		int glMaxTextureSize = glGetInteger(GL_MAX_TEXTURE_SIZE);
		if (glMaxTextureSize > 0) {
			b.maxTextureSize = glMaxTextureSize;
		}		
		b.extensions = exts;
	}
	
	protected abstract String glOptString(int glIdentifier, String defaultVal);
	protected abstract int glGetInteger(int glIdentifier);
	protected abstract void glTexParameterf(int target, int pname, float value);
	
	//Getters
	public G getGL() {
		return gl;
	}
	
	public abstract int[] getRenderTargetBits();
	
	public abstract void glReadPixels(int x, int y, int w, int h, int fmt, int type, Buffer buf);
	
	public float[] getProjectionMatrix() {
		return projectionMatrix;
	}
	
	//Setters
	@Override
	public void setSwapInterval(int i) {
		//Not implemented
	}

	public void initProjection(int w, int h) {
		Matrix.orthoM(projectionMatrix, 0, 0f, w, 0f, h, 0f, 1f);
	}
	
}

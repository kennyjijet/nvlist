package nl.weeaboo.vn.android.impl;

import java.io.IOException;
import java.io.ObjectStreamException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import nl.weeaboo.android.gles.ESTextureData;
import nl.weeaboo.android.gles.ESTextureStore;
import nl.weeaboo.android.gui.FontManager;
import nl.weeaboo.android.vn.AndroidConfig;
import nl.weeaboo.common.Dim;
import nl.weeaboo.gl.GLInfo;
import nl.weeaboo.gl.tex.GLTexRect;
import nl.weeaboo.gl.tex.GLTexture;
import nl.weeaboo.gl.tex.GLWritableTexture;
import nl.weeaboo.io.EnvironmentSerializable;
import nl.weeaboo.lua2.io.LuaSerializable;
import nl.weeaboo.styledtext.MutableTextStyle;
import nl.weeaboo.styledtext.TextAttribute;
import nl.weeaboo.styledtext.TextStyle;
import nl.weeaboo.vn.IButtonDrawable;
import nl.weeaboo.vn.INotifier;
import nl.weeaboo.vn.IScreenshot;
import nl.weeaboo.vn.ISeenLog;
import nl.weeaboo.vn.ITexture;
import nl.weeaboo.vn.NovelPrefs;
import nl.weeaboo.vn.impl.base.BaseImageFactory;
import android.graphics.Bitmap;

@LuaSerializable
public class ImageFactory extends BaseImageFactory implements Serializable {

	private final FontManager fm;
	private final ESTextureStore texStore;
	private final AndroidConfig config;
	
	private int imgWidth, imgHeight;
	
	private final EnvironmentSerializable es;
	
	public ImageFactory(FontManager fm, ESTextureStore ts, ISeenLog sl, INotifier ntf,
			AndroidConfig config, int w, int h)
	{
		super(sl, ntf, w, h);
		
		this.fm = fm;
		this.texStore = ts;
		this.config = config;

		this.imgWidth = w;
		this.imgHeight = h;
		
		this.es = new EnvironmentSerializable(this);
	}
	
	//Functions
	private Object writeReplace() throws ObjectStreamException {	
		return es.writeReplace();
	}
	
	@Override
	public void preloadNormalized(String filename) {
		texStore.preload(filename, false);
	}
	
	@Override
	public ImageDrawable createImageDrawable() {
		return new ImageDrawable();
	}

	protected TextureTR createTextRenderer() {
		return new TextureTR(this);
	}
	
	@Override
	public TextDrawable createTextDrawable() {
		return new TextDrawable(createTextRenderer());
	}

	@Override
	public IButtonDrawable createButtonDrawable() {
		return new ButtonDrawable(createTextRenderer());
	}
	
	@Override
	public IScreenshot screenshot(short z, boolean isVolatile) {
		return new Screenshot(z, isVolatile);
	}
	
	public ITexture createTexture(GLTexture tex, double sx, double sy) {
		return createTexture(tex != null ? tex.getSubRect(null) : null, sx, sy);
	}

	public ITexture createTexture(GLTexRect tr, double sx, double sy) {
		if (tr == null) {
			return null;
		}

		TextureAdapter ta = new TextureAdapter(this);
		ta.setTexRect(tr, sx, sy);
		//System.out.println(ta.getWidth()+"x"+ta.getHeight() + " " + tr.getRect() + " " + tr.getUV() + " " + tr.getTexture().getTexWidth()+"x"+tr.getTexture().getTexHeight());
		return ta;
	}
	
	@Override
	public ITexture createTexture(int[] argb, int w, int h, double sx, double sy) {
		GLWritableTexture tex = texStore.newWritableTexture(w, h, 0, 0, 0, 0);
		if (tex == null) {
			return null;
		}
		
		if (argb != null) {
			tex.setPixels(texStore.newARGB8TextureData(argb, w, h));
		}
		
		TextureAdapter ta = new TextureAdapter(this);
		ta.setTexRect(tex.getSubRect(null), sx, sy);
		return ta;
	}
	
	public ESTextureData createTextureData(Bitmap bitmap, boolean shared) {
		Dim texSize = texStore.toTexSize(bitmap.getWidth(), bitmap.getHeight());
		return ESTextureData.fromBitmap(texStore.getGLInfo(), texSize, bitmap, shared);
	}
	
	//Getters	
	public FontManager getFontManager() {
		return fm;
	}
	
	@Override
	protected ITexture getTextureNormalized(String filename, String normalized, String[] luaStack) {
		GLTexRect tr = getTexRectNormalized(filename, normalized, luaStack);

		//Returning null prevents reloading the image if it's available in a different resolution only
		//if (tr == null) {
		//	return null;
		//}
		
		TextureAdapter ta = new ImageTextureAdapter(this, normalized);
		double scale = getImageScale(normalized);
		ta.setTexRect(tr, scale, scale);
		return ta;
	}

	public GLTexRect getTexRect(String filename, String[] luaStack) {
		return getTexRectNormalized(filename, normalizeFilename(filename), luaStack);
	}
	
	protected GLTexRect getTexRectNormalized(String filename, String normalized, String[] luaStack) {
		if (normalized == null) {
			return null;
		}		
		return texStore.getTexRect(normalized);
	}
	
	@Override
	protected boolean isValidFilename(String filename) {
		return texStore.isValidTexRect(filename);
	}

	@Override
	protected List<String> getFiles(String folder) {
		List<String> out = new ArrayList<String>();
		try {
			texStore.getFiles(out, folder, true);
		} catch (IOException e) {
			notifier.d("Folder doesn't exist or can't be read: " + folder, e);
		}
		return out;
	}
	
	public boolean isGLExtensionAvailable(String ext) {
		GLInfo glInfo = texStore.getGLInfo();
		return glInfo.isExtensionAvailable(ext);
	}
	
	public double getImageScale(String filename) {
		if (texStore.isAssetImage(filename)) {
			return texStore.getAssetImageScale();
		} else {
			return Math.min(width / (double)imgWidth, height / (double)imgHeight);
		}
	}
	
	public GLInfo getGLInfo() {
		return texStore.getGLInfo();
	}
	
	TextStyle getDefaultStyle() {
		MutableTextStyle style = config.get(NovelPrefs.TEXT_STYLE).mutableCopy();
		style.removeProperty(TextAttribute.fontSize); //Desirable desktop font size has very little to do with desirable Android font size
		return style.immutableCopy();
	}
	
	//Setters
	public void setImageSize(int iw, int ih) {
		imgWidth = iw;
		imgHeight = ih;
	}

}

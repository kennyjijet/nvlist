package nl.weeaboo.vn.android.impl;

import java.io.IOException;
import java.io.ObjectStreamException;
import java.io.Serializable;
import java.util.Collection;
import java.util.Collections;

import nl.weeaboo.android.gl.GLDraw;
import nl.weeaboo.android.gl.GLTexture;
import nl.weeaboo.android.gl.Screenshot;
import nl.weeaboo.android.gl.TextureCache;
import nl.weeaboo.android.gui.FontManager;
import nl.weeaboo.android.vn.AndroidConfig;
import nl.weeaboo.io.EnvironmentSerializable;
import nl.weeaboo.lua2.io.LuaSerializable;
import nl.weeaboo.styledtext.MutableTextStyle;
import nl.weeaboo.styledtext.TextAttribute;
import nl.weeaboo.styledtext.TextStyle;
import nl.weeaboo.vn.IButtonDrawable;
import nl.weeaboo.vn.INotifier;
import nl.weeaboo.vn.IScreenshot;
import nl.weeaboo.vn.ISeenLog;
import nl.weeaboo.vn.ITexture;
import nl.weeaboo.vn.NovelPrefs;
import nl.weeaboo.vn.impl.base.BaseImageFactory;

@LuaSerializable
public class ImageFactory extends BaseImageFactory implements Serializable {

	private final FontManager fm;
	private final TextureCache texCache;
	private final double displayDensity;
	private final boolean isTouchScreen;
	private final AndroidConfig config;
	
	private double scale;
	private double textScale;
	
	private final EnvironmentSerializable es;
	
	public ImageFactory(FontManager fm, TextureCache tc, ISeenLog sl, INotifier ntf,
			AndroidConfig config, int w, int h, double displayDensity, boolean isTouchScreen)
	{
		super(sl, ntf, w, h);
		
		this.fm = fm;
		this.texCache = tc;
		this.displayDensity = displayDensity;
		this.isTouchScreen = isTouchScreen;
		this.config = config;
		
		textScale = 1f;

		this.es = new EnvironmentSerializable(this);
	}
	
	//Functions
	private Object writeReplace() throws ObjectStreamException {	
		return es.writeReplace();
	}
	
	@Override
	public void preloadNormalized(String filename) {
		//TODO Implement preload? Don't forget to set the LuaMediaPreloader lookahead to a nonzero value.
	}
	
	@Override
	public ImageDrawable createImageDrawable() {
		return new ImageDrawable();
	}

	@Override
	public TextDrawable createTextDrawable() {
		return new TextDrawable(this, scale, textScale, displayDensity);
	}

	@Override
	public IButtonDrawable createButtonDrawable() {
		return new ButtonDrawable(isTouchScreen);
	}
	
	@Override
	public IScreenshot screenshot(short z) {
		return new Screenshot(z);
	}
	
	@Override
	public ITexture createTexture(int[] argb, int w, int h, double sx, double sy) {
		GLTexture tex = texCache.generateTexture(null, argb, w, h);
		if (tex == null) return null;
		
		return new TextureAdapter(tex.getTexRect(0), null, sx, sy);
	}
	
	@Override
	public ITexture createTexture(IScreenshot ss) {
		GLTexture tex = texCache.generateTexture(null, ss.getWidth(), ss.getHeight());
		if (tex == null) return null;
		
		if (ss instanceof Screenshot) {
			tex.setPixels(null, ((Screenshot)ss).toBitmap());
		} else {
			tex.setPixels(null, ss.getARGB(), ss.getWidth(), ss.getHeight());
		}
		
		//System.out.println(ss.getWidth() + "x" + ss.getHeight() + " " + width + "x" + height
		//		+ " " + width / (double)ss.getScreenWidth() + "x" + height / (double)ss.getScreenHeight());
		
		return new TextureAdapter(tex.getTexRect(0), null,
				width / (float)ss.getScreenWidth(),
				height / (float)ss.getScreenHeight());
	}
	
	//Getters	
	public FontManager getFontManager() {
		return fm;
	}
	
	@Override
	public ITexture getTextureNormalized(String filename, String normalized, String[] callStack) {
		return texCache.get(null, normalized);
	}

	@Override
	protected boolean isValidFilename(String filename) {
		return texCache.getImageFileExists(filename);
	}

	@Override
	protected Collection<String> getFiles(String folder) {
		try {
			return texCache.getImageFiles(folder, true);
		} catch (IOException e) {
			notifier.d("Folder doesn't exist or can't be read: " + folder, e);
		}
		return Collections.emptyList();
	}
	
	public boolean isGLExtensionAvailable(String ext) {
		return GLDraw.isGLExtensionAvailable(ext);
	}
	
	TextStyle getDefaultStyle() {
		MutableTextStyle style = config.get(NovelPrefs.TEXT_STYLE).mutableCopy();
		style.removeProperty(TextAttribute.fontSize); //Desirable desktop font size has very little to do with desirable Android font size
		return style.immutableCopy();
	}
	
	//Setters
	public void setTextScale(double ts) {
		textScale = ts;
	}
	public void setScale(double s) {
		scale = s;
	}
	
}

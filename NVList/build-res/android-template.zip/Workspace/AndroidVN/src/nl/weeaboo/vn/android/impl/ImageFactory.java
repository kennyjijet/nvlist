package nl.weeaboo.vn.android.impl;

import java.io.IOException;
import java.io.ObjectStreamException;
import java.io.Serializable;
import java.util.Collection;
import java.util.Collections;

import nl.weeaboo.android.gl.GLDraw;
import nl.weeaboo.android.gl.GLGeneratedTexture;
import nl.weeaboo.android.gl.GLTexRect;
import nl.weeaboo.android.gl.GLTexture;
import nl.weeaboo.android.gl.Screenshot;
import nl.weeaboo.android.gl.TextureCache;
import nl.weeaboo.android.gui.FontManager;
import nl.weeaboo.android.vn.AndroidConfig;
import nl.weeaboo.io.EnvironmentSerializable;
import nl.weeaboo.lua2.io.LuaSerializable;
import nl.weeaboo.styledtext.MutableTextStyle;
import nl.weeaboo.styledtext.TextAttribute;
import nl.weeaboo.styledtext.TextStyle;
import nl.weeaboo.vn.IButtonDrawable;
import nl.weeaboo.vn.INotifier;
import nl.weeaboo.vn.IScreenshot;
import nl.weeaboo.vn.ISeenLog;
import nl.weeaboo.vn.ITexture;
import nl.weeaboo.vn.NovelPrefs;
import nl.weeaboo.vn.impl.base.BaseImageFactory;

@LuaSerializable
public class ImageFactory extends BaseImageFactory implements Serializable {

	private final FontManager fm;
	private final TextureCache texCache;
	private final AndroidConfig config;
	
	private final EnvironmentSerializable es;
	
	public ImageFactory(FontManager fm, TextureCache tc, ISeenLog sl, INotifier ntf,
			AndroidConfig config, int w, int h)
	{
		super(sl, ntf, w, h);
		
		this.fm = fm;
		this.texCache = tc;
		this.config = config;

		this.es = new EnvironmentSerializable(this);
	}
	
	//Functions
	private Object writeReplace() throws ObjectStreamException {	
		return es.writeReplace();
	}
	
	@Override
	public void preloadNormalized(String filename) {
		//TODO Implement preload? Don't forget to set the LuaMediaPreloader lookahead to a nonzero value.
	}
	
	@Override
	public ImageDrawable createImageDrawable() {
		return new ImageDrawable();
	}

	protected TextureTR createTextRenderer() {
		return new TextureTR(this);
	}
	
	@Override
	public TextDrawable createTextDrawable() {
		return new TextDrawable(createTextRenderer());
	}

	@Override
	public IButtonDrawable createButtonDrawable() {
		return new ButtonDrawable(createTextRenderer());
	}
	
	@Override
	public IScreenshot screenshot(short z) {
		return new Screenshot(z);
	}
	
	public ITexture createTexture(GLTexture tex, double sx, double sy) {
		if (tex == null) {
			return null;
		}
		return createTexture(tex.getTexRect(null), sx, sy);
	}

	public ITexture createTexture(GLTexRect tr, double sx, double sy) {
		if (tr == null) {
			return null;
		}

		TextureAdapter ta = new TextureAdapter(tr, null, sx, sy);
		//System.out.println(ta.getWidth()+"x"+ta.getHeight() + " " + tr.getRect() + " " + tr.getUV() + " " + tr.getTexture().getTexWidth()+"x"+tr.getTexture().getTexHeight());
		return ta;
	}
	
	@Override
	public ITexture createTexture(int[] argb, int w, int h, double sx, double sy) {
		GLTexture tex = texCache.generateTexture(null, argb, w, h);
		if (tex == null) return null;
		
		return new TextureAdapter(tex.getTexRect(0), null, sx, sy);
	}
	
	@Override
	public ITexture createTexture(IScreenshot ss) {
		GLTexture tex = texCache.generateTexture(null, ss.getWidth(), ss.getHeight());
		if (tex == null) return null;
		
		if (ss instanceof Screenshot) {
			tex.setPixels(null, ((Screenshot)ss).toBitmap());
		} else {
			tex.setPixels(null, ss.getARGB(), ss.getWidth(), ss.getHeight());
		}
		
		//System.out.println(ss.getWidth() + "x" + ss.getHeight() + " " + width + "x" + height
		//		+ " " + width / (double)ss.getScreenWidth() + "x" + height / (double)ss.getScreenHeight());
		
		return new TextureAdapter(tex.getTexRect(0), null,
				width / (float)ss.getScreenWidth(),
				height / (float)ss.getScreenHeight());
	}
	
	public GLGeneratedTexture createGLTexture(int[] argb, int w, int h) {	
		return texCache.generateTexture(null, w, h);		
	}
	
	//Getters	
	public FontManager getFontManager() {
		return fm;
	}
	
	@Override
	public ITexture getTextureNormalized(String filename, String normalized, String[] callStack) {
		return texCache.get(null, normalized);
	}

	@Override
	protected boolean isValidFilename(String filename) {
		return texCache.getImageFileExists(filename);
	}

	@Override
	protected Collection<String> getFiles(String folder) {
		try {
			return texCache.getImageFiles(folder, true);
		} catch (IOException e) {
			notifier.d("Folder doesn't exist or can't be read: " + folder, e);
		}
		return Collections.emptyList();
	}
	
	public boolean isGLExtensionAvailable(String ext) {
		return GLDraw.isGLExtensionAvailable(ext);
	}
	
	TextStyle getDefaultStyle() {
		MutableTextStyle style = config.get(NovelPrefs.TEXT_STYLE).mutableCopy();
		style.removeProperty(TextAttribute.fontSize); //Desirable desktop font size has very little to do with desirable Android font size
		return style.immutableCopy();
	}
	
	//Setters
	
}

package nl.weeaboo.vn.android.impl;

import android.view.KeyEvent;
import nl.weeaboo.android.gui.UserInput;
import nl.weeaboo.android.vn.AndroidVN;
import nl.weeaboo.io.EnvironmentSerializable;
import nl.weeaboo.vn.IInput;

public class InputAdapter extends EnvironmentSerializable implements IInput {

	private final UserInput input;
	private double touchDx, touchDy;
	
	public InputAdapter(UserInput i) {
		input = i;
	}
	
	@Override
	public void translate(double dx, double dy) {
		touchDx += dx;
		touchDy += dy;
	}
	
	@Override
	public boolean consumeKey(int keycode) {
		return input.consumeKey(keycode);
	}

	@Override
	public boolean isIdle() {
		return input.isIdle();
	}
	
	@Override
	public boolean isKeyHeld(int keycode, boolean allowConsumedPress) {
		return input.isKeyHeld(keycode, allowConsumedPress);
	}

	@Override
	public long getKeyHeldTime(int keycode, boolean allowConsumedPress) {
		return input.getKeyHeldTime(keycode, allowConsumedPress);
	}
	
	@Override
	public boolean isKeyPressed(int keycode) {
		return input.isKeyPressed(keycode);
	}

	@Override
	public double getMouseX() {
		return input.getTouchX() + touchDx;
	}

	@Override
	public double getMouseY() {
		return input.getTouchY() + touchDy;
	}

	@Override
	public boolean isUpHeld() {
		return input.isKeyHeld(KeyEvent.KEYCODE_DPAD_UP, false);
	}

	@Override
	public boolean isDownHeld() {
		return input.isKeyHeld(KeyEvent.KEYCODE_DPAD_DOWN, false);
	}

	@Override
	public boolean isLeftHeld() {
		return input.isKeyHeld(KeyEvent.KEYCODE_DPAD_LEFT, false);
	}

	@Override
	public boolean isRightHeld() {
		return input.isKeyHeld(KeyEvent.KEYCODE_DPAD_RIGHT, false);
	}

	@Override
	public boolean isQuickRead() {
		if (!AndroidVN.allowQuickRead) return false;
		
		return input.getTouchHeldTime(true) > 1500
			|| input.isKeyHeld(0x0071, false) //Left Ctrl
			|| input.isKeyHeld(0x0072, false) //Right Ctrl
			|| input.getKeyHeldTime(KeyEvent.KEYCODE_DPAD_CENTER, false) > 1500
			|| input.getKeyHeldTime(KeyEvent.KEYCODE_ENTER, false) > 1500;			
	}
	
	@Override
	public boolean isQuickReadAlt() {
		if (!isQuickRead()) return false;
		
		return input.isKeyHeld(KeyEvent.KEYCODE_SHIFT_LEFT, true)
			|| input.isKeyHeld(KeyEvent.KEYCODE_SHIFT_RIGHT, true);
	}
	
	@Override
	public boolean consumeMouse() {
		return input.consumeTouch();
	}

	@Override
	public boolean isMouseHeld(boolean allowConsumedPress) {
		return input.isTouchHeld(allowConsumedPress);
	}

	@Override
	public long getMouseHeldTime(boolean allowConsumedPress) {
		return input.getTouchHeldTime(allowConsumedPress);
	}
	
	@Override
	public boolean isMousePressed() {
		return input.isTouchPressed();
	}

	@Override
	public int getMouseScroll() {
		return 0;
	}
	
	@Override
	public boolean isCancelHeld() {
		return input.isKeyHeld(KeyEvent.KEYCODE_BACK, false);
	}
	
	@Override
	public boolean consumeCancel() {
		return input.consumeKey(KeyEvent.KEYCODE_BACK);
	}

	@Override
	public boolean isConfirmHeld() {
		return input.isTouchHeld(false)
			|| input.isKeyHeld(KeyEvent.KEYCODE_DPAD_CENTER, false)
			|| input.isKeyHeld(KeyEvent.KEYCODE_ENTER, false)
			|| input.isKeyHeld(KeyEvent.KEYCODE_SEARCH, false);
	}
	
	@Override
	public boolean consumeConfirm() {
		return input.consumeTouch()
			|| input.consumeKey(KeyEvent.KEYCODE_DPAD_CENTER)
			|| input.consumeKey(KeyEvent.KEYCODE_ENTER)
			|| input.consumeKey(KeyEvent.KEYCODE_SEARCH);
	}
	
	@Override
	public boolean consumeTextLog() {
		return false; //input.consumeKey(KeyEvent.KEYCODE_DPAD_UP);
	}
	
	@Override
	public boolean consumeTextContinue() {
		return input.consumeTouch()			
			//|| input.consumeKey(KeyEvent.KEYCODE_DPAD_DOWN)
			|| input.consumeKey(KeyEvent.KEYCODE_DPAD_CENTER)
			|| input.consumeKey(KeyEvent.KEYCODE_ENTER)
			|| input.consumeKey(0x00a0); //Numpad Enter
	}

	@Override
	public boolean consumeEffectSkip() {
		return consumeTextContinue();
	}

	@Override
	public boolean consumeViewCG() {
		return input.consumeKey(KeyEvent.KEYCODE_SPACE);
	}
		
	@Override
	public boolean consumeSaveScreen() {
		if (!AndroidVN.allowSaveLoad) return false;

		return input.consumeKey(KeyEvent.KEYCODE_S);
	}

	@Override
	public boolean consumeLoadScreen() {
		if (!AndroidVN.allowSaveLoad) return false;
		
		return input.consumeKey(KeyEvent.KEYCODE_L);
	}
	
	@Override
	public boolean consumeUp() {
		return input.consumeKey(KeyEvent.KEYCODE_DPAD_UP);
	}

	@Override
	public boolean consumeDown() {
		return input.consumeKey(KeyEvent.KEYCODE_DPAD_DOWN);

	}

	@Override
	public boolean consumeLeft() {
		return input.consumeKey(KeyEvent.KEYCODE_DPAD_LEFT);
	}

	@Override
	public boolean consumeRight() {
		return input.consumeKey(KeyEvent.KEYCODE_DPAD_RIGHT);
	}

	@Override
	public boolean isEnabled() {
		return input.isEnabled();
	}

	@Override
	public void setEnabled(boolean e) {
		input.setEnabled(e);
	}
	
}

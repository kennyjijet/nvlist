package nl.weeaboo.vn.android.impl;

import java.io.ObjectStreamException;
import java.io.Serializable;

import nl.weeaboo.android.vn.AndroidVN;
import nl.weeaboo.io.EnvironmentSerializable;
import nl.weeaboo.lua2.io.LuaSerializable;
import nl.weeaboo.vn.IChoice;
import nl.weeaboo.vn.ILayer;
import nl.weeaboo.vn.INotifier;
import nl.weeaboo.vn.IPanel;
import nl.weeaboo.vn.ISaveLoadScreen;
import nl.weeaboo.vn.IViewport;
import nl.weeaboo.vn.impl.base.BaseGUIFactory;
import nl.weeaboo.vn.impl.base.BaseImageFactory;
import android.os.Handler;

public class GUIFactory extends BaseGUIFactory {

	private final AndroidVN context;
	private final Handler guiHandler;
	private final EnvironmentSerializable es;

	public GUIFactory(BaseImageFactory imgfac, INotifier ntf, AndroidVN ctxt, Handler h) {
		super(imgfac, ntf);
		this.context = ctxt;
		this.guiHandler = h;
		
		this.es = new EnvironmentSerializable(this);
	}
	
	private Object writeReplace() throws ObjectStreamException {	
		return es.writeReplace();
	}
		
	
	@Override
	public IChoice createChoice(String... options) {
		return new ChoiceView(context, guiHandler, options);
	}

	@Override
	public ISaveLoadScreen createSaveScreen() {
		context.openSaveScreen();
		return new SaveLoadScreen(true);
	}

	@Override
	public ISaveLoadScreen createLoadScreen() {
		context.openLoadScreen();
		return new SaveLoadScreen(false);
	}

	@Override
	public IPanel createPanel() {
		return new Panel();
	}

	@Override
	public IViewport createViewport(ILayer layer) {
		return new Viewport(layer);
	}
	
	//Inner Classes
	@LuaSerializable
	private static class SaveLoadScreen implements ISaveLoadScreen, Serializable {
		
		private static final long serialVersionUID = 7750032018427801944L;
		
		public SaveLoadScreen(boolean isSave) {
		}

		@Override
		public boolean isFinished() {
			// The activity is paused while the save/load screen is active, when
			// we get to execute code again the save/load screen must've been
			// closed.
			return true;
		}
	}
	
}

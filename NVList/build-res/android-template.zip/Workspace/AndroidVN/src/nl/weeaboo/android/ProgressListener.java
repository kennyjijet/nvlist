package nl.weeaboo.android;

public interface ProgressListener {

	public void onProgress(float frac);
	
}

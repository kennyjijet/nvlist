package nl.weeaboo.android.vn;

import javax.microedition.khronos.opengles.GL;

import nl.weeaboo.vn.IDrawBuffer;
import nl.weeaboo.vn.impl.base.BaseDrawBuffer;

public class DrawBuffer extends BaseDrawBuffer {

	private final GL gl;
	
	public DrawBuffer(AndroidRenderEnv env, GL gl) {
		super(env);
		
		this.gl = gl;
	}
	
	//Functions
	public static DrawBuffer cast(IDrawBuffer buf) {
		if (buf == null) return null;
		if (buf instanceof DrawBuffer) return (DrawBuffer)buf;
		throw new ClassCastException("Supplied draw buffer is of an invalid class: " + buf.getClass() + ", expected: " + DrawBuffer.class);
	}
	
	//Getters
	public GL getGL() {
		return gl;
	}
	
	//Setters
	
}

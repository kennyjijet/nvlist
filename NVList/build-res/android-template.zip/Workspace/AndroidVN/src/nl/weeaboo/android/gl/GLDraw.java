package nl.weeaboo.android.gl;

import static javax.microedition.khronos.opengles.GL10.GL_FLOAT;
import static javax.microedition.khronos.opengles.GL10.GL_MODULATE;
import static javax.microedition.khronos.opengles.GL10.GL_TEXTURE0;
import static javax.microedition.khronos.opengles.GL10.GL_TEXTURE_2D;
import static javax.microedition.khronos.opengles.GL10.GL_TEXTURE_COORD_ARRAY;
import static javax.microedition.khronos.opengles.GL10.GL_TEXTURE_ENV;
import static javax.microedition.khronos.opengles.GL10.GL_TEXTURE_ENV_MODE;
import static javax.microedition.khronos.opengles.GL10.GL_TRIANGLE_STRIP;
import static javax.microedition.khronos.opengles.GL10.GL_UNSIGNED_BYTE;
import static javax.microedition.khronos.opengles.GL10.GL_VERTEX_ARRAY;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;

import javax.microedition.khronos.opengles.GL;
import javax.microedition.khronos.opengles.GL10;
import javax.microedition.khronos.opengles.GL11;
import javax.microedition.khronos.opengles.GL11Ext;

import android.graphics.Bitmap;
import android.util.FloatMath;

public class GLDraw {

	private static GL cur;
	private static String[] glExtensions;
	private static boolean supportsNPOT;
	private static boolean supportsDrawTex;
	
	public static int toPowerOfTwo(int target) {
		int cur;
		for (cur = 16; cur < target; cur <<= 1);
		return cur;
	}
	
	public static boolean isPOT(int w, int h) {
		return toPowerOfTwo(w) == w && toPowerOfTwo(h) == h;
	}
	
	public static Bitmap createCompatibleBitmap(GL gl, int w, int h) {
		return createCompatibleBitmap(gl, w, h, (Bitmap)null);
	}
	public static Bitmap createCompatibleBitmap(GL gl, int w, int h, Bitmap sourceBitmap) {
		return createCompatibleBitmap(gl, w, h, getCompatibleBitmapConfig(sourceBitmap));
	}
	public static Bitmap createCompatibleBitmap(GL gl, int w, int h, Bitmap.Config config) {	
		if (!supportsNPOT(gl)) {
			w = toPowerOfTwo(w);
			h = toPowerOfTwo(h);
		}
		
		if (config == null) {
			config = Bitmap.Config.ARGB_8888;
		}
		
        return Bitmap.createBitmap(w, h, config);
	}
	
	public static Bitmap.Config getCompatibleBitmapConfig(Bitmap bitmap) {
		Bitmap.Config config = null;
		if (bitmap != null) {
			config = bitmap.getConfig();
		}

		if (config == null) {
			config = Bitmap.Config.ARGB_8888;			
		}
		
		return config;
	}
	
	public static Bitmap scaleHalf(Bitmap src) {
		int w = src.getWidth();
		int h = src.getHeight();
		int w2 = w >> 1;
		int h2 = h >> 1;
		if (w <= 1 || h <= 1) {
			//Would require bounds checking, fall back to slow path
			return Bitmap.createScaledBitmap(src, Math.max(1, w2), Math.max(1, h2), true);
		}
		
		Bitmap.Config config = getCompatibleBitmapConfig(src);
		
		int[] argb = new int[w * h];
		src.getPixels(argb, 0, w, 0, 0, w, h);
		
		int s = 0, d = 0;
		for (int y = 0; y < h2; y++) {
			for (int x = 0; x < w2; x++) {
				int c1 = argb[s], c2 = argb[s + 1], c3 = argb[s + w], c4 = argb[s + w + 1];
				int a = ((c1>>>24) + (c2>>>24) + (c3>>>24) + (c4>>>24)) >> 2;
				int r = ((c1 & 0x00FF0000) + (c2 & 0x00FF0000) + (c3 & 0x00FF0000) + (c4 & 0x00FF0000)) >> (16 + 2);
				int g = ((c1 & 0x0000FF00) + (c2 & 0x0000FF00) + (c3 & 0x0000FF00) + (c4 & 0x0000FF00)) >> ( 8 + 2);
				int b = ((c1 & 0x000000FF) + (c2 & 0x000000FF) + (c3 & 0x000000FF) + (c4 & 0x000000FF)) >> ( 0 + 2);
				
				argb[d++] = (a << 24) | (r << 16) | (g << 8) | (b);
				s += 2;
			}
			s += w;
		}

		return Bitmap.createBitmap(argb, w2, h2, config);
	}
		
	protected static void initGLInfo(GL gl) {
		if (cur != gl && gl != null) {
			cur = gl;
			
			GL10 gl10 = (GL10)gl;
			String extensions = gl10.glGetString(GL10.GL_EXTENSIONS);
			
			//Init extensions cache
			glExtensions = (extensions != null ? extensions.split(" ") : new String[0]);
			for (String ext : glExtensions) {
				//System.out.println(ext);				
				if (ext.equals("GL_IMG_texture_npot")
					|| ext.equals("GL_OES_texture_npot")
					|| ext.equals("GL_ARB_texture_non_power_of_two"))
				{
					supportsNPOT = true;
				}
				if (ext.equals("GL_OES_draw_texture")) {
					supportsDrawTex = true;
				}
			}
		}		
	}
	
	public static boolean supportsNPOT(GL gl) {
		initGLInfo(gl);
		return supportsNPOT;
	}
	
	public static boolean supportsDrawTex(GL gl) {
		initGLInfo(gl);
		return supportsDrawTex;
	}
	
	public static boolean isGLExtensionAvailable(String e) {
		for (String ext : glExtensions) {
			if (ext.equals(e)) return true;
		}
		return false;
	}
	
	public static int premultiplyAlpha(int argb) {
		int a = (argb>>24)&0xFF;
		int r = a * ((argb>>16)&0xFF) / 255;
		int g = a * ((argb>>8 )&0xFF) / 255;
		int b = a * ((argb    )&0xFF) / 255;
		return (a<<24)|(r<<16)|(g<<8)|(b);
	}
	
	public static void setColorPre(GL10 gl, int argb) {
		int a = (argb>>24)&0xFF;
		int r = (argb>>16)&0xFF;
		int g = (argb>>8 )&0xFF;
		int b = (argb    )&0xFF;
		
		gl.glColor4f(r/255f, g/255f, b/255f, a/255f);
	}
		
	private static Quad quad;
	private static int crop[] = {0, 0, 1, 1};

	public static int round(float f) {
		return f >= 0f ? (int)(f+.5f) : (int)(f-.5f);
	}
	public static int round(double d) {
		return d >= 0.0 ? (int)(d+.5) : (int)(d-.5);
	}
	public static int ceil(float f) {
		return (int)FloatMath.ceil(f);
	}
	public static int floor(float f) {
		return (int)FloatMath.floor(f);
	}
		
	public static void drawTexRecti(GL11 gl11, int texId, int texW, int texH,
			int ix, int iy, int iw, int ih, double u, double v, double uw, double vh)
	{
		if (!supportsDrawTex(gl11)) throw new RuntimeException("drawTexRect is not supported on this hardware");
		if (iw == 0 || ih == 0) return; 
		
		GL11Ext gl11Ext = (GL11Ext)gl11;
		
		if (iw <= 0) {
			ix += iw;  iw = -iw; u += uw; uw = -uw;
		}		
		if (ih <= 0) {
			iy += ih;  ih = -ih; v += vh; vh = -vh;
		}
		
		if (texId != 0) {
			gl11.glEnable(GL_TEXTURE_2D);
			gl11.glBindTexture(GL_TEXTURE_2D, texId);
			gl11.glTexEnvx(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);	        	        
			
			crop[0] = round(u); crop[1] = round(v); crop[2] = round(uw); crop[3] = round(vh);
			gl11.glTexParameteriv(GL_TEXTURE_2D, GL11Ext.GL_TEXTURE_CROP_RECT_OES, crop, 0);
		} else {
			gl11.glDisable(GL_TEXTURE_2D);			
		}		
		gl11Ext.glDrawTexiOES(ix, iy, 0, iw, ih);
	}
	
	
	public static void drawTexRectf(GL11 gl11, int texId, int texW, int texH,
			double x, double y, double w, double h, double u, double v, double uw, double vh)
	{
		if (!supportsDrawTex(gl11)) throw new RuntimeException("drawTexRect is not supported on this hardware");
		if (w == 0 || h == 0) return; 
		
		GL11Ext gl11Ext = (GL11Ext)gl11;
		
		if (w <= 0) {
			x += w;  w = -w; u += uw; uw = -uw;
		}		
		if (h <= 0) {
			y += h;  h = -h; v += vh; vh = -vh;
		}
		
		if (texId != 0) {
			gl11.glEnable(GL_TEXTURE_2D);
			gl11.glBindTexture(GL_TEXTURE_2D, texId);
			gl11.glTexEnvx(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);	        	        
			
			crop[0] = round(u); crop[1] = round(v); crop[2] = round(uw); crop[3] = round(vh);	
			gl11.glTexParameteriv(GL_TEXTURE_2D, GL11Ext.GL_TEXTURE_CROP_RECT_OES, crop, 0);
		} else {
			gl11.glDisable(GL_TEXTURE_2D);
		}
		gl11Ext.glDrawTexfOES((float)x, (float)y, 0, (float)w, (float)h);
	}
	
	public static void drawQuad(GL10 gl, int texId, int texW, int texH,
			double x, double y, double w, double h,
			double u, double v, double uw, double vh)
	{
		if (texId != 0) {
			gl.glEnable(GL_TEXTURE_2D);
			gl.glBindTexture(GL_TEXTURE_2D, texId);
			gl.glTexEnvx(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);	        	        
		} else {
			gl.glDisable(GL_TEXTURE_2D);			
		}
		
		if (quad == null) quad = new Quad();
		quad.setBounds((float)x, (float)y, (float)w, (float)h);
		quad.setTextureCount(1);
		quad.setCrop(0, texW, texH, (float)u, (float)v, (float)uw, (float)vh);
		quad.draw(gl);
	}
	
	public static void drawMultiQuad(GL10 gl,
			double x, double y, double w, double h,
			float[] uv0, float[] uv1)
	{
		if (quad == null) quad = new Quad();
		quad.setBounds((float)x, (float)y, (float)w, (float)h);
		quad.setTextureCount(2);
		quad.setCrop(0, uv0);
		quad.setCrop(1, uv1);
		quad.draw(gl);
	}
	
	private static class Quad {
		
	    private FloatBuffer verts;
	    private ByteBuffer indexBuf;
	    private FloatBuffer[] texCoords;
	    private int textureCount;
		
	    public Quad() {
	    	ByteBuffer vertsB = ByteBuffer.allocateDirect(4 * 2 * 4);
	    	vertsB.order(ByteOrder.nativeOrder());
	        verts = vertsB.asFloatBuffer();

	        ByteBuffer indexBufB = ByteBuffer.allocateDirect(4 * 2 * 1);
	        indexBufB.order(ByteOrder.nativeOrder());
	        indexBuf = indexBufB;

			for (int n = 0; n < 4; n++) {
				indexBuf.put((byte)n);
			}
	        indexBuf.rewind();

	        texCoords = new FloatBuffer[4];
	        for (int n = 0; n < texCoords.length; n++) {
		    	ByteBuffer texCoordsB = ByteBuffer.allocateDirect(4 * 2 * 4);
		    	texCoordsB.order(ByteOrder.nativeOrder());
		        texCoords[n] = texCoordsB.asFloatBuffer();
	        }	        
	        textureCount = 1;
	    }
	    
	    public void draw(GL10 gl) {
	        gl.glEnableClientState(GL_VERTEX_ARRAY);
	        gl.glVertexPointer(2, GL_FLOAT, 0, verts);
	        for (int n = 0; n < textureCount; n++) {
	        	gl.glClientActiveTexture(GL_TEXTURE0 + n);
		        gl.glEnableClientState(GL_TEXTURE_COORD_ARRAY);		
		        gl.glTexCoordPointer(2, GL_FLOAT, 0, texCoords[n]);
	        }

	        gl.glDrawElements(GL_TRIANGLE_STRIP, 4, GL_UNSIGNED_BYTE, indexBuf);

	        for (int n = textureCount-1; n >= 0; n--) {
	        	gl.glClientActiveTexture(GL_TEXTURE0 + n);
	        	gl.glDisableClientState(GL_TEXTURE_COORD_ARRAY);
	        }
	        gl.glDisableClientState(GL_VERTEX_ARRAY);	        
	    }
	    
	    public void setBounds(float x, float y, float w, float h) {
	    	verts.put(x);   verts.put(y);
	    	verts.put(x+w); verts.put(y);
	    	verts.put(x);   verts.put(y+h);
	    	verts.put(x+w); verts.put(y+h);
	    	verts.rewind();
	    	
	    	//Log.w("Quad.setBounds()", x + " " + y + " " + w + " " + h);
	    }
	    
	    public void setCrop(int texIndex, int tw, int th, float x, float y, float w, float h) {
	    	float u0 = x / tw;
	    	float v0 = y / th;
	    	float u1 = (x+w) / tw;
	    	float v1 = (y+h) / th;
	    	setCrop(texIndex, u0, u1, v0, v1);
	    }
	    public void setCrop(int texIndex, float[] uv) {
	    	setCrop(texIndex, uv[0], uv[1], uv[2], uv[3]);
	    }
	    public void setCrop(int texIndex, float u0, float u1, float v0, float v1) {
	    	FloatBuffer coords = this.texCoords[texIndex];
	    	coords.put(u0); coords.put(v0);
	    	coords.put(u1); coords.put(v0);
	    	coords.put(u0); coords.put(v1);
	    	coords.put(u1); coords.put(v1);
	    	coords.rewind();
	    	
	    	//Log.w("Quad.setCrop()", "(" + tw + "," + th + ") " + x + " " + y + " " + w + " " + h);
	    }
	    
	    public void setTextureCount(int num) {
	    	textureCount = num;
	    }
	    
	}
	
}

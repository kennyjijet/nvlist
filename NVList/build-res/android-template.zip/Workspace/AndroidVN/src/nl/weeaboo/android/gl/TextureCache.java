package nl.weeaboo.android.gl;

import static javax.microedition.khronos.opengles.GL10.GL_CLAMP_TO_EDGE;
import static javax.microedition.khronos.opengles.GL10.GL_LINEAR;
import static javax.microedition.khronos.opengles.GL10.GL_NEAREST;
import static javax.microedition.khronos.opengles.GL10.GL_TEXTURE_2D;
import static javax.microedition.khronos.opengles.GL10.GL_TEXTURE_MAG_FILTER;
import static javax.microedition.khronos.opengles.GL10.GL_TEXTURE_MIN_FILTER;
import static javax.microedition.khronos.opengles.GL10.GL_TEXTURE_WRAP_S;
import static javax.microedition.khronos.opengles.GL10.GL_TEXTURE_WRAP_T;

import java.io.BufferedInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.lang.ref.Reference;
import java.lang.ref.ReferenceQueue;
import java.lang.ref.SoftReference;
import java.lang.ref.WeakReference;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL;
import javax.microedition.khronos.opengles.GL10;

import nl.weeaboo.collections.LRUSet;
import nl.weeaboo.filemanager.FileManagerView;
import nl.weeaboo.image.ImageDesc;
import nl.weeaboo.image.ImageDescUtil;
import nl.weeaboo.image.MultiImageDesc;
import nl.weeaboo.image.MultiImageDesc.CropRect;
import nl.weeaboo.io.EnvironmentSerializable;
import nl.weeaboo.lua2.io.LuaSerializable;
import nl.weeaboo.vn.INotifier;
import nl.weeaboo.vn.android.impl.TextureAdapter;

import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

@LuaSerializable
public class TextureCache extends EnvironmentSerializable {

	private final INotifier notifier;
	private final FileManagerView fm;
	private final FileManagerView afm;
	private final Map<String, ImageDesc> imageDescs;
	private double imageScaleX, imageScaleY;
	private double assetImageScale;
	private int surfaceId;
	private int idgen;
	private Map<String, Reference<GLTexture>> textures;
	private ReferenceQueue<GLTexture> texturesGarbage;
	private LRUSet<String> invalidImages;
	private Set<String> assetImages;
	
	private transient boolean imageFolderInitialized;
	private transient boolean assetImageFolderInitialized;
	
	public TextureCache(INotifier notifier, FileManagerView fm, FileManagerView afm) {
		this.notifier = notifier;
		this.fm = fm;
		this.afm = afm;
		this.imageDescs = new HashMap<String, ImageDesc>();
		
		imageScaleX = imageScaleY = assetImageScale = 1;
		textures = new HashMap<String, Reference<GLTexture>>();
		texturesGarbage = new ReferenceQueue<GLTexture>();
		invalidImages = new LRUSet<String>(128);
		assetImages = new HashSet<String>();
	}
	
	//Functions
	public void initGL(GL gl, EGLConfig config, int rwidth, int rheight) {
		surfaceId++;
		
		clearTextures();
		
		if (!imageFolderInitialized) {
			imageFolderInitialized = true;
			//Do a one-time initialization
			onImageFolderChanged0();
		}
		
		if (!assetImageFolderInitialized) {
			assetImageFolderInitialized = true;
			//Do a one-time initialization
			onAssetImageFolderChanged0();
		}
	}
	
	public void updateGL(GL gl) {
		cleanupGarbage(gl);
	}
	
	protected void cleanupGarbage(GL gl) {
		Reference<?> ref;
		
		GL10 gl10 = (GL10)gl;
		while ((ref = texturesGarbage.poll()) != null) {
			if (ref instanceof GLTextureRef) {
				GLTextureRef texRef = (GLTextureRef)ref;
				if (texRef.surfaceId == surfaceId && texRef.texId != 0) {
					gl10.glDeleteTextures(1, new int[] {texRef.texId}, 0);
				}
			} else if (ref instanceof GLWeakTextureRef) {
				GLWeakTextureRef texRef = (GLWeakTextureRef)ref;
				if (texRef.surfaceId == surfaceId && texRef.texId != 0) {
					gl10.glDeleteTextures(1, new int[] {texRef.texId}, 0);
				}
			}
		}
	}
	
	private void reloadImageDescs() {
		//Reload image descs
		imageDescs.clear();
		try {
			ImageDescUtil.fromFileManager(imageDescs, fm.getFileManager(), fm.getPrefix());
			
			Map<String, ImageDesc> temp = new HashMap<String, ImageDesc>();
			ImageDescUtil.fromFileManager(temp, fm.getFileManager(), afm.getPrefix());
			for (Entry<String, ImageDesc> entry : temp.entrySet()) {
				String key = entry.getKey();
				assetImages.add(key);
				imageDescs.put(key, entry.getValue());
			}
		} catch (IOException ioe) {
			Throwable t = ioe.getCause();
			if (t instanceof SAXParseException) {
				SAXParseException spe = (SAXParseException)t;
				String extra = String.format("%d:%d :: %s", spe.getLineNumber(), spe.getColumnNumber(), spe.getMessage());
				notifier.w("Parse error reading image descs (" + ioe.getMessage() + ") " + extra, spe);				
			} else if (t instanceof SAXException) {
				SAXException se = (SAXException)t;
				String extra = (se != null ? " :: " + se.getMessage() : "");
				notifier.w("Parse error reading image descs (" + ioe.getMessage() + ") " + extra, se);				
			} else {
				String extra = (ioe.getCause() != null ? " :: " + ioe.getCause() : "");
				notifier.w("IO error reading image descs (" + ioe.getMessage() + ") " + extra, ioe);
			}
		}		
	}
	
	protected void onImageFolderChanged() {
		onImageFolderChanged0();
	}
	
	//This function may not call non-private methods, not even indirectly
	private void onImageFolderChanged0() {
		clearTextures();
		invalidImages.clear();
		reloadImageDescs();
	}
	
	protected void onAssetImageFolderChanged() {
		onAssetImageFolderChanged0();
	}
	private void onAssetImageFolderChanged0() {
		clearTextures();
		invalidImages.clear();
		assetImages.clear();
		reloadImageDescs();
		
		/*
		//Dispose assets loaded from the old assets folder
		for (String img : assetImages) {
			invalidImages.remove(img);
			
			imageDescs.remove(img);
			
			Reference<? extends GLTexture> ref = textures.remove(img);
			GLTexture tex = (ref != null ? ref.get() : null);
			if (tex != null) tex.dispose();
		}
		assetImages.clear();
		
		//Reload image descs
    	try {
    		Map<String, ImageDesc> descs = new HashMap<String, ImageDesc>();
			AndroidImageDescUtil.fromAssets(descs, assets, assetImageFolder);
			for (Entry<String, ImageDesc> entry : descs.entrySet()) {
				String key = entry.getKey();
				ImageDesc desc = entry.getValue();
				imageDescs.put(key, desc);
				assetImages.add(key);
			}
		} catch (IOException e) {
			notifier.w("Error loading img.xml for assets", e);
		} catch (ParserConfigurationException e) {
			notifier.w("Error loading img.xml for assets", e);
		} catch (SAXException e) {
			notifier.w("Error loading img.xml for assets", e);
		}
		*/
	}
	
	protected void markAsInvalidImage(String filename) {
		if (invalidImages.size() >= 1024) {
			invalidImages.clear();
		}
		invalidImages.add(filename);
	}
	
	public GLTexture generateTexture(GL gl, int w, int h) {
		return generateTexture(gl, null, w, h);
	}	

	public GLTexture generateTexture(GL gl, int argb[], int w, int h) {
		int texId = (gl != null ? generateTextureId(gl) : 0);
		GLTexture tex = new GLGeneratedTexture(texId, w, h);
		textures.put(String.format("!gen%04d", ++idgen), new GLWeakTextureRef(surfaceId, tex, texturesGarbage));
		if (argb != null) {
			tex.setPixels(gl, argb, w, h);
		}
		return tex;
	}

	public GLTexture generateTexture(GL gl, Bitmap bitmap) {
		int texId = (gl != null ? generateTextureId(gl) : 0);
		GLTexture tex = new GLGeneratedTexture(texId, bitmap.getWidth(), bitmap.getHeight());
		textures.put(String.format("!gen%04d", ++idgen), new GLWeakTextureRef(surfaceId, tex, texturesGarbage));
		tex.setPixels(gl, bitmap);
		return tex;
	}
	
	protected int generateTextureId(GL gl) {
		GL10 gl10 = (GL10)gl;
		
        int[] texIds = new int[1];
        gl10.glGenTextures(1, texIds, 0);

        gl10.glBindTexture(GL_TEXTURE_2D, texIds[0]);
        gl10.glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
        //gl.glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        //gl.glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
        gl10.glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
        gl10.glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
        gl10.glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
        
        return texIds[0];
	}
	
	protected GLImageTexture loadTexture(GL gl, ImageDesc desc, Bitmap bitmap) {		
		String filename = desc.getFilename();		
		if (invalidImages.contains(filename)) {
			return null;
		}
		
		BitmapFactory.Options opts = new BitmapFactory.Options();
		opts.inDither = true;
		opts.inScaled = false;
		
		boolean mipmap = desc.getMinifyFilter().isMipmap();
		
		if (bitmap == null || bitmap.isRecycled()) {
			try {
				InputStream in;
				try {
					in = afm.getInputStream(filename);
				} catch (FileNotFoundException fnfe) {
					in = fm.getInputStream(filename);
				}
				
				try {
					in = new BufferedInputStream(in, 4096);
					bitmap = BitmapFactory.decodeStream(in, null, opts);
				} finally {
					try {
						in.close();
					} catch (IOException e) {
						//Ignore
					}
		        }
			} catch (FileNotFoundException fnfe) {
				notifier.d("Image file not found (" + filename + ")", fnfe);
				markAsInvalidImage(desc.getFilename());
				return null;
			} catch (IOException e) {
				notifier.w("Image file not found (" + filename + ")", e);
				markAsInvalidImage(desc.getFilename());
				return null;
			}
		}
		
		if (bitmap == null) {
			notifier.w("Error decoding bitmap ("+filename+")");
			markAsInvalidImage(filename);
			return null;
		}
		
		int texId = 0;
		if (gl != null) {
			texId = generateTextureId(gl);
		}
		GLImageTexture tex = new GLImageTexture(desc, texId);
		tex.initialSetPixels(gl, bitmap, mipmap); 
		
        return tex;
	}
		
	public void clearTextures() {
		//Unload all existing textures
		Iterator<Entry<String, Reference<GLTexture>>> itr = textures.entrySet().iterator();
		while (itr.hasNext()) {
			Reference<GLTexture> ref = itr.next().getValue();
			GLTexture tex = ref.get();
			if (tex != null) {
				tex.dispose();
			}
			if (tex == null) {
				itr.remove();
			} else if (tex instanceof GLImageTexture) {
				GLImageTexture itex = (GLImageTexture)tex;
				itex.disposePixels();
				itr.remove();
			}
		}
	}
	
	//Getters	
	public String getFilePart(String id) {
		int index = id.indexOf('#');
		return (index >= 0 ? id.substring(0, index) : id);
	}
	
	public String getSubPart(String id) {
		int index = id.indexOf('#');
		return (index >= 0 ? id.substring(index+1) : null);
	}
	
	public boolean getImageFileExists(String id) {
		String filename = getFilePart(id);
		if (invalidImages.contains(filename)) {
			return false;
		}
		
		try {
			return getImageDesc(filename) != null;
		} catch (IOException e) {
			markAsInvalidImage(filename);
			return false;
		}
	}
	
	public boolean getImageExists(String id) {
		String filename = getFilePart(id);
		String subpart = getSubPart(id);
		if (subpart == null) {
			return getImageFileExists(filename);
		}
		
		try {
			ImageDesc desc = getImageDesc(filename);
			if (desc instanceof MultiImageDesc) {
				MultiImageDesc mdesc = (MultiImageDesc)desc;
				for (CropRect cr : mdesc.getCropRects()) {
					if (subpart.equals(cr.getId())) {
						return true;
					}
				}
			}
		} catch (IOException e) {
			//Ignore
		}		
		return false;
	}
	
	public Collection<String> getImageFiles(String folder, boolean recursive) throws IOException {
		return fm.getFolderContents(folder, recursive);
	}
	
	public TextureAdapter get(GL gl, String id) {		
		String filepart = getFilePart(id);
		String croppart = getSubPart(id);
		
		Reference<GLTexture> ref = textures.get(filepart);
		GLTexture tex = (ref != null ? ref.get() : null);
		if (tex == null || tex.isDisposed()) {
			if (invalidImages.contains(filepart)) {
				return null;
			}
			
			ImageDesc desc;
			try {
				desc = getImageDesc(filepart);
			} catch (IOException e) {
				if (e instanceof FileNotFoundException) {
					notifier.d(filepart, e);
				} else {
					notifier.w(filepart, e);
				}
				markAsInvalidImage(filepart);
				return null;
			}
			
			Bitmap oldBitmap = null;
			if (tex instanceof GLImageTexture) {
				oldBitmap = ((GLImageTexture)tex).getBitmap();
			}
			tex = loadTexture(gl, desc, oldBitmap);

			if (tex != null) {
				textures.put(filepart, new GLTextureRef(surfaceId, tex, texturesGarbage));
			}
		}		
		
		if (tex != null) {
			GLTexRect tr = tex.getTexRect(croppart);
			if (tr != null) {
				double scaleX, scaleY;				
				if (assetImages.contains(filepart)) {
					scaleX = scaleY = assetImageScale;
				} else {
					scaleX = imageScaleX;
					scaleY = imageScaleY;
				}
				//System.out.println(filepart + " " + croppart + " " + tr.getUV());
				return new TextureAdapter(tr, id, scaleX, scaleY);
			}
		}
		return null;
	}
	
	public ImageDesc getImageDesc(String filename) throws IOException {
		ImageDesc desc = imageDescs.get(filename);		
		if (desc == null) {
			InputStream in = null;
			try {
				try {
					in = afm.getInputStream(filename);
					assetImages.add(filename);
				} catch (FileNotFoundException fnfe) {
					in = fm.getInputStream(filename);
				}
				in = new BufferedInputStream(in, 4096);
				desc = ImageDescUtil.fromImageFile(filename, in);
				//System.out.println(desc);
			} finally {
				try {
					if (in != null) in.close();
				} catch (IOException ioe) {
					//Ignore
				}
			}
			imageDescs.put(filename, desc);
		}
		return desc;
	}
	
	//Setters
	public void setImageFolder(String folder, double scaleX, double scaleY) {
		if (folder.length() > 0 && !folder.endsWith("/")) {
			folder += "/";
		}
		
		if (!folder.equals(fm.getPrefix()) || imageScaleX != scaleX || imageScaleY != scaleY) {
			fm.setPrefix(folder);
			imageScaleX = scaleX;
			imageScaleY = scaleY;

			onImageFolderChanged();
		}
	}
	
	public void setAssetImageFolder(String folder, double scale) {
		if (folder.length() > 0 && !folder.endsWith("/")) {
			folder += "/";
		}
		
		if (!folder.equals(afm.getPrefix()) || assetImageScale != scale) {
			afm.setPrefix(folder);
			assetImageScale = scale;
			
			onAssetImageFolderChanged();			
		}
	}
	
	//Inner Classes
	private static class GLTextureRef extends SoftReference<GLTexture> {

		public final int surfaceId;
		public final int texId;
		
		public GLTextureRef(int surfaceId, GLTexture r, ReferenceQueue<? super GLTexture> q) {
			super(r, q);
			
			this.surfaceId = surfaceId;
			this.texId = r.getTexId();
		}
		
	}

	private static class GLWeakTextureRef extends WeakReference<GLTexture> {

		public final int surfaceId;
		public final int texId;
		
		public GLWeakTextureRef(int surfaceId, GLTexture r, ReferenceQueue<? super GLTexture> q) {
			super(r, q);
			
			this.surfaceId = surfaceId;
			this.texId = r.getTexId();
		}
		
	}
}

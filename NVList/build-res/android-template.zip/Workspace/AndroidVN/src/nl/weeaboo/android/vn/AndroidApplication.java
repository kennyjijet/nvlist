package nl.weeaboo.android.vn;

import android.app.Application;

public class AndroidApplication extends Application {

	public static Game game;
	
}

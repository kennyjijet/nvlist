package nl.weeaboo.android.gles;

import nl.weeaboo.gl.GLResCache;
import nl.weeaboo.gl.GLResId;
import nl.weeaboo.gl.PBO;

public class ES1ResCache extends GLResCache {

	@Override
	public int getBufferCount() {
		return 0;
	}

	@Override
	public int getProgramCount() {
		return 0;
	}

	@Override
	public int getTextureCount() {
		return ES1ResId.getTextureCount();
	}

	@Override
	public void registerId(GLResId id) {
		registerId(new ES1ResId.IdRef((ES1ResId)id, this));
	}

	@Override
	public PBO newPBO() {
		throw new RuntimeException("Not implemented");
	}

}

package nl.weeaboo.vn.android.impl;

import java.io.FileDescriptor;
import java.io.IOException;
import java.io.ObjectInputStream;

import nl.weeaboo.android.FileSegment;
import nl.weeaboo.android.ResourceManager;
import nl.weeaboo.lua2.io.LuaSerializable;
import nl.weeaboo.vn.INotifier;
import nl.weeaboo.vn.SoundType;
import nl.weeaboo.vn.impl.base.BaseSound;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnCompletionListener;
import android.media.MediaPlayer.OnErrorListener;
import android.media.MediaPlayer.OnPreparedListener;

@LuaSerializable
public class Sound extends BaseSound {

	private static final long serialVersionUID = AndroidImpl.serialVersionUID;

	private static final int syncWaitTime = 500; //Milliseconds
	
	private SoundFactory factory;
	private final INotifier notifier;
	private final String sndFolderPrefix;
	
	private final Integer loopLeftLock = new Integer(1337); //Must be serializable
	
	private transient MediaPlayer mp;
	private volatile transient boolean prepared;
	private volatile transient boolean startEnqueued;
	
	Sound(SoundFactory f, SoundType stype, String folderPrefix, String filename) {
		super(stype, filename);

		this.factory = f;
		this.notifier = f.getNotifier();
		this.sndFolderPrefix = folderPrefix;
	}
	
	//Functions
	@Override
	public void destroy() {
		if (!isDestroyed()) {
			super.destroy();
			
			factory = null;
		}
	}
	
	@Override
	protected void _start() throws IOException {
		final SoundFactory fac = factory;
		if (fac == null) {
			return;
		}
		
		ResourceManager rm = fac.getResourceManager();

		final String relpath = getFilename();
		final float volume = (float)getVolume();
		final FileSegment fileseg = rm.getFileSegment(sndFolderPrefix + relpath);
		
		startEnqueued = true;
		
		Runnable r = new Runnable() {
			public void run() {
				prepared = false;

				mp = new MediaPlayer();
				mp.reset();
				mp.setAudioStreamType(AudioManager.STREAM_MUSIC);
				
				try {
					FileDescriptor fd = fileseg.open();
					try {
						mp.setDataSource(fd, fileseg.getOffset(), fileseg.getLength());
					} finally {
						fileseg.close();
					}
				} catch (IOException ioe) {					
					String message = ioe.getMessage();
					if (message.startsWith("setDataSourceFD") && message.indexOf("status=0x80000000") >= 0) {
						//Unsupported audio format
						
						// Android is broken since 2.2, see: Android bug #9787
						// (http://code.google.com/p/android/issues/detail?id=9787)
						notifier.d("Unsupported audio format causing an error in setDataSource (" + relpath + ")");
					} else {
						notifier.w("Error playing audio ("+relpath+")", ioe);
					}
					startEnqueued = false;				
					//try { mp.release(); } catch (IllegalStateException ise) { }
					return;
				}

				mp.setVolume(volume, volume);
				
				mp.setOnPreparedListener(new OnPreparedListener() {
					public void onPrepared(MediaPlayer m) {
						if (mp == m) {
							prepared = true;
							startEnqueued = false;				
						}
						try{ m.start(); } catch (IllegalStateException ise) { }
					}
				});
				mp.setOnCompletionListener(new OnCompletionListener() {
					public void onCompletion(MediaPlayer m) {
						if (mp == m) {
							if (!onLoopEnd()) {
								mp.start();
								return;
							}
							destroy();
							mp = null;
							prepared = false;
						}
						try {
							m.release();
						} catch (IllegalStateException ise) { }
					}
				});
				mp.setOnErrorListener(new OnErrorListener() {
					public boolean onError(MediaPlayer m, int what, int extra) {
						if (mp == m) {
							mp = null;
							prepared = false;
							notifier.d("Error playing audio ("+relpath+") what="+what+" extra="+extra);
						}
						try {
							m.release();
						} catch (IllegalStateException ise) { }
						return true;
					}
				});
				
				//mp.prepareAsync();
				
				//Prepare/start synchronously
				try {
					mp.prepare();
					startEnqueued = false;				
					mp.start();
				} catch (Exception e) {
					startEnqueued = false;	
					
					notifier.d("Error playing audio ("+relpath+")");
					try {
						mp.release();
					} catch (IllegalStateException ise) { }
					return;
				}				
			}
		};
		post(r);
		
		//Wait for playback to start
		for (int n = 0; startEnqueued && n < syncWaitTime; n++) {
			try {
				Thread.sleep(1);
			} catch (InterruptedException e) { }
		}
	}

	@Override
	protected void _stop() {
		Runnable r = new Runnable() {
			public void run() {
				if (mp != null) {
					if (prepared) {
						try {
							mp.stop();
						} catch (IllegalStateException ise) { }
					}
					try {
						mp.release();
					} catch (IllegalStateException ise) { }
					
					mp = null;
					prepared = false;
				}
			}
		};
		post(r);
	}

	@Override
	protected void _pause() {
		Runnable r = new Runnable() {
			public void run() {
				if (mp != null && prepared) {
					try { mp.pause(); } catch (IllegalStateException ise) { }
				}
			}
		};
		post(r);
	}

	@Override
	protected void _resume() {
		Runnable r = new Runnable() {
			public void run() {
				if (mp != null && prepared) {
					try { mp.start(); } catch (IllegalStateException ise) { }
				}
			}
		};
		post(r);
	}

	@Override
	protected void onVolumeChanged() {
		final float volume = (float)getVolume();
		
		Runnable r = new Runnable() {
			public void run() {
				if (mp != null) {
					mp.setVolume(volume, volume);
				}
			}
		};
		post(r);
	}
	
	@Override
	protected boolean onLoopEnd() {
		synchronized (loopLeftLock) {
			return super.onLoopEnd();
		}
	}
	
	protected void post(Runnable r) {
		final SoundFactory fac = factory;
		if (fac != null) {
			fac.getSoundHandler().post(r);
		}
	}
	
	private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
		in.defaultReadObject();

		//Restart automatically when loaded
		if (!isStopped()) {
			_start();
			if (isPaused()) {
				_pause();
			}
		}
	}	
			
	//Getters
	@Override
	public int getLoopsLeft() {
		synchronized (loopLeftLock) {
			return super.getLoopsLeft();
		}
	}
	
	//Setters
	@Override
	protected void setLoopsLeft(int ll) {
		synchronized (loopLeftLock) {
			super.setLoopsLeft(ll);
		}
	}
	
}

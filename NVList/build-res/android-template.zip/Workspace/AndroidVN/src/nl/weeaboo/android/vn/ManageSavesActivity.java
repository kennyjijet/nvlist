package nl.weeaboo.android.vn;

import static nl.weeaboo.android.AndroidUtil.cancelTask;
import static nl.weeaboo.android.AndroidUtil.isTaskRunning;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import nl.weeaboo.android.gui.ProgressAsyncTask;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.os.Handler;
import android.util.SparseBooleanArray;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckedTextView;
import android.widget.ListView;
import android.widget.Toast;

public class ManageSavesActivity extends Activity {

	private Handler handler;
	private ListView saveList;
	private SaveItemAdapter saveItemAdapter;
	private Button deleteButton;
	private ProgressAsyncTask<File, SaveItem[]> refreshTask;
	
	//Functions
	@Override
	public void onCreate(Bundle bundle) {
		super.onCreate(bundle);
		
		handler = new Handler();		

		setContentView(R.layout.mansave);
				
		deleteButton = (Button)findViewById(R.id.mansaveDelete);
		deleteButton.setEnabled(false);
		
		saveList = (ListView)findViewById(R.id.mansaveList);
		saveList.setEmptyView(findViewById(android.R.id.empty));
		saveList.setOnItemClickListener(new OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> parent, View view, int pos, long id) {
				onMultiSelectionChanged();
			}
		});
		
		saveItemAdapter = new SaveItemAdapter();
		saveList.setAdapter(saveItemAdapter);
		
		refresh();
	}
	
	@Override
	public void onDestroy() {
		cancelTask(refreshTask);
		refreshTask = null;
		
		super.onDestroy();
	}
	
	@Override
	public void onResume() {
		super.onResume();	
		
		if (saveList.getCount() == 0) {
			refresh();
		}
	}
	
	@Override
	public void onPause() {
		cancelTask(refreshTask);
		refreshTask = null;
		
		super.onPause();		
	}
	
	public void onRefreshPressed(final View view) {
		cancelTask(refreshTask);
		refreshTask = null;
		
		refresh();		
	}
	
	private static void findSaveFolders(File folder, List<File> result) {
		if (folder.getName().equals("save")) {
			result.add(folder);
		} else {
			File[] children = folder.listFiles();
			if (children != null) {
				for (File child : children) {
					if (child.isDirectory()) {
						findSaveFolders(child, result);
					} else if (child.getName().equals("sysvars.bin")) {
						result.add(folder); //Required to be compatible with version <= 1.4.7
					}
				}
			}
		}
	}
	
	private void onMultiSelectionChanged() {
		SparseBooleanArray sba = saveList.getCheckedItemPositions();
    	deleteButton.setEnabled(sba.indexOfValue(true) >= 0);		
	}
	
	public void refresh() {
		if (isTaskRunning(refreshTask)) {
			return;
		}
		
		List<File> files = new ArrayList<File>();
		findSaveFolders(getFilesDir().getParentFile(), files);				
		File[] saveFolders = files.toArray(new File[files.size()]);
		
		String msg = getString(R.string.mansave_refresh_dialog);
		
		refreshTask = new ProgressAsyncTask<File, SaveItem[]>(this, handler, msg) {
			@Override
			protected SaveItem[] doInBackground(File... params) {
				List<SaveItem> list = new ArrayList<SaveItem>();
				for (File saveFolder : params) {
					if (isCancelled()) return null;

					File files[] = saveFolder.listFiles();
					if (files != null) {
						for (File file : files) {
							if (isCancelled()) return null;
							if (!file.isFile()) continue;
							
							String gameId = file.getAbsolutePath();
							int index = gameId.indexOf("app_");
							if (index < 0) continue;
							gameId = gameId.substring(index + 4);
							index = gameId.indexOf("/save", 1);
							if (index < 0) {
								index = gameId.indexOf("/save-shared.bin", 1);
								if (index < 0) {
									index = gameId.indexOf("/sysvars.bin", 1);
									if (index < 0) continue;
								}
							}
							gameId = gameId.substring(0, index);
							
							list.add(new SaveItem(gameId, file));
						}
					}
				}
				
				SaveItem[] result = list.toArray(new SaveItem[list.size()]);
				Arrays.sort(result);
				return result;
			}

			@Override
			protected void onPostExecute(SaveItem result[]) {
				saveItemAdapter.clear();
				for (SaveItem item : result) {
					saveItemAdapter.add(item);
				}				
				super.onPostExecute(result);
			}
		};
		refreshTask.setShowDelay(500);
		refreshTask.execute(saveFolders);
	}
	
	public void onDeletePressed(final View view) {
		new AlertDialog.Builder(this)
			.setTitle(R.string.mansave_confirm_delete_title)
			.setMessage(R.string.mansave_confirm_delete_message)
			.setPositiveButton(R.string.mansave_confirm_delete_ok, new Dialog.OnClickListener() {
				public void onClick(DialogInterface dialog, int which) {
					int deleted = 0;
					SparseBooleanArray sba = saveList.getCheckedItemPositions();
					for (int n = 0; n < sba.size(); n++) {
						int key = sba.keyAt(n);
						if (sba.valueAt(n)) {
							SaveItem item = saveItemAdapter.getItem(key);
							if (item != null && item.file != null) {
								//System.out.println("Delete: " + item.file);
								if (item.file.delete()) {
									deleted++;
								}
							}
						}
					}
					saveList.clearChoices();
								
					String string = getString(R.string.mansave_deleted_toast, deleted);
					Toast toast = Toast.makeText(ManageSavesActivity.this, string, Toast.LENGTH_SHORT);
					toast.show();
					
					refresh();
				}
			})
			.setNegativeButton(R.string.mansave_confirm_delete_cancel, null)
			.show();		        
	}
	
	//Getters
	
	//Setters
	
	//Inner Classes
	private static class SaveItem implements Comparable<SaveItem> {

		private final String gameId;
		private final File file;
		private final String string;
		
		private SaveItem(String gid, File f) {
			this.gameId = gid;
			this.file = f;
			
			String fn = file.getName();
			if (fn.equals("sysvars.bin")) {
				fn = "global.sav";
			}
			int kbs = (int)(file.length() >> 10);
			string = String.format("[%s] %s\n%dKiB", gameId, fn, kbs);
		}
		
		@Override
		public String toString() {
			return string;
		}

		@Override
		public int compareTo(SaveItem item) {
			if (item == null) return 1;
			int result = gameId.compareTo(item.gameId);
			if (result != 0) return result;
			return file.getName().compareTo(item.file.getName());
		}
		
	}
	
	private class SaveItemAdapter extends ArrayAdapter<SaveItem> {
		
		public SaveItemAdapter() {
			super(ManageSavesActivity.this, android.R.layout.simple_list_item_multiple_choice);
		}
		
		public View getView(int position, View convertView, ViewGroup parent) {
			if (convertView == null) {
				convertView = getLayoutInflater().inflate(R.layout.mansave_list_item, parent, false);
			
				ViewHolder holder = new ViewHolder(
						(CheckedTextView)convertView.findViewById(R.id.mansaveListItem));
				convertView.setTag(holder);
			}
			
			ViewHolder holder = (ViewHolder)convertView.getTag();
			SaveItem item = getItem(position);

			CheckedTextView check = holder.check;
			if (check != null) {
				check.setFocusable(false);
				check.setText(item.toString());
			}
			
			return convertView;
		}
		
		class ViewHolder {
			
			CheckedTextView check;
			
			public ViewHolder(CheckedTextView c) {
				check = c;
			}
		}
		
	}
	
}

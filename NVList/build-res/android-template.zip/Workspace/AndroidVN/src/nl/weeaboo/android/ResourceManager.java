package nl.weeaboo.android;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URI;

import nl.weeaboo.filemanager.FileManager;
import nl.weeaboo.zip.FileRecord;
import nl.weeaboo.zip.FilterFileArchive;
import nl.weeaboo.zip.IFileArchive;
import nl.weeaboo.zip.ZipArchive;
import android.content.Context;

public class ResourceManager extends FileManager {

	private String imageFolder;
	private String soundFolder;
	private String videoFolder;
	private File cacheFolder;
	
	public ResourceManager(Context context, URI readURI, String... zipFileNames) {
		super(readURI, zipFileNames);
		
		imageFolder = "img/";
		soundFolder = "snd/";
		videoFolder = "video/";
		cacheFolder = context.getCacheDir();
	}
		
	//Functions
	@Override
	protected boolean checkCrossPlatformFilename(File root, String path, File file) {
		return true; //Don't bother checking on Android, can cause random exceptions within java internals.
	}
	
	//Getters	
	/**
	 * @return The image folder prefix, will end with a slash if needed.
	 */
	public String getImageFolder() {
		return imageFolder;
	}
	
	/**
	 * @return The sound folder prefix, will end with a slash if needed.
	 */
	public String getSoundFolder() {
		return soundFolder;
	}
	
	/**
	 * @return The video folder prefix, will end with a slash if needed.
	 */
	public String getVideoFolder() {
		return videoFolder;
	}
	
	public File getCacheFolder() {
		return cacheFolder;
	}
	
	@Override
	public File[] getReadFolders() {
		return super.getReadFolders();
	}
	
	@Override
	public File getWriteFolder() {
		return super.getWriteFolder();
	}
		
	//Setters
	public FileSegment getFileSegment(String path) throws IOException {
		for (File root : getReadFolders()) {
			if (getFileExistsF(root, path)) {
				return FileSegment.fromFile(new File(root, path));
			}
		}
		for (IFileArchive archive : getArchives()) {			
			while (archive instanceof FilterFileArchive) {
				archive = ((FilterFileArchive)archive).getInner();
			}
			
			if (archive instanceof ZipArchive) {
				ZipArchive zip = (ZipArchive)archive;
				FileRecord r = zip.get(path);
				if (r != null && zip.getFile() != null) {
					return FileSegment.fromFile(zip.getFile(), r.offset, r.compressedLength);
				}
			}
			
			if (archive instanceof AssetZipArchive) {
				AssetZipArchive azip = (AssetZipArchive)archive;
				FileRecord r = azip.get(path);
				if (r != null && azip.getAssets() != null) {
					return FileSegment.fromAsset(azip.getAssets(), r.getFilename(),
							null, 0, r.compressedLength);
				}
			}
		}
				
		throw new FileNotFoundException(path);
	}
	
	public void setImageFolder(String imgF) {
		imageFolder = (imgF.length() > 0 && !imgF.endsWith("/") ? imgF+"/" : imgF);
	}
	public void setSoundFolder(String sndF) {
		soundFolder = (sndF.length() > 0 && !sndF.endsWith("/") ? sndF+"/" : sndF);
	}
	public void setVideoFolder(String vidF) {
		videoFolder = (vidF.length() > 0 && !vidF.endsWith("/") ? vidF+"/" : vidF);
	}
	
}

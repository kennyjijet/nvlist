package nl.weeaboo.android.vn;

import java.io.Serializable;

import nl.weeaboo.lua2.io.LuaSerializable;
import nl.weeaboo.vn.RenderEnv;

@LuaSerializable
public class AndroidRenderEnv extends RenderEnv implements Serializable {

	private static final long serialVersionUID = 1L;
	
	public final float textSize;
	public final float displayDensity;
	public final boolean allowCoordinateRounding;
	
	public AndroidRenderEnv(int vw, int vh, int rx, int ry, int rw, int rh, int sw, int sh, boolean isTouchScreen,
			float textSize, float displayDensity, boolean allowCoordinateRounding)
	{
		super(vw, vh, rx, ry, rw, rh, sw, sh, isTouchScreen);
		
		this.textSize = textSize;
		this.displayDensity = displayDensity;
		this.allowCoordinateRounding = allowCoordinateRounding;
	}

}

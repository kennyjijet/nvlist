package nl.weeaboo.android.gles;

import static nl.weeaboo.gl.GLUtil.toPowerOfTwo;
import nl.weeaboo.gl.GLInfo;
import android.graphics.Bitmap;
import android.util.FloatMath;

public final class ESUtil {

	private ESUtil() {		
	}
	
	public static Bitmap createCompatibleBitmap(GLInfo glInfo, int w, int h) {
		return createCompatibleBitmap(glInfo, w, h, (Bitmap)null);
	}
	public static Bitmap createCompatibleBitmap(GLInfo glInfo, int w, int h, Bitmap sourceBitmap) {
		return createCompatibleBitmap(glInfo, w, h, getCompatibleBitmapConfig(sourceBitmap));
	}
	public static Bitmap createCompatibleBitmap(GLInfo glInfo, int w, int h, Bitmap.Config config) {	
		if (!glInfo.isTexNPOTSupported()) {
			w = toPowerOfTwo(w);
			h = toPowerOfTwo(h);
		}
		
		if (config == null) {
			config = Bitmap.Config.ARGB_8888;
		}
		
        return Bitmap.createBitmap(w, h, config);
	}
	
	public static Bitmap.Config getCompatibleBitmapConfig(Bitmap bitmap) {
		Bitmap.Config config = null;
		if (bitmap != null) {
			config = bitmap.getConfig();
		}

		if (config == null) {
			config = Bitmap.Config.ARGB_8888;			
		}
		
		return config;
	}
	
	public static int round(float f) {
		return f >= 0f ? (int)(f+.5f) : (int)(f-.5f);
	}
	public static int round(double d) {
		return d >= 0.0 ? (int)(d+.5) : (int)(d-.5);
	}
	public static int ceil(float f) {
		return (int)FloatMath.ceil(f);
	}
	public static int floor(float f) {
		return (int)FloatMath.floor(f);
	}	
}

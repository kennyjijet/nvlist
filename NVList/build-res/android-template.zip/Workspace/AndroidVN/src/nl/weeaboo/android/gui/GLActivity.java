package nl.weeaboo.android.gui;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.pm.ApplicationInfo;
import android.opengl.GLSurfaceView;
import android.opengl.GLSurfaceView.Renderer;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.View;
import android.view.View.OnTouchListener;

public abstract class GLActivity extends Activity {

	protected final Renderer renderer;
	protected InputAccumulator inputAccum;
	protected GLSurfaceView glView;
	private SurfaceHolder surfaceHolder;
	
	protected GLActivity(Renderer r) {
		renderer = r;
	}
	
	//Functions
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		inputAccum = new InputAccumulator();

		glView = createGLView();
		surfaceHolder = glView.getHolder();	

		glView.setRenderer(renderer);		
		glView.setRenderMode(GLSurfaceView.RENDERMODE_WHEN_DIRTY);
		setContentView(glView);
	}
	
	public GLSurfaceView createGLView() {
		GLSurfaceView glView = new GLSurfaceView(this);
		glView.setOnTouchListener(new OnTouchListener() {
			//Must add touchlistener to GLView (otherwise the actionbar messes up our coordinates)
			
			@Override
			public boolean onTouch(View view, MotionEvent event) {
				return inputAccum.onTouchEvent(event);
			}
		});
		if ((getApplication().getApplicationInfo().flags & ApplicationInfo.FLAG_DEBUGGABLE) != 0) {
			glView.setDebugFlags(GLSurfaceView.DEBUG_CHECK_GL_ERROR); //DEBUG_LOG_GL_CALLS
			glView.setEGLConfigChooser(8, 8, 8, 8, 0, 0); //Required to get GLES 2.0 to run on the emulator
		}
		//glView.setEGLConfigChooser(false); //glView.setEGLConfigChooser(8, 8, 8, 0, 0, 0);
		glView.setFocusableInTouchMode(true);	
		return glView;
	}
	
	@Override
	protected void onPause() {
		super.onPause();
		
		if (glView != null) glView.onPause();
	}

	@Override
	protected void onResume() {
		super.onResume();
		
		if (glView != null) glView.onResume();
	}

	@Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (event.isSystem()) {
			return super.onKeyDown(keyCode, event);
		}
		return inputAccum.onKeyDown(event);
	}
	
	//@Override Not supported in 1.6
	@SuppressLint("Override")
	public boolean onKeyLongPress(int keyCode, KeyEvent event) {
		if (event.isSystem()) {
			//return super.onKeyLongPress(keyCode, event);
		}		
		return inputAccum.onKeyLongPress(event);
	}

	@Override
	public boolean onKeyMultiple(int keyCode, int repeatCount, KeyEvent event) {
		if (event.isSystem()) {
			return super.onKeyMultiple(keyCode, repeatCount, event);
		}
		return inputAccum.onKeyMultiple(event);
	}
	
	@Override
	public boolean onKeyUp(int keyCode, KeyEvent event) {
		if (event.isSystem() && keyCode != KeyEvent.KEYCODE_BACK) {			
			return super.onKeyUp(keyCode, event);
		}
		return inputAccum.onKeyUp(event);
	}
		
	//Getters
	public SurfaceHolder getSurfaceHolder() {
		return surfaceHolder;
	}
	public View getGLView() {
		return glView;
	}
	
	//Setters
	
}

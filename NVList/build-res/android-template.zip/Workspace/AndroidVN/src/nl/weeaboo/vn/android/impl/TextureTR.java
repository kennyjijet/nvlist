package nl.weeaboo.vn.android.impl;

import java.util.Arrays;

import nl.weeaboo.android.gles.ESTextureData;
import nl.weeaboo.android.gles.ESUtil;
import nl.weeaboo.android.gui.FontManager;
import nl.weeaboo.android.gui.ShadowSpan;
import nl.weeaboo.android.gui.TextLayoutUtil;
import nl.weeaboo.android.gui.TextStyleParser;
import nl.weeaboo.android.vn.AndroidRenderEnv;
import nl.weeaboo.gl.tex.GLTexRect;
import nl.weeaboo.gl.tex.GLWritableTexture;
import nl.weeaboo.gl.tex.ITextureData;
import nl.weeaboo.lua2.io.LuaSerializable;
import nl.weeaboo.styledtext.MutableStyledText;
import nl.weeaboo.styledtext.StyledText;
import nl.weeaboo.styledtext.TextAttribute;
import nl.weeaboo.styledtext.TextStyle;
import nl.weeaboo.vn.BlendMode;
import nl.weeaboo.vn.ITexture;
import nl.weeaboo.vn.impl.base.TextureTextRenderer;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.text.Layout;
import android.text.Layout.Alignment;
import android.text.SpannableString;
import android.text.TextPaint;
import android.text.style.CharacterStyle;
import android.text.style.ForegroundColorSpan;
import android.util.Log;

@LuaSerializable
public class TextureTR extends TextureTextRenderer<Layout> {

	private static final long serialVersionUID = AndroidImpl.serialVersionUID;
	
	private static final String TAG = "TextureTR";
	private static final CharacterStyle INVISIBLE_FOREGROUND = new ForegroundColorSpan(0);
	private static final CharacterStyle INVISIBLE_SHADOW = new ShadowSpan(0, 0, 0);
	private static final int BOTTOM_PAD = 2;
	
	private final ImageFactory imgfac;
	
	private BlendMode blendMode;
	private int backgroundARGB;
	
	private transient StyledText layoutText;
	private transient Bitmap tempBitmap;
	private transient Canvas tempCanvas;
	private transient float[] lineWidth;
	private transient int visibleCharsInLayout;
	
	public TextureTR(ImageFactory imgfac) {
		super(false); //Coordinate rounding of all rendered quads is done on a global level.
		
		this.imgfac = imgfac;
		
		blendMode = BlendMode.DEFAULT;
	}
	
	@Override
	public float increaseVisibleChars(float textSpeed) {
		float off = getCharOffset(getStartLine());
		float pos0 = off + getVisibleChars();
		float pos = Math.max(0, pos0);
		float inc = textSpeed;
		while (inc > 0.001) {
			int itextPos = (int)pos;
			float fracLeft = (itextPos + 1) - pos;
			float charDuration = 1f;			

			TextStyle style = layoutText.getStyle(itextPos);			
			if (style != null && style.hasProperty(TextAttribute.speed)) {
				charDuration = 1f / style.getSpeed();
			}
	
			if (fracLeft >= 1f && inc >= charDuration) {
				pos = itextPos + 1;
				inc -= charDuration;
			} else {
				//System.out.println(textPos + " " + fracLeft + " | " +  (inc / charDuration) + " " + inc + " " + charDuration);
				pos += Math.min(fracLeft, inc / charDuration);
				inc -= fracLeft * charDuration;
			}
		}
		
		setVisibleText(getStartLine(), pos - off);
		return pos - pos0;
	}
	
	@Override
	protected void destroyTexture(ITexture texture) {
		TextureAdapter ta = (TextureAdapter)texture;
		GLTexRect tr = ta.getTexRect();
		if (tr == null) return;
		
		GLWritableTexture inner = (GLWritableTexture)tr.getTexture();
		if (inner == null) return;
		
		inner.glUnload();
		ITextureData tdata = inner.peekPixels();
		inner.setPixels(null);
		if (tdata instanceof ESTextureData) {
			ESTextureData esdata = (ESTextureData)tdata;
			esdata.disposeBitmap();
		}
	}

	@Override
	protected ITexture createTexture(int w, int h, float sx, float sy) {
		return imgfac.createTexture(null, w, h, sx, sy);
	}
	
	private void setCanvas(Canvas canvas, Bitmap bitmap) {
		tempCanvas = canvas;
		if (tempBitmap != null && tempBitmap != bitmap) {
			tempBitmap.recycle();
		}
		tempBitmap = bitmap;
	}
	
	private void initTempImage(int w, int h) {
		final int bgAlpha = (backgroundARGB>>>24);
		final int bgColor = (backgroundARGB&0xFFFFFF);
		final boolean opaque = (bgAlpha == 255 || blendMode == BlendMode.OPAQUE);
		Bitmap.Config config = Bitmap.Config.ARGB_8888;
		if (opaque) {
			config = Bitmap.Config.RGB_565;
		}
		
		if (tempBitmap == null || tempBitmap.getWidth() != w || tempBitmap.getHeight() != h
				|| config != tempBitmap.getConfig())
		{
			Log.d(TAG, "Create TextureTR bitmap (" + w + "x" + h + ")");
			
			Bitmap bitmap = ESUtil.createCompatibleBitmap(imgfac.getGLInfo(), w, h, config);
	        Canvas canvas = new Canvas(bitmap);
	        if (opaque && bgColor != 0) {
	        	bitmap.eraseColor(backgroundARGB);
	        }
	        
	        setCanvas(canvas, bitmap);
		} else {
			tempBitmap.eraseColor(opaque ? backgroundARGB : 0);
		}
	}
	
	@Override
	protected void renderLayoutToTexture(Layout layout, ITexture tex) {
		int vc = (int)Math.round(getVisibleChars());
		if (visibleCharsInLayout != vc) {
			visibleCharsInLayout = vc;
			updateLayout(vc);
		}
		
		TextureAdapter ta = (TextureAdapter)tex;
		GLWritableTexture inner = (GLWritableTexture)ta.getTexRect().getTexture();
		final int tw = inner.getTexWidth();
		final int th = inner.getTexHeight();
		initTempImage(tw, th);
		
		int sl = getStartLine();
		int el = getEndLine();
		int tx = getTranslateX(sl, el);
		int ty = getTranslateY(sl);		
		//Clip rect height determines which lines are drawn in Layout.draw()
		int lh = Math.max(0, layout.getLineTop(el) - layout.getLineTop(sl));		
		
		if (tempCanvas == null) {
			return; //This should never happen
		}
		
		tempCanvas.save();
		tempCanvas.clipRect(new Rect(0, 0, tw, lh));
		tempCanvas.translate(tx, ty);
		
		/*tempBitmap.eraseColor(0);
		Paint paint = new Paint();
		paint.setColor(0xFFFF0000);
		tempCanvas.drawRect(0, 0, getLayoutWidth(), lh, paint);*/
		
		layout.draw(tempCanvas);
		tempCanvas.restore();
		
		inner.setPixels(imgfac.createTextureData(tempBitmap, true));
		
		//System.out.printf("layout=%dx%d, startLine=%d, endLine=%d, ty=%d, lh=%d\n", layout.getWidth(), layout.getHeight(), getStartLine(), getEndLine(), ty, lh);		
	}
		
	protected void updateLayout(int visibleChars) {
		//Second pass to generate fade-in styles
		final Layout layout = getLayout();
		
		CharSequence text = layout.getText();
		SpannableString stext = (SpannableString)text;
		int length = stext.length();
		
		int start = getCharOffset(getStartLine());
		int end   = (visibleChars >= 0 ? start + visibleChars : length);
					
		//Remove previous invisibility spans (call removeSpan() once per span to remove)
		stext.removeSpan(INVISIBLE_FOREGROUND);
		stext.removeSpan(INVISIBLE_FOREGROUND);
		
		stext.removeSpan(INVISIBLE_SHADOW);
		stext.removeSpan(INVISIBLE_SHADOW);

		//Apply new spans
		if (start > 0) {
			stext.setSpan(INVISIBLE_FOREGROUND, 0, start, 0);			
			stext.setSpan(INVISIBLE_SHADOW, 0, start, 0);
		}
		if (end < length) {
			stext.setSpan(INVISIBLE_FOREGROUND, end, length, 0);			
			stext.setSpan(INVISIBLE_SHADOW, end, length, 0);
		}

		//I don't think we need to create a new layout object. No layout-related properties were changed.
		//layout = TextLayout.doLayout(stext, layout.getWidth(), layout.getPaint(), layout.getAlignment());			
	}	
	
	@Override
	protected Layout createLayout(float width, float height) {
		lineWidth = null;
		visibleCharsInLayout = -1;

		AndroidRenderEnv env = (AndroidRenderEnv)getRenderEnv();
		final int iwidth = (int)Math.floor(width);
		final float textSize = (env != null ? env.textSize : 1f);
		final float displayDensity = (env != null ? env.displayDensity : 1f);
		
		StyledText text = getText();
		MutableStyledText stext;
		if (text.length() > 8192) {
			//Prevent out-of-memory errors
			stext = text.substring(0, 8192).mutableCopy();
		} else {
			stext = text.mutableCopy();
		}
		
		//Make all styles extend the defaultStyle
		TextStyle lastSourceStyle = null;
		TextStyle lastDestStyle = null;
		
		TextStyle defaultStyle = imgfac.getDefaultStyle().extend(getDefaultStyle());		
		for (int n = 0; n < stext.length(); n++) {
			TextStyle curStyle = stext.getStyle(n);
			TextStyle newStyle;
			if (curStyle == lastSourceStyle && lastDestStyle != null) {
				newStyle = lastDestStyle;
			} else {
				newStyle = defaultStyle.extend(curStyle);
			}
			
			lastSourceStyle = curStyle;
			lastDestStyle = newStyle;
			stext.setStyle(newStyle, n);
		}
		
		FontManager fontManager = imgfac.getFontManager();
		layoutText = stext.immutableCopy();
		SpannableString styled = TextStyleParser.toSpannableString(fontManager, layoutText);
		
		TextPaint paint = TextLayoutUtil.getTextPaint(displayDensity);
		paint.setColor(0xFFFFFFFF);
		paint.setTextSize(textSize * paint.getTextSize());
		
		return TextLayoutUtil.doLayout(styled, iwidth, paint, Alignment.ALIGN_NORMAL);
	}
			
	@Override
	public int getEndLine() {
		final Layout layout = getLayout();
		final int lineCount = layout.getLineCount();
		if (lineCount == 0) {
			return 0;
		}
		
		final int startLine = Math.max(0, Math.min(lineCount, getStartLine()));		
		final int iheight = getLayoutMaxHeight();
		final int startTop = -getTranslateY(startLine);
		final int bottom = startTop + iheight - BOTTOM_PAD;
		
		int endLine = startLine;
		while (endLine < lineCount && layout.getLineBottom(endLine) <= bottom) {
			endLine++;
		}
		//System.out.println(startLine + " " + endLine + " " + lineCount + " " + startTop + " " + iheight + " " + bottom);
		return Math.max(startLine+1, endLine); 
	}
	
	@Override
	public int getLineCount() {
		Layout layout = getLayout();
		return layout.getLineCount();
	}
			
	@Override
	public int getCharOffset(int line) {
		Layout layout = getLayout();
		return layout.getLineStart(Math.max(0, Math.min(layout.getLineCount(), line)));			
	}
	
	private int getTranslateX(int startLine, int endLine) {
		return Math.round(-getLayoutLeading(startLine, endLine));		
	}
	
	private int getTranslateY(int startLine) {
		Layout layout = getLayout();
		startLine = Math.max(0, Math.min(getLineCount(), startLine));
		return (startLine == 0 ? layout.getTopPadding() : -layout.getLineTop(startLine));	
	}
	
	@Override
	protected float getLayoutLeading(int line) {
		Layout layout = getLayout();		
		return isRightToLeft() ? layout.getWidth()-getLayoutWidth(line) : layout.getLineLeft(line);
	}

	@Override
	protected float getLayoutTrailing(int line) {
		Layout layout = getLayout();		
		return isRightToLeft() ? layout.getLineLeft(line) : layout.getWidth()-getLayoutWidth(line);
	}
	
	@Override
	public float getLayoutWidth(int line) {
		Layout layout = getLayout();
		if (lineWidth == null) {
			//Layout.getLineMax() does some fairly complex calculations -- do manual caching.
			lineWidth = new float[layout.getLineCount()];
			Arrays.fill(lineWidth, -1);
		}
		if (lineWidth[line] < 0) {
			lineWidth[line] = layout.getLineMax(line) + layout.getLineLeft(line);
		}
		return lineWidth[line];
	}
		
	@Override
	public float getLayoutHeight(int startLine, int endLine) {
		Layout layout = getLayout();		
		endLine = Math.min(layout.getLineCount(), endLine);

		int top = -getTranslateY(startLine);
		int bottom = BOTTOM_PAD;
		if (endLine > 0) {
			bottom += layout.getLineBottom(endLine-1);
		}
		return bottom - top;
	}
		
	@Override
	public int[] getHitTags(float cx, float cy) {
		if (cy < 0) {
			return null;
		}
		
		Layout layout = getLayout();
		if (layoutText == null) {
			return null;
		}
				
		float displayScale = getDisplayScale();
		cx *= displayScale;
		cy *= displayScale;		
		int line = getStartLine();
		int el = getEndLine();
		int tx = getTranslateX(line, el);
		int ty = getTranslateY(line);
		
		while (line < el) {
			if (ty + cy < layout.getLineBottom(line)) {
				break;
			}
			line++;
		}
		if (line >= el) {
			return null;
		}
		
		int index = layout.getOffsetForHorizontal(line, tx + cx);
		if (index < 0 || index >= layoutText.length()) {
			return null;
		}
		
		TextStyle style = layoutText.getStyle(index);
		if (style == null) {
			return null;
		}
		return style.getTags();
	}
	
	public void setBlendMode(BlendMode bm) {
		if (blendMode != bm) {
			blendMode = bm;
			
			if (blendMode == BlendMode.OPAQUE || bm == BlendMode.OPAQUE) {
				invalidateTextureContents();
			}
		}
	}
	
	public void setBackgroundColor(int argb) {
		if (backgroundARGB != argb) {		
			int oldAlpha = (backgroundARGB>>>24);			

			backgroundARGB = argb;
			
			int alpha = (argb>>>24);
			if ((oldAlpha == 0xFF) != (alpha == 0xFF) || alpha == 255 || blendMode == BlendMode.OPAQUE) {
				invalidateTextureContents();
			}
		}
	}
	
}

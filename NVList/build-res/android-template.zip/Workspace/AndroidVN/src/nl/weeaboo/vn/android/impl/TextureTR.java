package nl.weeaboo.vn.android.impl;

import java.util.Arrays;

import javax.microedition.khronos.opengles.GL;

import nl.weeaboo.android.gl.GLDraw;
import nl.weeaboo.android.gl.GLGeneratedTexture;
import nl.weeaboo.android.gl.GLTexture;
import nl.weeaboo.android.gui.FontManager;
import nl.weeaboo.android.gui.ShadowSpan;
import nl.weeaboo.android.gui.TextLayoutUtil;
import nl.weeaboo.android.gui.TextStyleParser;
import nl.weeaboo.android.vn.AndroidRenderEnv;
import nl.weeaboo.lua2.io.LuaSerializable;
import nl.weeaboo.styledtext.MutableStyledText;
import nl.weeaboo.styledtext.StyledText;
import nl.weeaboo.styledtext.TextStyle;
import nl.weeaboo.vn.BlendMode;
import nl.weeaboo.vn.ITexture;
import nl.weeaboo.vn.impl.base.TextureTextRenderer;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.text.Layout;
import android.text.Layout.Alignment;
import android.text.SpannableString;
import android.text.TextPaint;
import android.text.style.CharacterStyle;
import android.text.style.ForegroundColorSpan;

@LuaSerializable
public class TextureTR extends TextureTextRenderer<Layout> {

	private static final long serialVersionUID = AndroidImpl.serialVersionUID;
	
	private static final CharacterStyle INVISIBLE_FOREGROUND = new ForegroundColorSpan(0);
	private static final CharacterStyle INVISIBLE_SHADOW = new ShadowSpan(0, 0, 0);
	private static final int BOTTOM_PAD = 2;
	
	private final ImageFactory imgfac;
	
	private BlendMode blendMode;
	private int backgroundARGB;
	
	private transient Bitmap tempBitmap;
	private transient Canvas tempCanvas;
	private transient float[] lineWidth;
	private transient int visibleCharsInLayout;
	
	public TextureTR(ImageFactory imgfac) {
		super(false); //Coordinate rounding of all rendered quads is done on a global level.
		
		this.imgfac = imgfac;
		
		blendMode = BlendMode.DEFAULT;
	}
	
	@Override
	protected void destroyTexture(ITexture texture) {
		//Can't manually dispose GLTexRect, must wait for GC
		TextureAdapter ta = (TextureAdapter)texture;
		GLTexture inner = ta.getTexRect().getTexture();
		inner.disposePixels();
		inner.dispose();
	}

	@Override
	protected ITexture createTexture(int w, int h, float sx, float sy) {
		GLGeneratedTexture inner = imgfac.createGLTexture(null, w, h);
		return imgfac.createTexture(inner.getTexRect(0), sx, sy);
	}
	
	private void initTempImage(GL gl, int w, int h) {
		final int bgAlpha = (backgroundARGB>>>24);
		final int bgColor = (backgroundARGB&0xFFFFFF);
		final boolean opaque = (bgAlpha == 255 || blendMode == BlendMode.OPAQUE);
		Bitmap.Config config = Bitmap.Config.ARGB_8888;
		if (opaque) {
			config = Bitmap.Config.RGB_565;
		}
		
		if (tempBitmap == null || tempBitmap.getWidth() != w || tempBitmap.getHeight() != h
				|| config != tempBitmap.getConfig())
		{
			if (tempBitmap != null) {
				tempBitmap.recycle();
			}
			
			tempBitmap = GLDraw.createCompatibleBitmap(gl, w, h, config);
	        tempCanvas = new Canvas(tempBitmap);
	        if (opaque && bgColor != 0) {
	        	tempBitmap.eraseColor(backgroundARGB);
	        }
		} else {
			tempBitmap.eraseColor(opaque ? backgroundARGB : 0);
		}
	}
	
	@Override
	protected void renderLayoutToTexture(Layout layout, ITexture tex) {
		int vc = (int)Math.round(getVisibleChars());
		if (visibleCharsInLayout != vc) {
			visibleCharsInLayout = vc;
			updateLayout(vc);
		}
		
		TextureAdapter ta = (TextureAdapter)tex;
		GLTexture inner = ta.getTexRect().getTexture();
		final int tw = inner.getTexWidth();
		final int th = inner.getTexHeight();
		initTempImage(null, tw, th);
		
		int sl = getStartLine();
		int el = getEndLine();
		int tx = Math.round(-getLayoutLeading(sl, el));
		int ty = getTranslateY(sl);		
		//Clip rect height determines which lines are drawn in Layout.draw()
		int lh = Math.max(0, layout.getLineTop(el) - layout.getLineTop(sl));		
		
		tempCanvas.save();
		tempCanvas.clipRect(new Rect(0, 0, tw, lh));
		tempCanvas.translate(tx, ty);
		layout.draw(tempCanvas);
		tempCanvas.restore();
		
		inner.setPixels(null, tempBitmap);
		
		//System.out.printf("layout=%dx%d, startLine=%d, endLine=%d, ty=%d, lh=%d\n", layout.getWidth(), layout.getHeight(), getStartLine(), getEndLine(), ty, lh);		
	}
		
	protected void updateLayout(int visibleChars) {
		//Second pass to generate fade-in styles
		final Layout layout = getLayout();
		
		CharSequence text = layout.getText();
		SpannableString stext = (SpannableString)text;
		int length = stext.length();
		
		int start = getCharOffset(getStartLine());
		int end   = (visibleChars >= 0 ? start + visibleChars : length);
					
		//Remove previous invisibility spans (call removeSpan() once per span to remove)
		stext.removeSpan(INVISIBLE_FOREGROUND);
		stext.removeSpan(INVISIBLE_FOREGROUND);
		
		stext.removeSpan(INVISIBLE_SHADOW);
		stext.removeSpan(INVISIBLE_SHADOW);

		//Apply new spans
		if (start > 0) {
			stext.setSpan(INVISIBLE_FOREGROUND, 0, start, 0);			
			stext.setSpan(INVISIBLE_SHADOW, 0, start, 0);
		}
		if (end < length) {
			stext.setSpan(INVISIBLE_FOREGROUND, end, length, 0);			
			stext.setSpan(INVISIBLE_SHADOW, end, length, 0);
		}

		//I don't think we need to create a new layout object. No layout-related properties were changed.
		//layout = TextLayout.doLayout(stext, layout.getWidth(), layout.getPaint(), layout.getAlignment());			
	}	
	
	@Override
	protected Layout createLayout(float width, float height) {
		lineWidth = null;
		visibleCharsInLayout = -1;

		AndroidRenderEnv env = (AndroidRenderEnv)getRenderEnv();
		final int iwidth = (int)Math.floor(width);
		final float textSize = (env != null ? env.textSize : 1f);
		final float displayDensity = (env != null ? env.displayDensity : 1f);
		
		StyledText text = getText();
		MutableStyledText stext;
		if (text.length() > 8192) {
			//Prevent out-of-memory errors
			stext = text.substring(0, 8192).mutableCopy();
		} else {
			stext = text.mutableCopy();
		}
		
		//Make all styles extend the defaultStyle
		TextStyle lastSourceStyle = null;
		TextStyle lastDestStyle = null;
		
		TextStyle defaultStyle = imgfac.getDefaultStyle().extend(getDefaultStyle());
		for (int n = 0; n < stext.length(); n++) {
			TextStyle curStyle = stext.getStyle(n);
			TextStyle newStyle;
			if (curStyle == lastSourceStyle && lastDestStyle != null) {
				newStyle = lastDestStyle;
			} else {
				newStyle = defaultStyle.extend(curStyle);
			}
			
			lastSourceStyle = curStyle;
			lastDestStyle = newStyle;
			stext.setStyle(newStyle, n);
		}
		
		FontManager fontManager = imgfac.getFontManager();
		SpannableString styled = TextStyleParser.toSpannableString(fontManager, stext.immutableCopy());
		
		TextPaint paint = TextLayoutUtil.getTextPaint(displayDensity);
		paint.setColor(0xFFFFFFFF);
		paint.setTextSize(textSize * paint.getTextSize());
		
		return TextLayoutUtil.doLayout(styled, iwidth, paint, Alignment.ALIGN_NORMAL);
	}
			
	@Override
	public int getEndLine() {
		final Layout layout = getLayout();
		final int lineCount = layout.getLineCount();
		if (lineCount == 0) {
			return 0;
		}
		
		final int startLine = Math.max(0, Math.min(lineCount, getStartLine()));		
		final int iheight = getLayoutMaxHeight();
		final int startTop = -getTranslateY(startLine);
		final int bottom = startTop + iheight - BOTTOM_PAD;
		
		int endLine = startLine;
		while (endLine < lineCount && layout.getLineBottom(endLine) <= bottom) {
			endLine++;
		}
		//System.out.println(startLine + " " + endLine + " " + lineCount + " " + startTop + " " + iheight + " " + bottom);
		return Math.max(startLine+1, endLine); 
	}
	
	@Override
	public int getLineCount() {
		Layout layout = getLayout();
		return layout.getLineCount();
	}
			
	@Override
	public int getCharOffset(int line) {
		Layout layout = getLayout();
		return layout.getLineStart(Math.max(0, Math.min(layout.getLineCount(), line)));			
	}
	
	private int getTranslateY(int startLine) {
		Layout layout = getLayout();
		startLine = Math.max(0, Math.min(getLineCount(), startLine));
		return (startLine == 0 ? layout.getTopPadding() : -layout.getLineTop(startLine));	
	}
	
	@Override
	protected float getLayoutLeading(int line) {
		Layout layout = getLayout();		
		return isRightToLeft() ? layout.getLineWidth(line)-getLayoutWidth(line) : layout.getLineLeft(line);
	}

	@Override
	protected float getLayoutTrailing(int line) {
		Layout layout = getLayout();		
		return isRightToLeft() ? layout.getLineLeft(line) : layout.getLineWidth(line)-getLayoutWidth(line);
	}
	
	@Override
	public float getLayoutWidth(int line) {
		Layout layout = getLayout();
		if (lineWidth == null) {
			//Layout.getLineMax() does some fairly complex calculations. Use lineMax array for manual caching.
			lineWidth = new float[layout.getLineCount()];
			Arrays.fill(lineWidth, -1);
		}
		if (lineWidth[line] < 0) {
			lineWidth[line] = layout.getLineMax(line) - layout.getLineLeft(line);
		}
		return lineWidth[line];
	}
		
	@Override
	public float getLayoutHeight(int startLine, int endLine) {
		Layout layout = getLayout();		
		endLine = Math.min(layout.getLineCount(), endLine);

		int top = -getTranslateY(startLine);
		int bottom = BOTTOM_PAD;
		if (endLine > 0) {
			bottom += layout.getLineBottom(endLine-1);
		}
		return bottom - top;
	}
		
	@Override
	public int[] getHitTags(float cx, float cy) {
		// TODO Auto-generated method stub
		return null;
	}
	
	public void setBlendMode(BlendMode bm) {
		if (blendMode != bm) {
			blendMode = bm;
			
			if (blendMode == BlendMode.OPAQUE || bm == BlendMode.OPAQUE) {
				invalidateTextureContents();
			}
		}
	}
	
	public void setBackgroundColor(int argb) {
		if (backgroundARGB != argb) {		
			int oldAlpha = (backgroundARGB>>>24);			

			backgroundARGB = argb;
			
			int alpha = (argb>>>24);
			if ((oldAlpha == 0xFF) != (alpha == 0xFF) || alpha == 255 || blendMode == BlendMode.OPAQUE) {
				invalidateTextureContents();
			}
		}
	}
	
}

package nl.weeaboo.vn.android.impl;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import nl.weeaboo.android.vn.AndroidVN;
import nl.weeaboo.lua2.io.LuaSerializable;
import nl.weeaboo.vn.impl.base.BaseChoice;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.os.Handler;

@LuaSerializable
public class ChoiceView extends BaseChoice {

	private static final long serialVersionUID = AndroidImpl.serialVersionUID;
	
	public ChoiceView(final AndroidVN context, Handler handler, final String[] opts) {
		super(opts);

		handler.post(new Runnable() {
			public void run() {
				context.onWindowFocusChanged(false);
				
				AlertDialog.Builder b = new AlertDialog.Builder(context);
				b.setItems(opts, new Dialog.OnClickListener() {
					public void onClick(DialogInterface dialog, int which) {
						setSelected(which);
					}
				});
				b.setOnCancelListener(new OnCancelListener() {
					public void onCancel(DialogInterface dialog) {
						cancel();
					}
				});
				b.show();		
			}
		});
	}
	
	//Functions
	private void writeObject(ObjectOutputStream out) throws IOException {
		out.defaultWriteObject();
	}
	
	private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
		in.defaultReadObject();
		
		cancel(); //Persisted object has no active popup.
	}
	
	//Getters
	
	//Setters
	
}

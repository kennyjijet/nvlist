package nl.weeaboo.vn.android.impl;

import nl.weeaboo.lua2.io.LuaSerializable;
import nl.weeaboo.vn.impl.base.BaseSoundState;

@LuaSerializable
public class SoundState extends BaseSoundState {

	private static final long serialVersionUID = AndroidImpl.serialVersionUID;

	public SoundState() {		
	}
	
	//Functions
	
	//Getters
	
	//Setters
	
}

package nl.weeaboo.android.vn;

import static nl.weeaboo.android.AndroidUtil.cancelTask;
import static nl.weeaboo.android.AndroidUtil.isTaskRunning;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.Map;
import java.util.TreeMap;

import nl.weeaboo.android.gl.Screenshot;
import nl.weeaboo.android.gui.ProgressAsyncTask;
import nl.weeaboo.io.StreamUtil;
import nl.weeaboo.vn.ISaveHandler;
import nl.weeaboo.vn.ISaveInfo;
import nl.weeaboo.vn.IScreenshot;
import nl.weeaboo.vn.android.impl.JpegDecodingScreenshot;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.view.ContextMenu;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.AdapterContextMenuInfo;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.ToggleButton;

public class SaveLoadActivity extends Activity {

	private static final int ITEMS_PER_PAGE = 10;
	private static final int PAGE_MIN = 1;
	private static final int PAGE_MAX = 10;
	
	public static Game game;
	
	private Handler handler;
	private SharedPreferences prefs;
	private boolean isSave;
	private Drawable defaultIcon;
	private Drawable newSlotIcon;
	private IScreenshot screenshot;
	private File screenshotF;
	
	private GridView saveList;
	private SaveItemAdapter saveItemAdapter;	
	private boolean isGridLayout;
	private int page;
	
	private ProgressAsyncTask<Void, SaveItem[]> getSaveItemsTask;
	private SaveLoadTask saveloadTask;
	
	//Functions
	public void onCreate(Bundle savedBundle) {
		super.onCreate(savedBundle);
				
		handler = new Handler();		
		
		prefs = PreferenceManager.getDefaultSharedPreferences(this);				
		isGridLayout = prefs.getBoolean(getString(R.string.pref_saveload_view), true);
		page = prefs.getInt(getString(R.string.pref_saveload_page), PAGE_MIN);
		
		Intent intent = getIntent();
		isSave = intent.getBooleanExtra("save", false);
		String screenshotPath = intent.getStringExtra("screenshot");
		if (screenshotPath != null) {
			screenshotF = new File(screenshotPath);
		} else {
			screenshotF = new File(getFilesDir(), "~ss.jpg");
		}
		
		try {
			FileInputStream fin = new FileInputStream(screenshotF);
			try {
				ByteBuffer b = ByteBuffer.wrap(StreamUtil.readFully(fin));
				screenshot = new JpegDecodingScreenshot(b, 1);
			} finally {
				fin.close();
			}
		} catch (IOException ioe) {
			//Ignore
		}
		
		Resources res = getResources();
		defaultIcon = res.getDrawable(R.drawable.noimage);
		newSlotIcon = res.getDrawable(R.drawable.newslot);
		
		setTitle(R.string.saveload_title);		
		setContentView(R.layout.saveload);
		
		saveList = (GridView)findViewById(R.id.saveSlotList);
		saveList.setEmptyView(findViewById(android.R.id.empty));
		saveList.setOnItemClickListener(new OnItemClickListener() {
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
				onOKPressed((SaveItem)saveList.getItemAtPosition(position));
			}
		});
				
		saveItemAdapter = new SaveItemAdapter();
		saveList.setAdapter(saveItemAdapter);
		
		registerForContextMenu(saveList);
		
		onLayoutChanged();
	}

	@Override
	public void onDestroy() {
		cancelTask(getSaveItemsTask);
		getSaveItemsTask = null;
		cancelTask(saveloadTask);
		saveloadTask = null;
		
		Editor editor = prefs.edit();
		editor.putBoolean(getString(R.string.pref_saveload_view), isGridLayout);
		editor.putInt(getString(R.string.pref_saveload_page), page);
		editor.commit(); //Ignore failure
		
		super.onDestroy();
		
		//game = null;
	}
	
	@Override
	public void onResume() {
		super.onResume();
		
		refresh();		
	}
	
	@Override
	public void onPause() {				
		cancelTask(getSaveItemsTask);
		getSaveItemsTask = null;
		cancelTask(saveloadTask);
		saveloadTask = null;
		
		super.onPause();		
	}
	
	private void onLayoutChanged() {
		saveItemAdapter.clear();
		
		if (isGridLayout) {
			saveList.setNumColumns(-1);
		} else {
			saveList.setNumColumns(1);
		}

		ToggleButton gridButton = (ToggleButton)findViewById(R.id.saveloadGridView);
		if (gridButton != null) {
			gridButton.setChecked(isGridLayout);
			gridButton.setEnabled(!isGridLayout);
		}
		ToggleButton listButton = (ToggleButton)findViewById(R.id.saveloadListView);
		if (listButton != null) {
			listButton.setChecked(!isGridLayout);
			listButton.setEnabled(isGridLayout);
		}		
		
		saveItemAdapter.discardConvertView();

		refresh();
	}
	
	protected void refresh() {
		if (isTaskRunning(getSaveItemsTask)) {
			return;
		}
		
		Resources res = getResources();
		int titleRes = (isSave ? R.string.saveload_title_save : R.string.saveload_title_load);
		setTitle(res.getString(titleRes, page));
		
		View prevButton = findViewById(R.id.saveloadPrevPage);
		if (prevButton != null) prevButton.setEnabled(page > PAGE_MIN);
		View nextButton = findViewById(R.id.saveloadNextPage);
		if (nextButton != null) nextButton.setEnabled(page < PAGE_MAX);
				
		final int pageMin = 1 + (page - 1) * ITEMS_PER_PAGE;
		final int pageMax = 1 + (page    ) * ITEMS_PER_PAGE;
		
		String msg = res.getString(R.string.dialog_refresh_novel_list_message);
		getSaveItemsTask = new ProgressAsyncTask<Void, SaveItem[]>(this, handler, msg) {
			@Override
			protected SaveItem[] doInBackground(Void... params) {
				final Game g = game;
				if (g == null) {
					return new SaveItem[0];
				}
				
				synchronized (g) {
					ISaveHandler sh = g.getNovel().getSaveHandler();
					
					Map<Integer, SaveItem> saves = new TreeMap<Integer, SaveItem>();
					for (ISaveInfo info : sh.getSaves(pageMin, pageMax)) {
						if (isCancelled()) return null;

						SaveItem item = new SaveItem(info.getSlot(), info.getTitle(),
								info.getLabel(), info.getTimestamp(), false);
						
						IScreenshot s = info.getScreenshot();
						if (s instanceof Screenshot) {
							Screenshot ss = (Screenshot)s;
							item.icon = ss.toBitmap();
						} else if (s != null && !s.isCancelled()) {
							int argb[] = s.getARGB();
							int w = s.getWidth();
							int h = s.getHeight();
							if (argb != null && w > 0 && h > 0) {
								item.icon = Bitmap.createBitmap(argb, w, h, Config.RGB_565);
							}
						}
						
						saves.put(item.slot, item);
					}
					
					if (isSave) {
						long time = System.currentTimeMillis();
						for (int slot = pageMin; slot < pageMax; slot++) {
							if (!saves.containsKey(slot)) {
								String title = String.format("empty %d", slot);
								SaveItem free = new SaveItem(slot, title, title, time, true);
								saves.put(slot, free);
							}
						}
					}
					
					return saves.values().toArray(new SaveItem[saves.size()]);
				}
			}

			@Override
			protected void onPostExecute(SaveItem result[]) {
				getSaveItemsTask = null;
				
				saveItemAdapter.clear();
				if (result != null) {
					for (SaveItem item : result) {
						saveItemAdapter.add(item);
					}
				}

				super.onPostExecute(result);				
			}
		};
		getSaveItemsTask.setShowDelay(500);
		getSaveItemsTask.execute();
	}
	
	public void onOKPressed(SaveItem item) {
		if (item == null || isTaskRunning(saveloadTask)) {
			return;
		}
		
		synchronized (game) {
			if (isSave) {
				saveloadTask = SaveLoadTask.createSaveTask(this, game, handler, null, screenshot);
			} else {
				saveloadTask = SaveLoadTask.createLoadTask(this, game, handler);
			}
		}
		saveloadTask.execute(item.slot);
		
		saveloadTask.setOnPostExecuteListener(new Runnable() {
			public void run() {
				saveloadTask = null;
				
				finish();
			}
		});		
	}
		
	@Override
	public void onCreateContextMenu(ContextMenu menu, View v, ContextMenuInfo menuInfo) {
		super.onCreateContextMenu(menu, v, menuInfo);
		
		if (v == saveList) {
			AdapterContextMenuInfo info = (AdapterContextMenuInfo)menuInfo;
			SaveItem saveItem = (SaveItem)saveList.getItemAtPosition(info.position);
			if (saveItem != null && !saveItem.isFree) {				
				MenuInflater inflater = getMenuInflater();
				inflater.inflate(R.menu.saveslot, menu);
			}
		}
	}
	
	@Override
	public boolean onContextItemSelected(MenuItem item) {
		AdapterContextMenuInfo info = (AdapterContextMenuInfo)item.getMenuInfo();
		SaveItem saveItem = (SaveItem)saveList.getItemAtPosition(info.position);
		
		final int id = item.getItemId();
		if (id == R.id.deleteItem) {
			deleteItem(saveItem);
			return true;
		} else {
			return super.onContextItemSelected(item);
		}
	}
	
	protected void deleteItem(SaveItem info) {
		synchronized (game) {
			try {
				ISaveHandler sh = game.getNovel().getSaveHandler();
				sh.delete(info.slot);
			} catch (IOException e) {
				//Ignore
			}
		}
		
		refresh();
	}
	
	public void onViewPressed(final View view) {		
		if (view.getId() == R.id.saveloadListView) {
			isGridLayout = false;
		} else {
			isGridLayout = true;
		}
		
		onLayoutChanged();
	}
	
	public void onPagePressed(final View view) {
		setPage(view.getId() == R.id.saveloadPrevPage ? page-1 : page+1);		
	}
	
	//Getters
	
	//Setters
	public void setPage(int p) {
		if (page != p && p >= PAGE_MIN && p <= PAGE_MAX) {
			page = p;
						
			refresh();
		}
	}
	
	//Inner Classes
	protected static class SaveItem {

		public final int slot;
		public final String title;
		public final String label;
		public final long timestamp;
		public final boolean isFree;
		
		public Bitmap icon;
		
		public SaveItem(int slot, String title, String label, long timestamp, boolean isFree) {
			this.slot = slot;
			this.title = title;
			this.label = label;
			this.timestamp = timestamp;
			this.isFree = isFree;
		}
		
		public String toString() {
			return label;
		}
		
	}
	
	private class SaveItemAdapter extends ArrayAdapter<SaveItem> {
		
		private boolean discardConvertView;
		
		public SaveItemAdapter() {
			super(SaveLoadActivity.this, android.R.layout.simple_list_item_1);
		}
		
		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			if (convertView == null || discardConvertView) {
				int layoutId = (isGridLayout ? R.layout.saveload_grid_item : R.layout.saveload_list_item);
				convertView = getLayoutInflater().inflate(layoutId, parent, false);
				
				ViewHolder holder = new ViewHolder(
						(ImageView)convertView.findViewById(R.id.saveloadListItemImage),
						(TextView)convertView.findViewById(R.id.saveloadListItemText));
				convertView.setTag(holder);
			}

			ViewHolder holder = (ViewHolder)convertView.getTag();
			SaveItem item = getItem(position);

			TextView tview = holder.text;
			if (tview != null) {
				tview.setText(item.toString());
			}
			
			ImageView iview = holder.image;
			if (iview != null) {
				if (item.icon != null) {
					iview.setImageBitmap(item.icon);
				} else if (item.isFree) {
					iview.setImageDrawable(newSlotIcon);
				} else {
					iview.setImageDrawable(defaultIcon);
				}
			}
			
			return convertView;
		}
		
		public void discardConvertView() {
			discardConvertView = true;
			notifyDataSetChanged();
		}
			
		class ViewHolder {
			
			ImageView image;
			TextView text;
			
			public ViewHolder(ImageView i, TextView t) {
				image = i;
				text = t;
			}
		}		
	}
	
}

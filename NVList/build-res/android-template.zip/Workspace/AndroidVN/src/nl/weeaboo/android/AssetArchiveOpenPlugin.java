package nl.weeaboo.android;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import nl.weeaboo.common.StringUtil;
import nl.weeaboo.filemanager.IArchiveOpenPlugin;
import nl.weeaboo.obfuscator.IObfuscator;
import nl.weeaboo.zip.IFileArchive;
import android.content.res.AssetManager;

public class AssetArchiveOpenPlugin implements IArchiveOpenPlugin {

	private final ResourceManager rm;
	private final IObfuscator obfuscator;
	private final Set<String> obfuscatedExtensions;
	private final AssetManager assets;
	private final int versionCode;
	
	public AssetArchiveOpenPlugin(ResourceManager rm, AssetManager assets, int versionCode, IObfuscator obf) {
		this.rm = rm;
		this.assets = assets;
		this.versionCode = versionCode;
		this.obfuscator = obf;
		this.obfuscatedExtensions = new HashSet<String>(Arrays.asList("obb", "enc", "nvl"));
	}

	//Functions
	@Override
	public IFileArchive newArchive(String filename) {
		if (obfuscatedExtensions.contains(StringUtil.getExtension(filename))) {
			return new AssetZipArchive(rm, versionCode, obfuscator);
		} else {
			return new AssetZipArchive(rm, versionCode, null);
		}
	}
	
	//Functions	
	@Override
	public void openArchive(IFileArchive zip, File[] readFolders, String filename) throws IOException {
		if (filename.equals("assets")) {
			AssetZipArchive azip = (AssetZipArchive)zip;
			azip.open(assets);
			return;
		} else {		
			for (File folder : readFolders) {
				File file = new File(folder, filename);
				if (file.exists()) {
					zip.open(file);
					return;
				}
			}
		}
		
		throw new FileNotFoundException("Archive not found: " + filename);
	}
	
	//Getters
	
	//Setters

}

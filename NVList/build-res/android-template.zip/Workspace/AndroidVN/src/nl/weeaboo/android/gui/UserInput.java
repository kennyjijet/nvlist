package nl.weeaboo.android.gui;

import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

import nl.weeaboo.android.gui.InputAccumulator.TouchEvent;
import android.util.SparseIntArray;
import android.view.KeyEvent;
import android.view.MotionEvent;

public class UserInput {
	
	private final InputAccumulator inputAccum;
	
	private Set<Integer> keysPressed;
	private SparseIntArray keysHeld;

	private double touchX, touchY;
	private boolean touchPressed;
	private transient long touchPressedTime;
	private boolean touchHeld;
	private long touchHeldTime;
	private float touchScroll;
	
	private boolean enabled;
	private boolean idle;
	private long minTouchPressDelay;
	
	private transient long lastTime;
	
	public UserInput(InputAccumulator accum) {
		inputAccum = accum;
		keysPressed = new HashSet<Integer>();
		keysHeld = new SparseIntArray(); 
		enabled = true;
	}
	
	//Functions
	public void update(int dx, int dy, double scaleX, double scaleY) {
		if (lastTime == 0) {
			lastTime = System.currentTimeMillis();
		}

		long time = System.currentTimeMillis();
		int dt = (int)(time - lastTime);

		idle = true;
		synchronized (inputAccum) {
			Collection<KeyEvent> adown = inputAccum.keysDown;
			Collection<KeyEvent> aup   = inputAccum.keysUp;
			Collection<TouchEvent> ate = inputAccum.touchEvents;
			
			keysPressed.clear();
			touchPressed = false;
			touchScroll = 0;
			idle = adown.isEmpty() && aup.isEmpty() && ate.isEmpty();

			if (!adown.isEmpty()) {
				for (KeyEvent event : adown) {
					int keyCode = event.getKeyCode();
					keysPressed.add(keyCode);
					keysHeld.delete(keyCode);
				}
			}
			if (!aup.isEmpty()) {
				for (KeyEvent event : aup) {
					int keyCode = event.getKeyCode();
					keysHeld.delete(keyCode);
				}
			}			
			if (!ate.isEmpty()) {
				for (TouchEvent te : ate) {
					touchX = (te.getX() - dx) * scaleX;
					touchY = (te.getY() - dy) * scaleY;
					
					int action = te.getAction();
					if (action == MotionEvent.ACTION_DOWN) {
						touchHeld = true;
						if (checkPressDelay(time)) {
							touchPressed = true;
							touchPressedTime = time;
						}
					} else if (action == MotionEvent.ACTION_MOVE) {
						if (!touchHeld && checkPressDelay(time)) {
							touchPressed = true;
							touchPressedTime = time;
						}
						touchHeld = true;
					} else if (action == MotionEvent.ACTION_UP) {
						touchHeld = false;
					} /*else if (action == MotionEvent.ACTION_SCROLL) {
						touchScroll = getAxisValue(MotionEvent.AXIS_VSCROLL);
					}*/
				}
			}			
		
			inputAccum.clear();
		}
						
		//Increase held time
		for (int n = 0; n < keysHeld.size(); n++) {
			int key = keysHeld.keyAt(n);
			int val = keysHeld.valueAt(n);
			keysHeld.put(key, val + dt);
		}
		touchHeldTime = (touchHeld ? touchHeldTime+dt : 0);		
		lastTime = time;
	}
	
	public boolean consumeKey(int keycode) {
		if (!enabled) return false;
		
		return keysPressed.remove(Integer.valueOf(keycode));
	}
	
	public boolean consumeTouch() {
		if (!enabled) return false;

		if (touchPressed) {
			touchPressed = false;
			return true;
		}
		return false;
	}

	public void clear() {
		keysPressed.clear();
		keysHeld.clear();
		
		touchPressed = false;
		touchPressedTime = 0;
		touchHeldTime = 0;
		
		lastTime = System.currentTimeMillis();
	}
	
	protected boolean checkPressDelay(long timeMillis) {
		boolean result = timeMillis - touchPressedTime >= minTouchPressDelay;
		if (!result) {
			//Log.v("UserInput", "Double-press blocked by filter");
		}
		return result;
	}
	
	//Getters
	public boolean isKeyHeld(int keycode) {
		if (!enabled || keysHeld.size() == 0) return false;
		
		return keysHeld.get(keycode) > 0;
	}
	public long getKeyHeldTime(int keycode) {
		if (!enabled || keysHeld.size() == 0) return 0L;

		return keysHeld.get(keycode);
	}
	
	public boolean isKeyPressed(int keycode) {
		if (!enabled || keysPressed.isEmpty()) return false;

		return keysPressed.contains(keycode);
	}

	public double getTouchX() {
		return touchX;
	}

	public double getTouchY() {
		return touchY;
	}
	
	public boolean isTouchPressed() {
		if (!enabled) return false;

		return touchPressed;
	}
	public boolean isTouchHeld() {
		return touchHeld;
	}
	public long getTouchHeldTime() {
		return touchHeldTime;
	}
	public float getTouchScroll() {
		return touchScroll;
	}
	
	public boolean isEnabled() {
		return enabled;
	}
	
	public boolean isIdle() {
		return idle;
	}
		
	//Setters
	public void setEnabled(boolean e) {
		enabled = e;
	}
	
	/**
	 * Sets the minimum allowed delay between two press events. Press events
	 * within the delay are ignored.
	 * 
	 * @param millis The minimum delay in milliseconds
	 */
	public void setMinTouchPressDelay(long millis) {
		minTouchPressDelay = millis;
	}
	
}

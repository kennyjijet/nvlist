package nl.weeaboo.vn.android.impl;

import nl.weeaboo.lua2.io.LuaSerializable;
import nl.weeaboo.vn.BlendMode;
import nl.weeaboo.vn.impl.base.BaseTextDrawable;

@LuaSerializable
public class TextDrawable extends BaseTextDrawable {

	private static final long serialVersionUID = AndroidImpl.serialVersionUID;

	private final TextureTR textRenderer;
	
	public TextDrawable(TextureTR tr) {
		super(tr);
		
		this.textRenderer = tr;
	}
	
	//Functions
	
	//Getters
	
	//Setters
	@Override
	public void setBlendMode(BlendMode bm) {
		super.setBlendMode(bm);
		textRenderer.setBlendMode(bm);
	}
	
	@Override
	public void setBackgroundColor(double r, double g, double b, double a) {
		super.setBackgroundColor(r, g, b, a);
		textRenderer.setBackgroundColor(getBackgroundColorARGB());
	}
	
}

package nl.weeaboo.vn.android.impl;

import nl.weeaboo.lua2.io.LuaSerializable;
import nl.weeaboo.vn.BlendMode;
import nl.weeaboo.vn.IDrawBuffer;
import nl.weeaboo.vn.ITextRenderer;
import nl.weeaboo.vn.impl.base.BaseTextDrawable;
import nl.weeaboo.vn.layout.LayoutUtil;

@LuaSerializable
public class TextDrawable extends BaseTextDrawable {

	private static final long serialVersionUID = AndroidImpl.serialVersionUID;

	private final TextureTR textRenderer;
	
	public TextDrawable(TextureTR tr) {
		super(tr);
		
		this.textRenderer = tr;
	}
	
	//Functions
	@Override
	public void draw(IDrawBuffer d) {
		super.draw(d);
		
		/*
		int[] pressed = consumePressedLinks();
		if (pressed != null && pressed.length > 0) {
			System.out.println(Arrays.toString(pressed));
		}
		*/
	}
	
	//Getters
	
	//Setters
	@Override
	public void setBlendMode(BlendMode bm) {
		super.setBlendMode(bm);
		textRenderer.setBlendMode(bm);
	}
	
	@Override
	public void setBackgroundColor(double r, double g, double b, double a) {
		super.setBackgroundColor(r, g, b, a);
		textRenderer.setBackgroundColor(getBackgroundColorARGB());
	}
		
}

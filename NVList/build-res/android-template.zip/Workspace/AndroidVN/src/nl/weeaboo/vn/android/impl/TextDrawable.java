package nl.weeaboo.vn.android.impl;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.Arrays;

import javax.microedition.khronos.opengles.GL;

import nl.weeaboo.android.gl.GLDraw;
import nl.weeaboo.android.gl.GLTexRect;
import nl.weeaboo.android.gl.GLTexture;
import nl.weeaboo.android.gui.FontManager;
import nl.weeaboo.android.gui.ShadowSpan;
import nl.weeaboo.android.gui.TextLayoutUtil;
import nl.weeaboo.android.gui.TextStyleParser;
import nl.weeaboo.lua2.io.LuaSerializable;
import nl.weeaboo.styledtext.MutableStyledText;
import nl.weeaboo.styledtext.MutableTextStyle;
import nl.weeaboo.styledtext.StyledText;
import nl.weeaboo.styledtext.TextStyle;
import nl.weeaboo.vn.BlendMode;
import nl.weeaboo.vn.IDrawable;
import nl.weeaboo.vn.IImageDrawable;
import nl.weeaboo.vn.IRenderer;
import nl.weeaboo.vn.impl.base.BaseTextDrawable;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.text.Layout;
import android.text.Layout.Alignment;
import android.text.SpannableString;
import android.text.TextPaint;
import android.text.style.CharacterStyle;
import android.text.style.ForegroundColorSpan;

@LuaSerializable
public class TextDrawable extends BaseTextDrawable {

	private static final long serialVersionUID = AndroidImpl.serialVersionUID;

	private static final CharacterStyle INVISIBLE_FOREGROUND = new ForegroundColorSpan(0);
	private static final CharacterStyle INVISIBLE_SHADOW = new ShadowSpan(0, 0, 0);
	
	private ImageFactory imgfac;
	private double textScale;
	private double displayDensity;
	
	//Cached
	private transient GLTexRect tex;
	private transient TextureAdapter texWrapper;
	private transient Bitmap texBitmap;
	private transient Canvas texCanvas;
	private transient Layout layout;
	private transient float[] lineMax;
	private transient double texScaleX, texScaleY;
	private transient int bottomPad;
	private transient int visibleCharsInLayout;
	private transient boolean allowCursorResize;
	
	public TextDrawable(ImageFactory imgfac, double scale, double textScale, double displayDensity) {
		super(new StyledText(""));
		
		this.imgfac = imgfac;
		this.textScale = textScale;
		this.displayDensity = displayDensity;
		
		texScaleX = texScaleY = 1.0 / scale;
		
		initTransients();
	}
	
	//Functions
	private void initTransients() {
		bottomPad = 2;
		allowCursorResize = true;
	}

	private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
		in.defaultReadObject();
		
		initTransients();
	}	
	
	@Override
	public void destroy() {
		if (!isDestroyed()) {
			disposeTexture();
			if (texBitmap != null) {
				texBitmap.recycle();
				texBitmap = null;
			}
			
			super.destroy();
		}
	}
	
	@Override
	public void draw(IRenderer r) {
		Renderer rr = (Renderer)r;
		GL gl = rr.getGL();		
		
		//Recalculate required texture size
		double newTexScale = 1.0 / r.getScale();
		if (texScaleX != newTexScale || texScaleY != newTexScale) {
			texScaleX = texScaleY = newTexScale;
			invalidateLayout();
		}
		
		updateTextureSize(r);
		
		if (displayDensity != rr.getDisplayDensity() || textScale != rr.getTextScale()) {
			displayDensity = rr.getDisplayDensity();
			textScale = rr.getTextScale();
			invalidateLayout();
		}
		
		if (getTextureWidth() <= 0 || getTextureHeight() <= 0) {			
			//Log.w("TextDrawable", "Panic: illegal texture size (" + getTextureWidth() + "x" + getTextureHeight() + ")");
			return; //Texture size <= 0, nothing to draw
		}
		
		double alpha = getAlpha();
		if (alpha <= 0) {
			return; //Nothing to render, completely transparent
		}

		//Ensure layout uses the most up-to-date version
		updateVisibleCharsInLayout();
		
		//Recreate texture if disposed
		if (tex == null || tex.isDisposed()) {
			GLTexture t = rr.createTexture(getTextureWidth(), getTextureHeight());
			tex = t.getTexRect(0);
			texWrapper = new TextureAdapter(tex, null, 1, 1);
			
			setTexDirty(true);
		}
					
		int bgColor = getBackgroundColorARGB();
		int bgAlpha = ((bgColor>>24)&0xFF);
		int textLength = getText().length();
		int texWidth = getTextureWidth();
		int texHeight = getTextureHeight();
		
		//Update texture (if the text string is non-empty)
		if (textLength > 0 && isTexDirty() && texWidth > 0 && texHeight > 0) {
			setTexDirty(false);
			
			boolean opaque = (bgAlpha == 255 || getBlendMode() == BlendMode.OPAQUE);
			Bitmap.Config config = Bitmap.Config.ARGB_8888;
			if (opaque) {
				config = Bitmap.Config.RGB_565;
			}
	        
			if (texBitmap == null || texBitmap.getWidth() != texWidth || texBitmap.getHeight() != texHeight) {
				//Current bitmap isn't good enough
				if (texBitmap != null) {
					texBitmap.recycle();
				}
				
				//Create new bitmap
				texBitmap = GLDraw.createCompatibleBitmap(gl, texWidth, texHeight, config);
		        if (opaque && bgColor != 0) {
		        	texBitmap.eraseColor(bgColor);
		        }
		        texCanvas = new Canvas(texBitmap);
			} else {
				//Clear and reuse existing bitmap
	        	texBitmap.eraseColor(opaque ? bgColor : 0);
			}
			
	        Layout layout = getLayout();
	        
			texCanvas.save();
	        texCanvas.clipRect(new Rect(0, 0, texWidth, getLayoutHeight()));
			texCanvas.translate(0, getTranslateY());
			layout.draw(texCanvas);
			texCanvas.restore();
			
			tex.getTexture().setPixels(gl, texBitmap);			
		}
		
		if (bgAlpha > 0) {
			if (alpha < 1) {
				bgAlpha = Math.max(0, Math.min(255, (int)Math.round(bgAlpha * alpha)));
			}
			if (bgAlpha > 0) {
				int c = (bgAlpha<<24)|(bgColor&0xFFFFFF);
				rr.drawQuad((short)(getZ()+1), isClipEnabled(), getBlendMode(), c, null,
					getTransform(), 0, 0, getWidth(), getHeight(), getPixelShader());
			}
		}
		
		if (textLength > 0 && texWrapper != null) {			
			double u = getLayoutWidth() / (double)getTextureWidth();
			double v = getLayoutHeight() / (double)getTextureHeight();
			//u = Math.max(0, Math.min(1.0, u));
			//v = Math.max(0, Math.min(1.0, v));
			
			double w = getInnerWidth();
			double h = getInnerHeight();
			double tw = getTextWidth();
			double th = getTextHeight();
			
			double tx = 0, ty = 0;			
			int anchor = getAnchor();
			if (anchor == 2 || anchor == 5 || anchor == 8) {
				tx = (w-tw)/2;
			} else if (anchor == 3 || anchor == 6 || anchor == 9) {
				tx = (w-tw);
			}
			if (anchor >= 4 && anchor <= 6) {
				ty = (h-th)/2;
			} else if (anchor >= 1 && anchor <= 3) {
				ty = (h-th);
			}
			
			double pad = getPadding();
			rr.drawQuad(getZ(), isClipEnabled(), getBlendMode(), getColorARGB(), texWrapper,
					getTransform(), pad+tx, pad+ty, tw, th,
					0, 0, u, v, getPixelShader());
		}

		updateCursorPos();
	}
	
	private void invalidateLayout() {
		markChanged();
		
		layout = null;
		lineMax = null;
	}
	
	protected void updateTextureSize(IRenderer r) {
		if (allowCursorResize) {
			allowCursorResize = false;

			IDrawable cursor = getCursor();
			if (cursor instanceof IImageDrawable) {
				//HACK: Change the cursor size automatically based on the text size
				IImageDrawable id = (IImageDrawable)cursor;
				int cl = getCursorLine();
				double scale = getTextHeight(cl, cl+1) / id.getUnscaledHeight();
				id.setScale(scale);
			}
		}
		
		super.updateTextureSize(r);
	}
	
	private void disposeTexture() {
		if (tex != null) {
			tex.getTexture().dispose();
		}		
		tex = null;
		texWrapper = null;
	}
	
	@Override
	protected void onSizeChanged() {
		invalidateLayout();
		
		disposeTexture();		
		allowCursorResize = true;
	}
	
	@Override
	protected void onTextChanged() {
		invalidateLayout();

		allowCursorResize = true;
	}
	
	//Getters
	protected void updateVisibleCharsInLayout() {
		//Second pass to generate fade-in styles
		int vc = (int)Math.round(getVisibleChars());
		if (visibleCharsInLayout != vc) {
			visibleCharsInLayout = vc;
			
			layout = getLayout();
			
			CharSequence text = layout.getText();
			SpannableString stext = (SpannableString)text;
			int length = stext.length();
			
			int start = getCharOffset(getStartLine());
			int end   = (vc >= 0 ? start + vc : length);
						
			//Remove previous invisibility spans (call removeSpan() once per span to remove)
			stext.removeSpan(INVISIBLE_FOREGROUND);
			stext.removeSpan(INVISIBLE_FOREGROUND);
			
			stext.removeSpan(INVISIBLE_SHADOW);
			stext.removeSpan(INVISIBLE_SHADOW);

			//Apply new spans
			if (start > 0) {
				stext.setSpan(INVISIBLE_FOREGROUND, 0, start, 0);			
				stext.setSpan(INVISIBLE_SHADOW, 0, start, 0);
			}
			if (end < length) {
				stext.setSpan(INVISIBLE_FOREGROUND, end, length, 0);			
				stext.setSpan(INVISIBLE_SHADOW, end, length, 0);
			}

			//I don't think we need to create a new layout object. No layout-related properties were changed.
			//layout = TextLayout.doLayout(stext, layout.getWidth(), layout.getPaint(), layout.getAlignment());			
		}
	}
	protected Layout getLayout() {
		if (layout == null) {
			layout = createLayout(0xFFFFFFFF, false);
			visibleCharsInLayout = getMaxVisibleChars();
		}
		return layout;
	}
	private Layout createLayout(int argb, boolean generateFadeInStyles) {
		int iwidth = Math.max(0, (int)Math.round(getInnerWidth() / getTextureScaleX()));
		if (getTextureWidth() > 0) {
			iwidth = Math.min(iwidth, getTextureWidth());
		}
		
		StyledText text = getText();
		MutableStyledText stext;
		if (text.length() > 8192) {
			//Prevent out-of-memory errors
			stext = text.substring(0, 8192).mutableCopy();
		} else {
			stext = text.mutableCopy();
		}
		
		//Make all styles extend the defaultStyle
		TextStyle lastSourceStyle = null;
		TextStyle lastDestStyle = null;
		
		TextStyle defaultStyle = imgfac.getDefaultStyle().extend(getDefaultStyle());
		for (int n = 0; n < stext.length(); n++) {
			TextStyle curStyle = stext.getStyle(n);
			TextStyle newStyle;
			if (curStyle == lastSourceStyle && lastDestStyle != null) {
				newStyle = lastDestStyle;
			} else {
				if (argb == 0xFFFFFFFF) {
					newStyle = defaultStyle.extend(curStyle);
				} else {
					MutableTextStyle mts = defaultStyle.mutableCopy();
					mts.extend(curStyle);
					mts.setColor(argb);
					newStyle = mts.immutableCopy();
				}
			}
			
			lastSourceStyle = curStyle;
			lastDestStyle = newStyle;
			stext.setStyle(newStyle, n);
		}
		
		FontManager fontManager = imgfac.getFontManager();
		SpannableString styled = TextStyleParser.toSpannableString(fontManager, stext.immutableCopy());
		
		TextPaint paint = TextLayoutUtil.getTextPaint(displayDensity);
		paint.setColor(argb);
		paint.setTextSize((float)(textScale * paint.getTextSize()));
		
		return TextLayoutUtil.doLayout(styled, iwidth, paint, Alignment.ALIGN_NORMAL);
	}
	
	@Override
	public double getTextWidth() {
		return getTextureScaleX() * getLayoutWidth();
	}

	@Override
	public double getTextHeight(int start, int end) {
		return getTextureScaleY() * getLayoutHeight(start, end);
	}
	
	protected double getTextureScaleX() {
		return texScaleX;
	}
	protected double getTextureScaleY() {
		return texScaleY;
	}
	
	@Override
	public int getLayoutWidth() {
		Layout layout = getLayout();
		return layout.getWidth();
	}
		
	@Override
	public int getLayoutHeight(int start, int end) {
		Layout layout = getLayout();
		
		int lineCount = layout.getLineCount();
		start = Math.max(0, Math.min(lineCount, start));
		end = Math.max(0, Math.min(lineCount-1, end-1));
		
		int top = (start == 0 ? -layout.getTopPadding() : layout.getLineTop(start));
		int bottom = bottomPad;
		if (end >= 0 && end < lineCount) {
			bottom += layout.getLineBottom(end);
		}
		
		return bottom - top;
	}
	
	@Override
	public int getEndLine() {
		final Layout layout = getLayout();
		final int lineCount = layout.getLineCount();
		if (lineCount == 0) {
			return 0;
		}
		
		final int startLine = Math.max(0, Math.min(lineCount, getStartLine()));		
		final int iheight = (int)Math.ceil(getInnerHeight() / getTextureScaleY());
		final int startTop = (startLine == 0 ? -layout.getTopPadding() : layout.getLineTop(startLine));
		final int limit = iheight - bottomPad + startTop;
		
		int endLine = startLine;
		while (endLine < lineCount && layout.getLineBottom(endLine) <= limit) {
			endLine++;
		}
		return endLine; 
	}

	@Override
	public int getLineCount() {
		Layout layout = getLayout();
		return layout.getLineCount();
	}

	@Override
	public int getCharOffset(int line) {
		Layout layout = getLayout();
		return layout.getLineStart(Math.max(0, Math.min(layout.getLineCount(), line)));
	}

	//Layout.getLineMax() does some fairly complex calculations. Use lineMax array for manual caching.
	private float getLineMax(int line) {
		if (lineMax == null) {
			lineMax = new float[layout.getLineCount()];
			Arrays.fill(lineMax, -1);
		}
		if (lineMax[line] < 0) {
			lineMax[line] = layout.getLineMax(line);
		}
		return lineMax[line];
	}
	
	private int getCursorLine() {
		Layout layout = getLayout();
		int sl = getStartLine();
		int el = getEndLine();
		for (int i = el-1; i >= sl; i--) {
			float w = layout.getLineMax(i);
			if (w > 0) {
				return i;
			}
		}
		return sl;
	}
	
	@Override
	protected double getCursorX() {
		if (getLineCount() == 0) return 0;

		int cl = getCursorLine();
		if (cl < 0 || cl >= getLineCount()) {
			return 0;
		} else {
			return getTextureScaleX() * getLineMax(cl);
		}
	}

	private int getTranslateY() {
		Layout layout = getLayout();
		int sl = getStartLine();
		return (sl == 0 ? layout.getTopPadding() : -layout.getLineTop(sl));		
	}
	
	@Override
	protected double getCursorY() {
		if (getLineCount() == 0) return 0;
				
		double cursorHeight = 0;
		IDrawable cursor = getCursor();
		if (cursor != null) {
			cursorHeight = cursor.getHeight();
		}
		
		Layout layout = getLayout();	
		int cl = getCursorLine();
		float bottom = layout.getLineBottom(cl);
		
		return getTextureScaleY() * (getTranslateY() + bottom) - cursorHeight;		
	}
	
	//Setters
	@Override
	public void setBlendMode(BlendMode bm) {
		if (bm != getBlendMode()) {
			if (getBlendMode() == BlendMode.OPAQUE || bm == BlendMode.OPAQUE) {
				setTexDirty(true);
			}
			
			super.setBlendMode(bm);
		}
	}
	
	@Override
	public void setBackgroundColor(double r, double g, double b, double a) {
		//change from opaque to non-opaque or vice-versa
		if ((getBackgroundAlpha() >= 1.0) != (a >= 1.0)) {
			setTexDirty(true);
		}
		
		super.setBackgroundColor(r, g, b, a);
	}
	
}

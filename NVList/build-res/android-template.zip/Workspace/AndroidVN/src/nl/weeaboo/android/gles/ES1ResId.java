package nl.weeaboo.android.gles;

import java.util.concurrent.atomic.AtomicInteger;

import javax.microedition.khronos.opengles.GL10;

import nl.weeaboo.gl.GLLog;
import nl.weeaboo.gl.GLManager;
import nl.weeaboo.gl.GLResCache;
import nl.weeaboo.gl.GLResId;

public final class ES1ResId implements GLResId {

	private enum Type {
		TEXTURE;
		
		final AtomicInteger alive = new AtomicInteger();
		
		private Type() {			
		}
	}
	
	private final Type type;
	private final int surfaceId;
	private int id;
	
	private ES1ResId(Type type, int id, int surfaceId) {
		this.type = type;
		this.id = id;
		this.surfaceId = surfaceId;
		
		type.alive.incrementAndGet();
	}
	
	//Functions		
	static ES1ResId newTextureInstance(GL10 gl, GLResCache rc) {
		int[] ids = new int[1];
		gl.glGenTextures(1, ids, 0);		

		ES1ResId r = new ES1ResId(Type.TEXTURE, ids[0], rc.getSurfaceId());
		rc.registerId(r);
		return r;
	}
	
	@Override
	public void dispose() {
		id = 0;
	}
	
	@Override
	public String toString() {
		return "GLResId(" + type + ":" + id + ")";
	}
	
	//Getters
	@Override
	public int getId() {
		return id;
	}
	
	static int getTextureCount() {
		return Type.TEXTURE.alive.get();
	}
	
	//Setters
	
	//Inner Classes
	static final class IdRef extends GLResCache.IdRef {
		
		private final Type type;
		private final int id;
		private final int surfaceId;
		
		private boolean disposed;
		
		public IdRef(ES1ResId r, GLResCache rc) {
			super(r, rc);
			
			this.type = r.type;
			this.id = r.id;
			this.surfaceId = r.surfaceId;
		}

		@Override
		public void dispose(GLManager glm, int currentSurfaceId) {
			if (disposed) {
				return;
			}
			disposed = true;
			
			type.alive.decrementAndGet();
			
			GL10 gl = ES1Manager.getGL(glm);
			if (surfaceId == currentSurfaceId && id != 0) {
				switch (type) {
				case TEXTURE:
					//System.out.println("DISPOSE: " + id);
					gl.glDeleteTextures(1, new int[]{id}, 0);
					break;
				default:
					GLLog.w("Undisposable GLResourceId type: " + type);
				}
			}		
		}
		
	}
	
}

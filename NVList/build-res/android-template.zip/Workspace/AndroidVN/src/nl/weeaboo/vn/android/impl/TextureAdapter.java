package nl.weeaboo.vn.android.impl;

import nl.weeaboo.android.gl.GLTexRect;
import nl.weeaboo.android.gl.GLTexture;
import nl.weeaboo.common.Area2D;
import nl.weeaboo.lua2.io.LuaSerializable;
import nl.weeaboo.vn.ITexture;

@LuaSerializable
public class TextureAdapter implements ITexture {

	private static final long serialVersionUID = AndroidImpl.serialVersionUID;
	
	private GLTexRect tr;
	private String id;
	private double scaleX, scaleY;
	
	public TextureAdapter(GLTexRect tr, String id, double sx, double sy) {
		this.tr = tr;
		this.id = id;
		this.scaleX = sx;
		this.scaleY = sy;
	}
	
	@Override
	public int hashCode() {
		return (tr != null ? tr.hashCode() : 0);
	}
	
	@Override
	public boolean equals(Object obj) {
		if (obj instanceof TextureAdapter && obj.getClass().equals(getClass())) {
			TextureAdapter ta = (TextureAdapter)obj;
			return (tr == ta.tr || (tr != null && tr.equals(ta.tr)))
				&& scaleX == ta.scaleX
				&& scaleY == ta.scaleY;
		}
		return false;
	}
	
	@Override
	public String toString() {
		return String.format("TextureAdapter(%s)", tr.getPath());
	}
	
	public String getId() {
		return id;
	}
	
	public int getTexId() {
		return (tr != null ? tr.getTexId() : 0);
	}
	
	public GLTexRect getTexRect() {
		return tr;
	}

	@Override
	public Area2D getUV() {
		if (tr != null) {
			GLTexture tex = tr.getTexture();
			if (tex != null) {
				Area2D uv = tr.getUV();
				int tw = tex.getTexWidth();
				int th = tex.getTexHeight();
				if (tw > 0 && th > 0) {
					return new Area2D(uv.x/tw, uv.y/th, uv.w/tw, uv.h/th);
				}
			}
		}
		return new Area2D(0, 0, 1, 1);
	}
	
	@Override
	public double getWidth() {
		return tr.getWidth() * scaleX;
	}
			
	@Override
	public double getHeight() {
		return tr.getHeight() * scaleY;
	}
	
	public double getScaleX() {
		return scaleX;
	}
	
	public double getScaleY() {
		return scaleY;
	}
	
	public void setTexRect(GLTexRect tr, double sx, double sy) {
		this.tr = tr;
		this.scaleX = sx;
		this.scaleY = sy;
	}
	
}